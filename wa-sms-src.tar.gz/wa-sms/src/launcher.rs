use crate::config::{home_dir, xdg_data};
use std::path::PathBuf;

// The applications-menu entry ("wa-sms install" / "wa-sms uninstall").

fn make_icon(p: &PathBuf) -> Result<(), String> {
    const N: usize = 128;
    let mut px = vec![0u8; N * N * 4];
    let mut set = |x: usize, y: usize, c: [u8; 4]| {
        let i = (y * N + x) * 4;
        px[i..i + 4].copy_from_slice(&c);
    };
    for y in 0..N {
        for x in 0..N {
            let (dx, dy) = (x as f64 - (N / 2) as f64 + 0.5, y as f64 - (N / 2) as f64 + 0.5);
            if dx * dx + dy * dy <= 62.0 * 62.0 {
                set(x, y, [37, 160, 90, 255]);
            }
            // white speech bubble
            if (x > 34 && x < 94 && y > 34 && y < 84) || (x > 40 && x < 60 && (84..98).contains(&y) && x - 40 < 98 - y) {
                set(x, y, [255, 255, 255, 255]);
            }
            // three green lines of text
            if x > 44 && x < 84 && (y / 8 == 5 || y / 8 == 7 || y / 8 == 9) && y % 8 < 3 && y > 40 && y < 78 {
                set(x, y, [37, 160, 90, 255]);
            }
        }
    }
    if let Some(dir) = p.parent() {
        std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    let file = std::fs::File::create(p).map_err(|e| e.to_string())?;
    let mut enc = png::Encoder::new(std::io::BufWriter::new(file), N as u32, N as u32);
    enc.set_color(png::ColorType::Rgba);
    enc.set_depth(png::BitDepth::Eight);
    let mut w = enc.write_header().map_err(|e| e.to_string())?;
    w.write_image_data(&px).map_err(|e| e.to_string())
}

pub fn launcher_paths() -> (PathBuf, PathBuf) {
    let d = xdg_data();
    (d.join("applications").join("wa-sms.desktop"), d.join("icons").join("hicolor").join("128x128").join("apps").join("wa-sms-icon.png"))
}

pub fn install_launcher() -> Result<PathBuf, String> {
    let exe = std::env::current_exe().map_err(|e| e.to_string())?;
    let exe = std::fs::canonicalize(&exe).unwrap_or(exe);
    let (desktop, icon) = launcher_paths();
    make_icon(&icon)?;
    if let Some(dir) = desktop.parent() {
        std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    }
    let text = format!(
        "[Desktop Entry]\nType=Application\nName=Wa-sms\nComment=Send WhatsApp / SMS to branch managers\nExec=\"{}\"\nIcon={}\nTerminal=true\nCategories=Utility;Office;\nStartupWMClass=wa-sms\n",
        exe.display(),
        icon.display()
    );
    std::fs::write(&desktop, text).map_err(|e| e.to_string())?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&desktop, std::fs::Permissions::from_mode(0o755));
    }
    Ok(desktop)
}

pub fn uninstall_launcher() {
    let (d, i) = launcher_paths();
    let _ = std::fs::remove_file(d);
    let _ = std::fs::remove_file(i);
}

pub fn ensure_launcher() {
    if std::env::var_os("WA_SMS_NO_LAUNCHER").is_some() || std::env::var_os("WA_SA_NO_LAUNCHER").is_some() || home_dir().as_os_str().is_empty() {
        return;
    }
    let (d, _) = launcher_paths();
    if !d.exists() {
        let _ = install_launcher();
    }
}

pub fn cmd_install() {
    match install_launcher() {
        Ok(p) => println!("Launcher installed: {}\nFind 'Wa-sms' in your applications menu.", p.display()),
        Err(e) => {
            println!("Could not install the launcher: {e}");
            std::process::exit(1);
        }
    }
}
