use crate::config::Cfg;
use crate::util::{b64, one_line, query_escape};
use serde_json::Value;
use std::io::Read;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::Duration;

// SMS goes through a gateway app on a phone in the same Wi-Fi (no user name, no password).
// Gateway apps differ in the address they listen on and in the way they want the request,
// so the first real send tries the usual combinations and remembers the one that worked.

/// One way of talking to a gateway: where, in which body style, with which phone style.
#[derive(Clone, Debug)]
struct Attempt {
    label: String, // e.g. "send-sms/json/plus", saved as sms_mode in config.json
    method: &'static str,
    path: &'static str,
    body: &'static str,  // json, form, get, capcom, capcom-new
    phone: &'static str, // plus (+919..), digits (919..), local (99..)
}

fn attempts() -> Vec<Attempt> {
    let mut all = Vec::new();
    for phone in ["plus", "digits", "local"] {
        let mut add = |name: &str, method: &'static str, path: &'static str, body: &'static str| {
            all.push(Attempt { label: format!("{name}/{phone}"), method, path, body, phone });
        };
        add("send-sms/json", "POST", "/send-sms", "json");
        add("send-sms/form", "POST", "/send-sms", "form");
        add("send-sms/get", "GET", "/send-sms", "get");
        add("send/json", "POST", "/send", "json");
        add("sms/json", "POST", "/sms", "json");
        add("sendsms/json", "POST", "/sendsms", "json");
        if phone != "local" {
            // these gateways insist on an international number
            add("message/capcom", "POST", "/message", "capcom");
            add("messages/capcom-new", "POST", "/messages", "capcom-new");
            add("api-v1-message/capcom", "POST", "/api/v1/message", "capcom");
            add("api-v1-messages/capcom-new", "POST", "/api/v1/messages", "capcom-new");
        }
    }
    all
}

#[derive(Default)]
struct GwState {
    base: String,
    learned: String, // label of the attempt that worked
}

/// Sends SMS through the phone app.
#[derive(Default)]
pub struct Gateway {
    st: Mutex<GwState>,
}

fn agent() -> ureq::Agent {
    ureq::Agent::config_builder()
        .timeout_global(Some(Duration::from_secs(20)))
        .http_status_as_error(false)
        .build()
        .into()
}

fn json_text(s: &str) -> String {
    serde_json::to_string(s).unwrap_or_else(|_| "\"\"".into())
}

/// Makes "192.168.1.20:8080" into "http://192.168.1.20:8080".
pub fn gateway_base(raw: &str) -> Result<String, String> {
    let mut raw = raw.trim().to_string();
    if raw.is_empty() {
        return Err("SMS gateway address is not set (config.json: sms_server_url)".into());
    }
    if !raw.contains("://") {
        raw = format!("http://{raw}");
    }
    let after = raw.split("://").nth(1).unwrap_or("");
    let authority = after.split(['/', '?', '#']).next().unwrap_or("");
    let host = authority.rsplit('@').next().unwrap_or("");
    if host.is_empty() || host.contains(' ') {
        return Err(format!("SMS gateway address looks wrong: {raw:?} (use IP:port, e.g. 192.168.1.20:8080)"));
    }
    Ok(raw.trim_end_matches('/').to_string())
}

/// Splits "http://user:pass@IP:port" into the address without the login and a Basic header.
fn split_login(base: &str) -> (String, Option<String>) {
    let Some((scheme, rest)) = base.split_once("://") else { return (base.to_string(), None) };
    let (authority, path) = match rest.find(['/', '?', '#']) {
        Some(i) => (&rest[..i], &rest[i..]),
        None => (rest, ""),
    };
    match authority.rsplit_once('@') {
        Some((login, host)) => (format!("{scheme}://{host}{path}"), Some(format!("Basic {}", b64(login.as_bytes())))),
        None => (base.to_string(), None),
    }
}

impl Attempt {
    fn phone_text(&self, phone: &str, country: &str) -> String {
        match self.phone {
            "plus" => format!("+{phone}"),
            "local" if !country.is_empty() && phone.starts_with(country) && phone.len() > country.len() + 6 => phone[country.len()..].to_string(),
            _ => phone.to_string(),
        }
    }

    /// Returns (method, url, content type, body).
    fn request(&self, base: &str, phone: &str, text: &str, country: &str) -> (&'static str, String, Option<&'static str>, Option<String>) {
        let p = self.phone_text(phone, country);
        let mut target = format!("{base}{}", self.path);
        let (mut content_type, mut body) = (None, None);
        match self.body {
            "capcom" => {
                body = Some(format!("{{\"message\":{},\"phoneNumbers\":[{}]}}", json_text(text), json_text(&p)));
                content_type = Some("application/json");
            }
            "capcom-new" => {
                body = Some(format!("{{\"textMessage\":{{\"text\":{}}},\"phoneNumbers\":[{}]}}", json_text(text), json_text(&p)));
                content_type = Some("application/json");
            }
            "json" => {
                body = Some(format!("{{\"phone\":{},\"message\":{}}}", json_text(&p), json_text(text)));
                content_type = Some("application/json");
            }
            "form" => {
                body = Some(format!("message={}&phone={}", query_escape(text), query_escape(&p)));
                content_type = Some("application/x-www-form-urlencoded");
            }
            "get" => target.push_str(&format!("?message={}&phone={}", query_escape(text), query_escape(&p))),
            _ => {}
        }
        (self.method, target, content_type, body)
    }
}

/// Runs a request and returns the status code and the start of the answer.
fn do_request(method: &str, url: &str, content_type: Option<&str>, body: Option<String>, login: &Option<String>) -> Result<(u16, String), String> {
    let a = agent();
    let result = if method == "GET" {
        let mut r = a.get(url);
        if let Some(l) = login {
            r = r.header("Authorization", l);
        }
        r.call()
    } else {
        let mut r = a.post(url);
        if let Some(l) = login {
            r = r.header("Authorization", l);
        }
        if let Some(ct) = content_type {
            r = r.header("Content-Type", ct);
        }
        match body {
            Some(b) => r.send(b),
            None => r.send_empty(),
        }
    };
    let mut resp = result.map_err(|e| e.to_string())?;
    let code = resp.status().as_u16();
    let mut buf = Vec::new();
    let _ = resp.body_mut().as_reader().take(4096).read_to_end(&mut buf);
    Ok((code, one_line(&String::from_utf8_lossy(&buf), 260)))
}

fn unreachable(base: &str, err: &str) -> String {
    format!("cannot reach {base} ({err}). Open the gateway app, make sure its server is STARTED, put the IP:port it shows into config.json (sms_server_url) and keep phone and computer on the same Wi-Fi")
}

fn login_required(code: u16) -> String {
    format!("HTTP {code}: the gateway wants a login. Switch the login off in the gateway app (or write the address as http://user:pass@IP:port)")
}

/// Spots gateways that answer HTTP 200 but say {"success":false,"error":"..."}.
pub fn failure_in_body(body: &str) -> String {
    let Ok(Value::Object(m)) = serde_json::from_str::<Value>(body) else { return String::new() };
    let reason = || -> String {
        for k in ["error", "message", "detail", "reason"] {
            if let Some(Value::String(s)) = m.get(k) {
                if !s.is_empty() {
                    return s.clone();
                }
            }
        }
        body.to_string()
    };
    for k in ["success", "ok"] {
        if let Some(Value::Bool(false)) = m.get(k) {
            return reason();
        }
    }
    if let Some(Value::String(s)) = m.get("status") {
        if !s.is_empty() && "error failed fail".contains(&s.to_lowercase()) {
            return reason();
        }
    }
    if let Some(Value::String(s)) = m.get("error") {
        if !s.is_empty() {
            return s.clone();
        }
    }
    String::new()
}

/// Explains the usual reasons behind a refusal.
pub fn hint_for(answer: &str) -> &'static str {
    let a = answer.to_lowercase();
    if a.contains("permission") {
        "Hint: the gateway app has no permission to send SMS (phone Settings > Apps > the app > Permissions > SMS)."
    } else if a.contains("sim") {
        "Hint: the phone has no usable SIM for this."
    } else if a.contains("platform") {
        "Hint: the PHONE's own SMS system refused it. Check SIM signal and balance, and that the gateway app may run in the background."
    } else if a.contains("invalid") || a.contains("number") || a.contains("phone") {
        "Hint: the gateway did not accept the phone number format (+91..., 91... and the local number were tried)."
    } else {
        ""
    }
}

fn first_of(list: &[String], n: usize) -> Vec<String> {
    let mut seen = std::collections::HashSet::new();
    let mut out: Vec<String> = list.iter().filter(|s| seen.insert((*s).clone())).cloned().collect();
    if out.len() > n {
        out.truncate(n);
        out.push("...".into());
    }
    out
}

impl Gateway {
    /// Forgets what was learned (used when the settings change).
    pub fn reset(&self) {
        let mut g = self.st.lock().unwrap_or_else(|p| p.into_inner());
        g.base.clear();
        g.learned.clear();
    }

    pub fn learned(&self) -> String {
        self.st.lock().unwrap_or_else(|p| p.into_inner()).learned.clone()
    }

    fn remember(&self, label: &str) {
        self.st.lock().unwrap_or_else(|p| p.into_inner()).learned = label.to_string();
    }

    /// Delivers one SMS. It tries the saved way first, then the others, and stops at the first success.
    pub fn send(&self, stop: &AtomicBool, cfg: &Cfg, phone: &str, text: &str) -> Result<(), String> {
        let base_full = gateway_base(&cfg.sms_url)?;
        let (base, login) = split_login(&base_full);
        if !cfg.sms_path.trim().is_empty() {
            return self.send_custom(cfg, &base, &login, phone, text);
        }

        let learned = {
            let mut g = self.st.lock().unwrap_or_else(|p| p.into_inner());
            if g.base != base {
                // the address changed: forget what we learned
                g.base = base.clone();
                g.learned.clear();
                if !cfg.sms_mode.is_empty() && cfg.sms_mode != "auto" {
                    g.learned = cfg.sms_mode.clone();
                }
            }
            g.learned.clone()
        };

        let all = attempts();
        let mut order: Vec<&Attempt> = all.iter().filter(|a| a.label == learned).collect(); // the learned attempt goes first
        order.extend(all.iter().filter(|a| a.label != learned));

        let (mut refusal, mut refusal_body, mut best_rank) = (String::new(), String::new(), 0u8);
        let mut refused = |rank: u8, why: String, answer: &str| {
            // keep the most telling refusal, not the last one
            if rank > best_rank {
                best_rank = rank;
                refusal = why;
                refusal_body = answer.to_string();
            }
        };
        let mut tried: Vec<String> = Vec::new();
        for a in order {
            if stop.load(Ordering::Relaxed) {
                return Err("stopped".into());
            }
            let (method, url, ct, body) = a.request(&base, phone, text, &cfg.country);
            let (code, answer) = match do_request(method, &url, ct, body, &login) {
                Ok(r) => r,
                Err(e) => return Err(unreachable(&base, &e)),
            };
            tried.push(format!("{} {}={}", a.method, a.path, code));
            match code {
                200..=299 => {
                    let reason = failure_in_body(&answer);
                    if !reason.is_empty() {
                        refused(3, format!("{} {} ({} phone) said: {}", a.method, a.path, a.phone, reason), &reason);
                        continue;
                    }
                    self.remember(&a.label);
                    return Ok(());
                }
                401 | 403 => return Err(login_required(code)),
                404 | 405 => {} // this API does not exist on the gateway: try the next one
                _ => {
                    let rank = if code >= 500 {
                        3
                    } else if code != 400 && code != 415 {
                        2
                    } else {
                        1 // 400 / 415: probably only this body style is wrong
                    };
                    refused(rank, format!("HTTP {} on {} {} ({} phone): {}", code, a.method, a.path, a.phone, answer), &answer);
                }
            }
        }
        if !refusal.is_empty() {
            return Err(format!("the SMS gateway refused the message - {refusal}. {}", hint_for(&refusal_body)));
        }
        Err(format!(
            "no SMS API found at {base} - every known path answered 404/405. Check the IP:port exactly as the gateway app shows it. Tried: {}",
            first_of(&tried, 6).join("; ")
        ))
    }

    /// Uses the path, method and body written in config.json (sms_custom_*).
    fn send_custom(&self, cfg: &Cfg, base: &str, login: &Option<String>, phone: &str, text: &str) -> Result<(), String> {
        let path = cfg.sms_path.trim();
        let target = if path.contains("://") { path.to_string() } else { format!("{base}/{}", path.trim_start_matches('/')) };
        let plus = format!("+{phone}");
        let (code, answer, method) = if cfg.sms_method.eq_ignore_ascii_case("GET") {
            let url = target.replace("{phone}", &query_escape(&plus)).replace("{message}", &query_escape(text));
            let (c, a) = do_request("GET", &url, None, None, login).map_err(|e| unreachable(base, &e))?;
            (c, a, "GET")
        } else {
            let body = if cfg.sms_body.is_empty() { r#"{"phone":{phone},"message":{message}}"#.to_string() } else { cfg.sms_body.clone() };
            let t = body.trim();
            let (ct, filled) = if t.starts_with('{') || t.starts_with('[') {
                ("application/json", body.replace("{phone}", &json_text(&plus)).replace("{message}", &json_text(text)))
            } else {
                ("application/x-www-form-urlencoded", body.replace("{phone}", &query_escape(&plus)).replace("{message}", &query_escape(text)))
            };
            let (c, a) = do_request("POST", &target, Some(ct), Some(filled), login).map_err(|e| unreachable(base, &e))?;
            (c, a, "POST")
        };
        match code {
            401 | 403 => return Err(login_required(code)),
            c if !(200..300).contains(&c) => {
                return Err(format!("SMS gateway error HTTP {code} on {method} {path}: {answer} {}", hint_for(&answer)));
            }
            _ => {}
        }
        let reason = failure_in_body(&answer);
        if !reason.is_empty() {
            return Err(format!("SMS gateway said: {reason} {}", hint_for(&reason)));
        }
        Ok(())
    }

    /// Only asks the gateway server whether it is there (a plain GET /). It sends nothing that could
    /// reach the SMS engine: broken or empty test messages made some gateway apps print errors.
    /// The real proof is "Send test SMS" with your own number.
    pub fn check(&self, cfg: &Cfg) -> (String, bool) {
        let base_full = match gateway_base(&cfg.sms_url) {
            Ok(b) => b,
            Err(e) => return (e, false),
        };
        let (base, login) = split_login(&base_full);
        let (code, _) = match do_request("GET", &format!("{base}/"), None, None, &login) {
            Ok(r) => r,
            Err(e) => return (unreachable(&base, &e), false),
        };
        if code == 401 || code == 403 {
            return (format!("the gateway answered but wants a login (HTTP {code}). Switch the login off in the gateway app."), false);
        }
        let mut msg = format!("SMS gateway OK: {base} is running (HTTP {code} to a plain GET - 404 is normal). Nothing was sent.");
        if !cfg.sms_path.trim().is_empty() {
            msg.push_str(&format!(" Your own path {} is used.", cfg.sms_path));
        } else if !cfg.sms_mode.is_empty() && cfg.sms_mode != "auto" {
            msg.push_str(&format!(" Saved API: {}.", cfg.sms_mode));
        }
        (msg, true)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{Read, Write};
    use std::net::TcpListener;

    #[test]
    fn gateway_address_parsing() {
        assert_eq!(gateway_base("192.168.1.20:8080").unwrap(), "http://192.168.1.20:8080");
        assert_eq!(gateway_base("http://10.0.0.5:8080/").unwrap(), "http://10.0.0.5:8080");
        assert!(gateway_base("").is_err());
        assert!(gateway_base("http://bad host").is_err());
        let (clean, auth) = split_login("http://user:pass@10.0.0.5:8080");
        assert_eq!(clean, "http://10.0.0.5:8080");
        assert_eq!(auth.unwrap(), "Basic dXNlcjpwYXNz");
    }

    #[test]
    fn failures_hidden_in_a_200_answer_are_spotted() {
        assert_eq!(failure_in_body(r#"{"success":false,"error":"No SIM"}"#), "No SIM");
        assert_eq!(failure_in_body(r#"{"ok":false,"message":"nope"}"#), "nope");
        assert_eq!(failure_in_body(r#"{"status":"failed","detail":"x"}"#), "x");
        assert_eq!(failure_in_body(r#"{"success":true}"#), "");
        assert_eq!(failure_in_body("plain text"), "");
        assert!(hint_for("no permission").contains("permission"));
    }

    #[test]
    fn attempt_list_has_the_expected_shape() {
        let a = attempts();
        // "plus" and "digits" try 10 APIs each, "local" skips the 4 that insist on international numbers
        assert_eq!(a.len(), 10 + 10 + 6);
        assert_eq!(a[0].label, "send-sms/json/plus");
        assert!(a.iter().filter(|x| x.phone == "local").all(|x| !x.body.starts_with("capcom")));
    }

    /// A tiny fake gateway: answers 404 to everything except POST /send-sms (JSON body), which it accepts.
    fn fake_gateway() -> (String, std::thread::JoinHandle<Vec<String>>) {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let h = std::thread::spawn(move || {
            let mut seen = Vec::new();
            listener.set_nonblocking(false).unwrap();
            for stream in listener.incoming().take(3) {
                let mut s = stream.unwrap();
                let mut buf = [0u8; 4096];
                let n = s.read(&mut buf).unwrap();
                let req = String::from_utf8_lossy(&buf[..n]).to_string();
                let first = req.lines().next().unwrap_or("").to_string();
                seen.push(first.clone());
                let ok = first.starts_with("POST /send-sms") && req.contains("application/json");
                let (status, body) = if ok { ("200 OK", r#"{"success":true}"#) } else { ("404 Not Found", "nope") };
                let resp = format!("HTTP/1.1 {status}\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len());
                s.write_all(resp.as_bytes()).unwrap();
                if ok {
                    break;
                }
            }
            seen
        });
        (format!("127.0.0.1:{}", addr.port()), h)
    }

    #[test]
    fn sends_through_a_fake_gateway_and_learns_the_mode() {
        let (addr, h) = fake_gateway();
        let cfg = Cfg { sms_url: addr, ..Cfg::default() };
        let gw = Gateway::default();
        let stop = AtomicBool::new(false);
        gw.send(&stop, &cfg, "919994452985", "Hello there").unwrap();
        assert_eq!(gw.learned(), "send-sms/json/plus");
        let seen = h.join().unwrap();
        assert!(seen.last().unwrap().starts_with("POST /send-sms"));
    }

    #[test]
    fn unreachable_gateway_gives_a_helpful_error() {
        let cfg = Cfg { sms_url: "127.0.0.1:1".into(), ..Cfg::default() };
        let err = Gateway::default().send(&AtomicBool::new(false), &cfg, "919994452985", "x").unwrap_err();
        assert!(err.contains("cannot reach"), "{err}");
    }
}
