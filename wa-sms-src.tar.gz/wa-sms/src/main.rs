// Wa-sms 3.0 - WhatsApp / SMS review counts for branch managers. Developed by Rocklin K S.
// Rust rewrite: no send history (a message can always be sent again), WhatsApp shows as Chrome,
// no chat history is requested or stored.

mod app;
mod branches;
mod config;
mod contacts;
mod excel;
mod launcher;
mod plan;
mod sms;
mod textbuf;
mod theme;
mod util;
mod wa;

const HELP: &str = "Wa-sms 3.0 - developed by Rocklin K S

Usage: wa-sms [install | uninstall | -h | -v]

  (none)      start the program
  install     add 'Wa-sms' to the applications menu
  uninstall   remove it again

Data folder: WA_SMS_DATA, else 'data' next to the program, else ~/.local/share/wa-sms";

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.first().map(String::as_str) {
        Some("install") => return launcher::cmd_install(),
        Some("uninstall") => {
            launcher::uninstall_launcher();
            println!("Launcher removed.");
            return;
        }
        Some("-h") | Some("--help") | Some("help") => return println!("{HELP}"),
        Some("-v") | Some("--version") | Some("version") => return println!("wa-sms 3.0.0 - developed by Rocklin K S"),
        Some(other) => {
            println!("Unknown option: {other}\n\n{HELP}");
            std::process::exit(2);
        }
        None => {}
    }

    std::panic::set_hook(Box::new(|info| {
        config::append_log("crash.log", &format!("{} {info}", chrono::Local::now().format("%Y-%m-%d %H:%M:%S")));
    }));

    let (store, problem) = config::Store::open();
    let app = app::App::new(store, problem);
    let terminal = ratatui::init();
    let res = app::run(terminal, app);
    ratatui::restore();
    if let Err(e) = res {
        eprintln!("error: {e}");
        std::process::exit(1);
    }
}
