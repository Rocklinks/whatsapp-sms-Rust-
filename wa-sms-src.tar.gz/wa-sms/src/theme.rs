// Colour themes: the built-in presets, the colours of the desktop (KDE/Qt or GTK/GNOME) and a
// custom one written in config.json ("custom_theme").

use ratatui::style::Color;
use regex::Regex;
use std::collections::{BTreeMap, HashMap};
use std::path::{Path, PathBuf};
use std::time::Duration;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub struct Rgb(pub u8, pub u8, pub u8);

impl Rgb {
    pub fn c(self) -> Color {
        Color::Rgb(self.0, self.1, self.2)
    }

    pub fn hex(self) -> String {
        format!("#{:02x}{:02x}{:02x}", self.0, self.1, self.2)
    }

    fn lum(self) -> f64 {
        (0.2126 * f64::from(self.0) + 0.7152 * f64::from(self.1) + 0.0722 * f64::from(self.2)) / 255.0
    }
}

pub fn mix(a: Rgb, b: Rgb, t: f64) -> Rgb {
    let f = |x: u8, y: u8| (f64::from(x) * (1.0 - t) + f64::from(y) * t + 0.5) as u8;
    Rgb(f(a.0, b.0), f(a.1, b.1), f(a.2, b.2))
}

pub fn parse_hex(s: &str) -> Option<Rgb> {
    let s = s.trim().trim_start_matches('#').trim();
    let s: String = if s.len() == 3 { s.chars().flat_map(|c| [c, c]).collect() } else { s.to_string() };
    if s.len() != 6 || !s.is_ascii() {
        return None;
    }
    let v = u32::from_str_radix(&s, 16).ok()?;
    Some(Rgb((v >> 16) as u8, (v >> 8 & 255) as u8, (v & 255) as u8))
}

#[derive(Clone, Debug)]
pub struct Theme {
    pub name: String,
    pub bg: Rgb,
    pub panel: Rgb,
    pub line: Rgb,
    pub fg: Rgb,
    pub dim: Rgb,
    pub accent: Rgb,
    pub ok: Rgb,
    pub warn: Rgb,
    pub err: Rgb,
}

fn rgb(s: &str) -> Rgb {
    parse_hex(s).unwrap_or_default()
}

fn preset(n: &str, a: [&str; 9]) -> Theme {
    Theme {
        name: n.into(),
        bg: rgb(a[0]),
        panel: rgb(a[1]),
        line: rgb(a[2]),
        fg: rgb(a[3]),
        dim: rgb(a[4]),
        accent: rgb(a[5]),
        ok: rgb(a[6]),
        warn: rgb(a[7]),
        err: rgb(a[8]),
    }
}

pub fn presets() -> Vec<Theme> {
    vec![
        preset("Catppuccin Mocha", ["#1e1e2e", "#242438", "#313244", "#cdd6f4", "#9399b2", "#89b4fa", "#a6e3a1", "#f9e2af", "#f38ba8"]),
        preset("Tokyo Night", ["#1a1b26", "#1f2335", "#2f3549", "#c0caf5", "#7a88b8", "#7aa2f7", "#9ece6a", "#e0af68", "#f7768e"]),
        preset("Catppuccin Macchiato", ["#24273a", "#2a2e45", "#363a4f", "#cad3f5", "#939ab7", "#8aadf4", "#a6da95", "#eed49f", "#ed8796"]),
        preset("Catppuccin Frappe", ["#303446", "#363a50", "#414559", "#c6d0f5", "#949cbb", "#8caaee", "#a6d189", "#e5c890", "#e78284"]),
        preset("Gruvbox", ["#282828", "#32302f", "#3c3836", "#ebdbb2", "#a89984", "#83a598", "#b8bb26", "#fabd2f", "#fb4934"]),
        preset("Solarized Dark", ["#002b36", "#073642", "#0d4452", "#93a1a1", "#657b83", "#268bd2", "#859900", "#b58900", "#dc322f"]),
        preset("Nord", ["#2e3440", "#3b4252", "#434c5e", "#e5e9f0", "#9aa5b8", "#88c0d0", "#a3be8c", "#ebcb8b", "#bf616a"]),
        preset("Catppuccin Latte", ["#eff1f5", "#e6e9ef", "#ccd0da", "#4c4f69", "#6c6f85", "#1e66f5", "#40a02b", "#df8e1d", "#d20f39"]),
    ]
}

/// Builds a theme from config hex values; None if none given.
pub fn custom_theme(m: &BTreeMap<String, String>) -> Option<Theme> {
    if m.is_empty() {
        return None;
    }
    let all = presets();
    let light = m.get("bg").and_then(|s| parse_hex(s)).map(|c| c.lum() > 0.5).unwrap_or(false);
    let mut t = if light { all[7].clone() } else { all[0].clone() };
    t.name = "Custom".into();
    let mut set = |key: &str, slot: &mut Rgb| {
        if let Some(c) = m.get(key).and_then(|s| parse_hex(s)) {
            *slot = c;
        }
    };
    set("bg", &mut t.bg);
    set("panel", &mut t.panel);
    set("line", &mut t.line);
    set("fg", &mut t.fg);
    set("dim", &mut t.dim);
    set("accent", &mut t.accent);
    set("ok", &mut t.ok);
    set("warn", &mut t.warn);
    set("err", &mut t.err);
    Some(t)
}

// ---------- system theme (KDE/Qt colors, GTK / GNOME) ----------

fn run1(name: &str, args: &[&str]) -> String {
    let (name, args): (String, Vec<String>) = (name.to_string(), args.iter().map(|s| s.to_string()).collect());
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let out = std::process::Command::new(name).args(args).stdin(std::process::Stdio::null()).output();
        let _ = tx.send(out);
    });
    match rx.recv_timeout(Duration::from_millis(1500)) {
        Ok(Ok(o)) if o.status.success() => String::from_utf8_lossy(&o.stdout).trim().trim_matches(|c| c == '\'' || c == '"').to_string(),
        _ => String::new(),
    }
}

fn read_ini(p: &Path) -> Option<HashMap<String, HashMap<String, String>>> {
    let text = std::fs::read_to_string(p).ok()?;
    let mut m: HashMap<String, HashMap<String, String>> = HashMap::new();
    let mut sec = String::new();
    for ln in text.lines() {
        let ln = ln.trim();
        if ln.starts_with('[') && ln.ends_with(']') {
            sec = ln[1..ln.len() - 1].to_string();
            m.entry(sec.clone()).or_default();
        } else if let Some(i) = ln.find('=') {
            if i > 0 && !sec.is_empty() {
                m.entry(sec.clone()).or_default().insert(ln[..i].trim().to_string(), ln[i + 1..].trim().to_string());
            }
        }
    }
    Some(m)
}

fn rgb_list(s: &str) -> Option<Rgb> {
    let p: Vec<&str> = s.split(',').collect();
    if p.len() < 3 {
        return None;
    }
    let n = |x: &str| x.trim().parse::<u8>().ok();
    Some(Rgb(n(p[0])?, n(p[1])?, n(p[2])?))
}

fn from_kde() -> Option<Theme> {
    let home = std::env::var_os("HOME").map(PathBuf::from).unwrap_or_default();
    let cfg = std::env::var_os("XDG_CONFIG_HOME").filter(|s| !s.is_empty()).map(PathBuf::from).unwrap_or_else(|| home.join(".config"));
    let ini = read_ini(&cfg.join("kdeglobals"))?;
    let get = |sec: &str, key: &str| -> Option<Rgb> { ini.get(sec).and_then(|s| s.get(key)).and_then(|v| rgb_list(v)) };
    let bg = get("Colors:Window", "BackgroundNormal")?;
    let fg = get("Colors:Window", "ForegroundNormal")?;
    let panel = get("Colors:View", "BackgroundNormal").unwrap_or_else(|| mix(bg, fg, 0.05));
    let accent = get("Colors:Selection", "BackgroundNormal").or_else(|| get("Colors:Window", "DecorationFocus")).unwrap_or_else(|| rgb("#3daee9"));
    let pick = |key: &str, def: &str| get("Colors:View", key).unwrap_or_else(|| rgb(def));
    Some(Theme {
        name: "System (Qt/KDE)".into(),
        bg,
        panel,
        line: mix(bg, fg, 0.15),
        fg,
        dim: mix(fg, bg, 0.45),
        accent,
        ok: pick("ForegroundPositive", "#27ae60"),
        warn: pick("ForegroundNeutral", "#f67400"),
        err: pick("ForegroundNegative", "#da4453"),
    })
}

fn css_colors(p: &Path) -> HashMap<String, Rgb> {
    let Ok(text) = std::fs::read_to_string(p) else { return HashMap::new() };
    let re = Regex::new(r"@define-color\s+([\w\-]+)\s+([^;]+);").unwrap();
    let raw: HashMap<String, String> = re.captures_iter(&text).map(|c| (c[1].to_string(), c[2].trim().to_string())).collect();
    fn res(raw: &HashMap<String, String>, k: &str, d: u8) -> Option<Rgb> {
        let v = raw.get(k)?;
        if d > 5 {
            return None;
        }
        if let Some(r) = v.strip_prefix('@') {
            return res(raw, r, d + 1);
        }
        if v.starts_with('#') {
            return parse_hex(v);
        }
        if let Some(inner) = v.strip_prefix("rgb(") {
            return rgb_list(inner.trim_end_matches(')'));
        }
        None
    }
    raw.keys().filter_map(|k| res(&raw, k, 0).map(|c| (k.clone(), c))).collect()
}

fn gnome_accent(name: &str) -> Option<&'static str> {
    Some(match name {
        "blue" => "#3584e4",
        "teal" => "#2190a4",
        "green" => "#3a944a",
        "yellow" => "#c88800",
        "orange" => "#ed5b00",
        "red" => "#e62d42",
        "pink" => "#d56199",
        "purple" => "#9141ac",
        "slate" => "#6f8396",
        _ => return None,
    })
}

fn from_gtk() -> Theme {
    let home = std::env::var_os("HOME").map(PathBuf::from).unwrap_or_default();
    let mut name = run1("gsettings", &["get", "org.gnome.desktop.interface", "gtk-theme"]);
    let scheme = run1("gsettings", &["get", "org.gnome.desktop.interface", "color-scheme"]);
    let accent = run1("gsettings", &["get", "org.gnome.desktop.interface", "accent-color"]);
    let mut dark = scheme == "prefer-dark";
    if let Some(ini) = read_ini(&home.join(".config/gtk-3.0/settings.ini")) {
        if let Some(s) = ini.get("Settings") {
            if name.is_empty() {
                name = s.get("gtk-theme-name").cloned().unwrap_or_default();
            }
            let prefer = s.get("gtk-application-prefer-dark-theme").map(String::as_str);
            if (scheme.is_empty() || scheme == "default") && (prefer == Some("true") || prefer == Some("1")) {
                dark = true;
            }
        }
    }
    if name.is_empty() {
        name = std::env::var("GTK_THEME").unwrap_or_default();
    }
    if name.to_lowercase().contains("dark") || name.ends_with(":dark") {
        dark = true;
    }
    let base = name.split(':').next().unwrap_or("").to_string();
    let mut cs: HashMap<String, Rgb> = HashMap::new();
    'dirs: for dir in [home.join(".themes"), home.join(".local/share/themes"), PathBuf::from("/usr/share/themes")] {
        for f in ["gtk-3.0/gtk.css", "gtk-3.0/gtk-dark.css"] {
            if dark && f == "gtk-3.0/gtk.css" {
                let m = css_colors(&dir.join(&base).join("gtk-3.0/gtk-dark.css"));
                if !m.is_empty() {
                    cs = m;
                    break 'dirs;
                }
            }
            let m = css_colors(&dir.join(&base).join(f));
            if !m.is_empty() {
                cs = m;
                break 'dirs;
            }
        }
    }
    let pick = |def: Rgb, keys: &[&str]| -> Rgb { keys.iter().find_map(|k| cs.get(*k).copied()).unwrap_or(def) };
    let mut t = if dark {
        Theme { name: String::new(), bg: rgb("#242424"), panel: rgb("#1e1e1e"), line: Rgb::default(), fg: rgb("#ffffff"), dim: Rgb::default(), accent: rgb("#3584e4"), ok: rgb("#57e389"), warn: rgb("#f8e45c"), err: rgb("#ff7b63") }
    } else {
        Theme { name: String::new(), bg: rgb("#fafafa"), panel: rgb("#ffffff"), line: Rgb::default(), fg: rgb("#2e3436"), dim: Rgb::default(), accent: rgb("#3584e4"), ok: rgb("#26a269"), warn: rgb("#cd9309"), err: rgb("#c01c28") }
    };
    t.name = if cs.is_empty() { "System (GTK)".into() } else { format!("System (GTK: {base})") };
    t.bg = pick(t.bg, &["theme_bg_color", "window_bg_color"]);
    t.panel = pick(t.panel, &["theme_base_color", "view_bg_color"]);
    t.fg = pick(t.fg, &["theme_fg_color", "window_fg_color"]);
    t.accent = pick(t.accent, &["theme_selected_bg_color", "accent_bg_color"]);
    t.ok = pick(t.ok, &["success_color"]);
    t.warn = pick(t.warn, &["warning_color"]);
    t.err = pick(t.err, &["error_color"]);
    if cs.is_empty() {
        if let Some(a) = gnome_accent(&accent) {
            t.accent = rgb(a);
        }
    }
    t.line = mix(t.bg, t.fg, 0.15);
    t.dim = mix(t.fg, t.bg, 0.45);
    t
}

pub fn system_theme() -> Theme {
    let d = std::env::var("XDG_CURRENT_DESKTOP").unwrap_or_default().to_lowercase();
    if d.contains("kde") || std::env::var_os("KDE_FULL_SESSION").is_some() {
        if let Some(t) = from_kde() {
            return t;
        }
    }
    if !d.contains("gnome") {
        if let Some(t) = from_kde() {
            return t;
        }
    }
    from_gtk()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hex_parsing() {
        assert_eq!(parse_hex("#1a1b26"), Some(Rgb(0x1a, 0x1b, 0x26)));
        assert_eq!(parse_hex("fff"), Some(Rgb(255, 255, 255)));
        assert_eq!(parse_hex("nope"), None);
        assert_eq!(Rgb(1, 2, 255).hex(), "#0102ff");
    }

    #[test]
    fn custom_theme_overrides_a_base() {
        let mut m = BTreeMap::new();
        assert!(custom_theme(&m).is_none());
        m.insert("bg".to_string(), "#ffffff".to_string());
        m.insert("accent".to_string(), "#ff0000".to_string());
        let t = custom_theme(&m).unwrap();
        assert_eq!(t.name, "Custom");
        assert_eq!(t.accent, Rgb(255, 0, 0));
        assert_eq!(t.fg, presets()[7].fg); // light base chosen because bg is light
    }

    #[test]
    fn eight_presets() {
        assert_eq!(presets().len(), 8);
    }
}
