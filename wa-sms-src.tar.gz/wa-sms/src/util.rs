use unicode_width::{UnicodeWidthChar, UnicodeWidthStr};

/// Shortens text to `n` characters and adds "..." when something was cut off.
pub fn trunc(s: &str, n: usize) -> String {
    let r: Vec<char> = s.chars().collect();
    if r.len() > n {
        let mut out: String = r[..n].iter().collect();
        out.push_str("...");
        out
    } else {
        s.to_string()
    }
}

/// Puts a text on a single line and shortens it.
pub fn one_line(s: &str, n: usize) -> String {
    trunc(&s.split_whitespace().collect::<Vec<_>>().join(" "), n)
}

/// Shortens text so that it is at most `n` characters long, including the "..." at the end.
pub fn fit(s: &str, n: usize) -> String {
    let s = s.split_whitespace().collect::<Vec<_>>().join(" ");
    let r: Vec<char> = s.chars().collect();
    if r.len() <= n {
        return s;
    }
    let keep = n.saturating_sub(3).max(1);
    let mut out: String = r[..keep].iter().collect();
    out.push_str("...");
    out
}

pub fn digits_only(s: &str) -> String {
    s.chars().filter(|c| c.is_ascii_digit()).collect()
}

pub fn width(s: &str) -> usize {
    UnicodeWidthStr::width(s)
}

/// Cuts a text so that its display width is at most `w` columns.
pub fn clip(s: &str, w: usize) -> String {
    let mut out = String::new();
    let mut used = 0;
    for c in s.chars() {
        let cw = UnicodeWidthChar::width(c).unwrap_or(0);
        if used + cw > w {
            break;
        }
        used += cw;
        out.push(c);
    }
    out
}

/// Pads (or cuts) a text to exactly `w` display columns.
pub fn pad(s: &str, w: usize) -> String {
    let mut out = clip(s, w);
    let used = width(&out);
    for _ in used..w {
        out.push(' ');
    }
    out
}

pub fn b64(data: &[u8]) -> String {
    const T: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(data.len().div_ceil(3) * 4);
    for chunk in data.chunks(3) {
        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
        let n = (u32::from(b[0]) << 16) | (u32::from(b[1]) << 8) | u32::from(b[2]);
        out.push(T[(n >> 18) as usize & 63] as char);
        out.push(T[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 { T[(n >> 6) as usize & 63] as char } else { '=' });
        out.push(if chunk.len() > 2 { T[n as usize & 63] as char } else { '=' });
    }
    out
}

/// Percent-encodes like Go's url.QueryEscape (space becomes '+').
pub fn query_escape(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => out.push(b as char),
            b' ' => out.push('+'),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

pub fn seconds(d: std::time::Duration) -> String {
    format!("{:.1} s", d.as_secs_f64())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trunc_and_fit() {
        assert_eq!(trunc("abcdef", 3), "abc...");
        assert_eq!(trunc("abc", 3), "abc");
        assert_eq!(fit("a  b   c", 10), "a b c");
        assert_eq!(fit("abcdefghij", 6), "abc...");
    }

    #[test]
    fn base64_matches_known_vectors() {
        assert_eq!(b64(b""), "");
        assert_eq!(b64(b"f"), "Zg==");
        assert_eq!(b64(b"fo"), "Zm8=");
        assert_eq!(b64(b"foo"), "Zm9v");
        assert_eq!(b64(b"user:pass"), "dXNlcjpwYXNz");
    }

    #[test]
    fn query_escape_like_go() {
        assert_eq!(query_escape("+91 99"), "%2B91+99");
        assert_eq!(query_escape("a&b=c"), "a%26b%3Dc");
    }
}
