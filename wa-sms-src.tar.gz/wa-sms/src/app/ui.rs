// Everything you see and click: the main screen, the dialogs and the mouse.

use super::*;
use ratatui::style::Color;

#[derive(Clone, Copy, PartialEq)]
enum Tone {
    Normal,
    Dim,
    Ok,
    Warn,
    Err,
}

fn tone(t: Tone, th: &Theme) -> Rgb {
    match t {
        Tone::Normal => th.fg,
        Tone::Dim => th.dim,
        Tone::Ok => th.ok,
        Tone::Warn => th.warn,
        Tone::Err => th.err,
    }
}

fn sty(fg: Rgb, bg: Rgb) -> Style {
    Style::default().fg(fg.c()).bg(bg.c())
}

/// Builds one line of text and buttons and remembers where every button is.
struct Bld {
    x: u16,
    y: u16,
    base: Style,
    spans: Vec<Span<'static>>,
    hits: Vec<(Rect, Hit)>,
}

impl Bld {
    fn new(r: Rect, base: Style) -> Bld {
        Bld { x: r.x, y: r.y, base, spans: vec![], hits: vec![] }
    }

    fn text(&mut self, s: impl Into<String>, st: Style) {
        let s: String = s.into();
        self.x += width(&s) as u16;
        self.spans.push(Span::styled(s, st));
    }

    fn gap(&mut self) {
        self.text(" ", self.base);
    }

    fn btn(&mut self, label: &str, st: Style, h: Hit) {
        let s = format!(" {label} ");
        let w = width(&s) as u16;
        self.hits.push((Rect { x: self.x, y: self.y, width: w, height: 1 }, h));
        self.x += w;
        self.spans.push(Span::styled(s, st));
        self.gap();
    }
}

fn text_h(s: &str, w: usize) -> u16 {
    s.lines().map(|l| (width(l) / w.max(1) + 1) as u16).sum::<u16>().max(1)
}

fn popup(f: &mut Frame, area: Rect, w: u16, h: u16, title: &str, th: &Theme) -> Rect {
    let w = w.min(area.width);
    let h = h.min(area.height);
    let r = Rect { x: area.x + (area.width - w) / 2, y: area.y + (area.height - h) / 2, width: w, height: h };
    f.render_widget(Clear, r);
    let blk = Block::default()
        .borders(Borders::ALL)
        .border_style(sty(th.accent, th.panel))
        .title(Span::styled(format!(" {title} "), sty(th.bg, th.accent).add_modifier(Modifier::BOLD)))
        .style(sty(th.fg, th.panel));
    f.render_widget(blk, r);
    r
}

fn inner_of(r: Rect) -> Rect {
    Rect { x: r.x + 2, y: r.y + 1, width: r.width.saturating_sub(4), height: r.height.saturating_sub(2) }
}

fn pad_center(s: &str, w: usize) -> String {
    let n = width(s);
    if n >= w {
        return clip(s, w);
    }
    let l = (w - n) / 2;
    format!("{}{}{}", " ".repeat(l), s, " ".repeat(w - n - l))
}

/// A row of dialog buttons in the last line of `r`, centred. kind: 0 normal, 1 main (green), 2 danger.
fn mbuttons(f: &mut Frame, r: Rect, items: &[(String, KeyCode, KeyModifiers, u8)], th: &Theme, mh: &mut Vec<(Rect, MHit)>) {
    let total: usize = items.iter().map(|i| width(&i.0) + 3).sum();
    let mut x = r.x + (r.width as usize).saturating_sub(total) as u16 / 2;
    let y = r.y + r.height.saturating_sub(1);
    let mut spans = vec![];
    for (label, code, mods, kind) in items {
        let s = format!(" {label} ");
        let w = width(&s) as u16;
        mh.push((Rect { x, y, width: w, height: 1 }, MHit::Key(*code, *mods)));
        let st = match kind {
            1 => sty(th.bg, th.ok).add_modifier(Modifier::BOLD),
            2 => sty(th.bg, th.err).add_modifier(Modifier::BOLD),
            _ => sty(th.accent, th.line).add_modifier(Modifier::BOLD),
        };
        spans.push(Span::styled(s, st));
        spans.push(Span::styled("  ", sty(th.fg, th.panel)));
        x += w + 2;
    }
    let line_r = Rect { x: r.x, y, width: r.width, height: 1 };
    f.render_widget(Paragraph::new(Line::from(spans)).alignment(ratatui::layout::Alignment::Center).style(sty(th.fg, th.panel)), line_r);
}

fn b(label: &str, code: KeyCode, kind: u8) -> (String, KeyCode, KeyModifiers, u8) {
    (label.to_string(), code, KeyModifiers::NONE, kind)
}

const HELP: &str = "\
 HOW TO SEND  -  five steps, from top to bottom (everything can be clicked)

  1 FILES     Browse the Excel file (branches + Reviews) and the contacts file.
  2 MESSAGE   Template (fills {branch} and {reviews}) or your own Custom message.
              With Custom you may also choose a file (optional): video, audio,
              picture or document is detected and sent as such (SMS: text only).
  3 SEND VIA  Tick WhatsApp, SMS, or both. 'Test SMS gateway' checks the phone app.
  4 SEND TO   Tick who gets it: BM, ASM, CRM ... Only the ticked roles get a message.
              If AGM is not ticked you are asked once whether to add it.
  5 BRANCHES  Click rows to tick them, or Select all / Unselect all.
  Then press the big green SEND button.

 KEYS   W WhatsApp   S SMS   M message type   E edit text   F choose file
        B Excel   K contacts file   A select all   N unselect all   G test gateway
        1-9 roles   Space tick row   Up/Down/PageUp/PageDown move
        T theme   O settings   C contacts   Z zero reviews   R reload   L link WhatsApp
        Ctrl+S or F5 send   Esc stop sending   H help   Ctrl+Q quit

 Messages can always be sent again: nothing is remembered about what was sent,
 and no chat history is kept. WhatsApp sees this computer as Google Chrome.

 Wa-sms - developed by Rocklin K S";

impl App {
    // ---------------- mouse ----------------

    pub(super) fn on_mouse(&mut self, kind: MouseEventKind, col: u16, row: u16) {
        let inside = |r: &Rect| col >= r.x && col < r.x + r.width && row >= r.y && row < r.y + r.height;
        match kind {
            MouseEventKind::Down(MouseButton::Left) => {
                if self.modal.is_some() {
                    let hit = self.mhits.iter().find(|(r, _)| inside(r)).map(|(_, h)| *h);
                    match hit {
                        Some(MHit::Key(c, m)) => self.modal_key(KeyEvent::new(c, m)),
                        Some(MHit::Row(i)) => self.modal_row(i),
                        None => {}
                    }
                    return;
                }
                let hit = self.hits.iter().find(|(r, _)| inside(r)).map(|(_, h)| *h);
                if let Some(h) = hit {
                    self.do_hit(h);
                }
            }
            MouseEventKind::ScrollDown | MouseEventKind::ScrollUp => {
                let down = matches!(kind, MouseEventKind::ScrollDown);
                if self.modal.is_some() {
                    for _ in 0..3 {
                        self.modal_key(KeyEvent::new(if down { KeyCode::Down } else { KeyCode::Up }, KeyModifiers::NONE));
                    }
                } else if down {
                    self.sel = (self.sel + 3).min(self.rows.len().saturating_sub(1));
                } else {
                    self.sel = self.sel.saturating_sub(3);
                }
            }
            _ => {}
        }
    }

    fn do_hit(&mut self, h: Hit) {
        match h {
            Hit::Mode(m) => self.set_mode(m as usize),
            Hit::Wa => self.toggle_channel(true),
            Hit::Sms => self.toggle_channel(false),
            Hit::Role(i) => self.toggle_role(i),
            Hit::Attach => self.open_browser(Target::Attach),
            Hit::Remove => {
                self.store.cfg.attachment.clear();
                self.att_info.clear();
                self.save();
            }
            Hit::Excel => self.open_browser(Target::Excel),
            Hit::Contacts => self.open_browser(Target::Contacts),
            Hit::EditText => self.edit_message(),
            Hit::Check => self.check_gateway(),
            Hit::LinkWa => self.open_link(),
            Hit::All(v) => self.rows.iter_mut().for_each(|r| r.ticked = v),
            Hit::Send => self.begin_send(true),
            Hit::Stop => {
                self.stop.store(true, Ordering::SeqCst);
                self.live.recent.push("Stopping after the current message...".into());
            }
            Hit::Theme => self.open_themes(),
            Hit::Settings => self.modal = Some(Modal::Settings(0)),
            Hit::ContactsList => self.modal = Some(Modal::Contacts(0)),
            Hit::Zero => self.modal = Some(Modal::Zero(0)),
            Hit::Reload => {
                self.reload_data();
                self.refresh_att();
                let t = match (&self.excel_err, &self.contacts_err) {
                    (Some(e), _) => e.clone(),
                    (_, Some(e)) => e.clone(),
                    _ => format!("Reloaded: {} branches, {} people.", self.rows.len(), self.contacts.len()),
                };
                self.alert("Reload", t);
            }
            Hit::Help => self.modal = Some(Modal::Help),
            Hit::Quit => self.modal = Some(Modal::Confirm("Quit".into(), "Close Wa-sms?".into(), Act::Quit)),
            Hit::Row(i) => {
                if let Some(r) = self.rows.get_mut(i) {
                    r.ticked = !r.ticked;
                    self.sel = i;
                }
            }
        }
    }

    /// A click on a list row inside a dialog.
    fn modal_row(&mut self, i: usize) {
        match self.modal.take() {
            Some(Modal::Browse(mut br)) => {
                br.sel = i.min(br.entries.len().saturating_sub(1));
                self.modal = Some(Modal::Browse(br));
                self.modal_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));
            }
            Some(Modal::Settings(_)) => {
                self.modal = Some(Modal::Settings(i));
                self.modal_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));
            }
            Some(Modal::Contacts(_)) => self.modal = Some(Modal::Contacts(i)),
            Some(Modal::Zero(_)) => self.modal = Some(Modal::Zero(i)),
            Some(Modal::Themes { old, .. }) => {
                if let Some((_, k)) = self.theme_list().get(i) {
                    self.store.cfg.theme = k.clone();
                }
                self.modal = Some(Modal::Themes { sel: i, old });
            }
            other => self.modal = other,
        }
    }

    // ---------------- main screen ----------------

    fn send_state(&self) -> (usize, Option<String>) {
        let c = self.cfg();
        let why = |s: &str| (0, Some(s.to_string()));
        if self.rows.is_empty() {
            return why("choose the Excel file (step 1)");
        }
        if !c.use_wa && !c.use_sms {
            return why("tick WhatsApp or SMS (step 3)");
        }
        if c.mode == "custom" && c.custom.trim().is_empty() && !self.with_attachment() {
            return why("write your message (step 2)");
        }
        let roles = role_set(&c.send_roles);
        if roles.is_empty() {
            return why("tick who to send to (step 4)");
        }
        if !self.rows.iter().any(|r| r.ticked) {
            return why("tick the branches (step 5)");
        }
        let plan = build_plan(&self.rows, c, &roles);
        if plan.jobs.is_empty() {
            return why("nobody to send to for these branches and roles");
        }
        (plan.jobs.len(), None)
    }

    fn row_status(&self, row: &Row) -> (String, Tone) {
        let roles = self.ticked_roles();
        let ppl: Vec<_> = row.people.iter().filter(|p| roles.iter().any(|r| r.eq_ignore_ascii_case(&p.contact.role))).collect();
        if ppl.is_empty() {
            return ("-".into(), Tone::Dim);
        }
        let sent = ppl.iter().filter(|p| p.state == SendState::Sent).count();
        let failed = ppl.iter().filter(|p| p.state == SendState::Failed).count();
        if failed > 0 {
            (format!("Failed {failed}"), Tone::Err)
        } else if sent == ppl.len() {
            ("Sent".into(), Tone::Ok)
        } else if sent > 0 {
            (format!("Sent {sent}/{}", ppl.len()), Tone::Warn)
        } else {
            (String::new(), Tone::Normal)
        }
    }

    pub(super) fn draw(&mut self, f: &mut Frame) {
        let th = self.theme();
        let area = f.area();
        f.render_widget(Block::default().style(sty(th.fg, th.bg)), area);
        self.hits.clear();
        if area.width < 76 || area.height < 24 {
            f.render_widget(Paragraph::new("Please make this window bigger (at least 76 x 24).").style(sty(th.warn, th.bg)), area);
            self.mhits.clear();
            return;
        }
        let one = Constraint::Length(1);
        let ch = Layout::vertical([one, one, one, one, one, one, one, one, one, Constraint::Min(4), one, Constraint::Length(4), Constraint::Length(3), one]).split(area);
        self.draw_title(f, ch[0], &th);
        self.draw_files(f, ch[1], ch[2], &th);
        self.draw_message(f, ch[3], ch[4], ch[5], &th);
        self.draw_via(f, ch[6], &th);
        self.draw_to(f, ch[7], &th);
        self.draw_branches_bar(f, ch[8], &th);
        if area.width >= 96 {
            let sp = Layout::horizontal([Constraint::Min(60), Constraint::Length(32)]).split(ch[9]);
            self.draw_table(f, sp[0], &th);
            self.draw_zero_panel(f, sp[1], &th);
        } else {
            self.draw_table(f, ch[9], &th);
        }
        self.draw_detail(f, ch[10], &th);
        self.draw_status(f, ch[11], &th);
        self.draw_send(f, ch[12], &th);
        self.draw_toolbar(f, ch[13], &th);
        self.draw_modal(f, area, &th);
    }

    fn put(&mut self, f: &mut Frame, r: Rect, bl: Bld) {
        f.render_widget(Paragraph::new(Line::from(bl.spans)).style(bl.base), r);
        self.hits.extend(bl.hits);
    }

    fn label(bl: &mut Bld, n: &str, name: &str, th: &Theme) {
        if n.is_empty() {
            bl.text(" ".repeat(13), bl.base);
        } else {
            bl.text(format!(" {n} "), sty(th.bg, th.accent).add_modifier(Modifier::BOLD));
            bl.text(format!(" {:<9}", name), sty(th.accent, th.bg).add_modifier(Modifier::BOLD));
        }
    }

    fn draw_title(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let base = sty(th.fg, th.panel);
        let mut bl = Bld::new(r, base);
        bl.text(" Wa-sms ", sty(th.bg, th.accent).add_modifier(Modifier::BOLD));
        bl.text(" developed by Rocklin K S", sty(th.dim, th.panel));
        let (wa_txt, wa_st) = if self.wa.connected() {
            ("WhatsApp: connected".to_string(), sty(th.bg, th.ok))
        } else if self.wa.linked() {
            (format!("WhatsApp: {}", self.wa.status()), sty(th.bg, th.warn))
        } else {
            ("WhatsApp: not linked - click to link".to_string(), sty(th.bg, th.warn))
        };
        let sms_txt = if self.cfg().use_sms { format!("SMS: {}", fit(&self.cfg().sms_url, 22)) } else { "SMS: off".to_string() };
        let right = width(&wa_txt) + width(&sms_txt) + 8;
        let fill = (r.width as usize).saturating_sub(bl.x as usize - r.x as usize + right);
        bl.text(" ".repeat(fill), base);
        bl.btn(&wa_txt, wa_st.add_modifier(Modifier::BOLD), Hit::LinkWa);
        bl.btn(&sms_txt, sty(th.fg, th.line), Hit::Check);
        self.put(f, r, bl);
    }

    fn draw_files(&mut self, f: &mut Frame, r1: Rect, r2: Rect, th: &Theme) {
        let base = sty(th.fg, th.bg);
        let btn = sty(th.accent, th.line).add_modifier(Modifier::BOLD);
        let c = self.cfg().clone();
        let room = (r1.width as usize).saturating_sub(13 + 10 + 20 + 2);
        let mut a = Bld::new(r1, base);
        Self::label(&mut a, "1", "FILES", th);
        a.text("Excel    ", sty(th.dim, th.bg));
        a.btn("Browse Excel... (B)", btn, Hit::Excel);
        match &self.excel_err {
            Some(e) => a.text(fit(e, room), sty(th.warn, th.bg)),
            None => a.text(fit(&format!("{}  ({} branches) {}", c.excel_file, self.rows.len(), self.excel_note), room), sty(th.fg, th.bg)),
        }
        self.put(f, r1, a);
        let mut b2 = Bld::new(r2, base);
        Self::label(&mut b2, "", "", th);
        b2.text("Contacts ", sty(th.dim, th.bg));
        b2.btn("Browse Contacts... (K)", btn, Hit::Contacts);
        let room = (r2.width as usize).saturating_sub(13 + 10 + 24 + 2);
        match &self.contacts_err {
            Some(e) => b2.text(fit(e, room), sty(th.warn, th.bg)),
            None => b2.text(fit(&format!("{}  ({} people)", c.contacts_file, self.contacts.len()), room), sty(th.fg, th.bg)),
        }
        self.put(f, r2, b2);
    }

    fn draw_message(&mut self, f: &mut Frame, r1: Rect, r2: Rect, r3: Rect, th: &Theme) {
        let base = sty(th.fg, th.bg);
        let btn = sty(th.accent, th.line).add_modifier(Modifier::BOLD);
        let c = self.cfg().clone();
        let mi = self.mode_index();
        let mut a = Bld::new(r1, base);
        Self::label(&mut a, "2", "MESSAGE", th);
        for (i, name) in ["Template", "Custom message (file optional)"].iter().enumerate() {
            let on = mi == i;
            a.btn(&format!("({}) {}", if on { "*" } else { " " }, name), if on { sty(th.bg, th.accent).add_modifier(Modifier::BOLD) } else { sty(th.fg, th.line) }, Hit::Mode(i as u8));
        }
        a.text("(M)", sty(th.dim, th.bg));
        self.put(f, r1, a);

        let mut t = Bld::new(r2, base);
        Self::label(&mut t, "", "", th);
        t.text("Text     ", sty(th.dim, th.bg));
        t.btn("Edit text (E)", btn, Hit::EditText);
        let text = if mi == 0 { c.template.clone() } else { c.custom.replace('\n', " / ") };
        let room = (r2.width as usize).saturating_sub(13 + 9 + 17);
        if text.trim().is_empty() {
            t.text("(empty - click Edit text and write your message)", sty(th.warn, th.bg));
        } else {
            t.text(fit(&text, room), sty(th.fg, th.bg));
        }
        self.put(f, r2, t);

        let mut fl = Bld::new(r3, base);
        Self::label(&mut fl, "", "", th);
        fl.text("File     ", sty(th.dim, th.bg));
        fl.btn("Choose file (F)", btn, Hit::Attach);
        if !c.attachment.is_empty() {
            fl.btn("Remove", btn, Hit::Remove);
        }
        let room = (r3.width as usize).saturating_sub(13 + 9 + 17 + 10);
        if c.attachment.is_empty() {
            fl.text("no file - to send a video, audio, picture or document pick one", sty(th.dim, th.bg));
        } else {
            let st = if mi == 1 { sty(th.fg, th.bg) } else { sty(th.dim, th.bg) };
            let note = if mi == 1 { String::new() } else { "  (not sent: files go with the Custom message)".to_string() };
            fl.text(fit(&format!("{}  [{}]{}", c.attachment, self.att_info, note), room), st);
        }
        self.put(f, r3, fl);
    }

    fn toggle_style(on: bool, th: &Theme) -> Style {
        if on { sty(th.bg, th.ok).add_modifier(Modifier::BOLD) } else { sty(th.fg, th.line) }
    }

    fn draw_via(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let c = self.cfg().clone();
        let btn = sty(th.accent, th.line).add_modifier(Modifier::BOLD);
        let mut a = Bld::new(r, sty(th.fg, th.bg));
        Self::label(&mut a, "3", "SEND VIA", th);
        a.btn(&format!("[{}] WhatsApp (W)", if c.use_wa { "x" } else { " " }), Self::toggle_style(c.use_wa, th), Hit::Wa);
        a.btn(&format!("[{}] SMS (S)", if c.use_sms { "x" } else { " " }), Self::toggle_style(c.use_sms, th), Hit::Sms);
        a.btn("Test SMS gateway (G)", btn, Hit::Check);
        a.btn("Link WhatsApp (L)", btn, Hit::LinkWa);
        self.put(f, r, a);
    }

    fn draw_to(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let c = self.cfg().clone();
        let mut a = Bld::new(r, sty(th.fg, th.bg));
        Self::label(&mut a, "4", "SEND TO", th);
        if self.roles.is_empty() {
            a.text("(no roles yet - choose the contacts file in step 1)", sty(th.warn, th.bg));
        }
        for (i, role) in self.roles.iter().enumerate().take(9) {
            let on = c.send_roles.contains(role);
            a.btn(&format!("[{}] {} {}", if on { "x" } else { " " }, i + 1, role), Self::toggle_style(on, th), Hit::Role(i));
        }
        if !self.roles.is_empty() {
            a.text("only ticked roles get the message", sty(th.dim, th.bg));
        }
        self.put(f, r, a);
    }

    fn draw_branches_bar(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let btn = sty(th.accent, th.line).add_modifier(Modifier::BOLD);
        let ticked = self.rows.iter().filter(|x| x.ticked).count();
        let mut a = Bld::new(r, sty(th.fg, th.bg));
        Self::label(&mut a, "5", "BRANCHES", th);
        a.btn("Select all (A)", btn, Hit::All(true));
        a.btn("Unselect all (N)", btn, Hit::All(false));
        a.text(format!("{} of {} selected - click a row to tick it", ticked, self.rows.len()), sty(th.dim, th.bg));
        self.put(f, r, a);
    }

    fn draw_table(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let w = r.width as usize;
        let h = r.height.saturating_sub(1) as usize;
        if self.sel < self.top {
            self.top = self.sel;
        }
        if h > 0 && self.sel >= self.top + h {
            self.top = self.sel + 1 - h;
        }
        let n = self.rows.len();
        let roles: Vec<String> = self.roles.iter().take(6).cloned().collect();
        let sb = usize::from(n > h);
        let name_w = w.saturating_sub(5 + 9 + roles.len() * 5 + 14 + sb).clamp(10, 36);
        let status_w = w.saturating_sub(5 + name_w + 1 + 9 + roles.len() * 5 + sb);
        let mut head = format!("{}{}{}", pad("Pick", 5), pad("Branch", name_w + 1), pad("Reviews", 9));
        for ro in &roles {
            head.push_str(&pad(&clip(ro, 4), 5));
        }
        head.push_str(&pad("Status", status_w + sb));
        let mut lines = vec![Line::from(Span::styled(head, sty(th.accent, th.panel).add_modifier(Modifier::BOLD)))];
        if n == 0 {
            lines.push(Line::from(Span::styled("  No branches yet. Do step 1: click 'Browse Excel...' and choose your Excel file.", sty(th.warn, th.bg))));
        }
        let (thumb_len, thumb_start) = if n > h && h > 0 { ((h * h / n).max(1), self.top * h / n) } else { (0, 0) };
        let mut new_hits = vec![];
        for (k, (i, row)) in self.rows.iter().enumerate().skip(self.top).take(h).enumerate().map(|(k, x)| (k, x)) {
            let bg = if i == self.sel { th.line } else { th.bg };
            let (st, tn) = self.row_status(row);
            let mut spans = vec![
                Span::styled(if row.ticked { " [x] " } else { " [ ] " }, sty(if row.ticked { th.ok } else { th.dim }, bg).add_modifier(Modifier::BOLD)),
                Span::styled(pad(&row.branch, name_w + 1), sty(th.fg, bg).add_modifier(if row.ticked { Modifier::BOLD } else { Modifier::empty() })),
                Span::styled(pad(&row.reviews.to_string(), 9), sty(if row.reviews == 0 { th.warn } else { th.fg }, bg)),
            ];
            for ro in &roles {
                let has = row.people.iter().any(|p| p.contact.role.eq_ignore_ascii_case(ro));
                spans.push(Span::styled(pad(if has { " *" } else { " ." }, 5), sty(if has { th.ok } else { th.dim }, bg)));
            }
            spans.push(Span::styled(pad(&st, status_w), sty(tone(tn, th), bg).add_modifier(Modifier::BOLD)));
            if sb == 1 {
                let on = k >= thumb_start && k < thumb_start + thumb_len;
                spans.push(Span::styled(if on { "█" } else { "│" }, sty(if on { th.accent } else { th.line }, bg)));
            }
            lines.push(Line::from(spans));
            new_hits.push((Rect { x: r.x, y: r.y + 1 + k as u16, width: r.width, height: 1 }, Hit::Row(i)));
        }
        f.render_widget(Paragraph::new(lines).style(sty(th.fg, th.bg)), r);
        self.hits.extend(new_hits);
    }

    /// The branches without any review, always in view (wide windows) so nobody has to find a hidden option.
    fn draw_zero_panel(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let zero: Vec<&Row> = self.rows.iter().filter(|x| x.reviews == 0).collect();
        let title = format!(" 0 REVIEWS ({}) ", zero.len());
        let blk = Block::default().borders(Borders::ALL).border_style(sty(if zero.is_empty() { th.line } else { th.warn }, th.bg)).title(Span::styled(title, sty(th.bg, if zero.is_empty() { th.ok } else { th.warn }).add_modifier(Modifier::BOLD)));
        let inner = blk.inner(r);
        f.render_widget(blk, r);
        let h = inner.height as usize;
        let mut lines: Vec<Line> = vec![];
        if zero.is_empty() {
            lines.push(Line::from(Span::styled(" Every branch has reviews.", sty(th.ok, th.bg))));
        } else {
            let room = h.saturating_sub(1);
            for row in zero.iter().take(if zero.len() > room { room.saturating_sub(1) } else { room }) {
                lines.push(Line::from(Span::styled(fit(&format!(" ✖ {}", row.branch), inner.width as usize), sty(th.warn, th.bg))));
            }
            if zero.len() > room {
                lines.push(Line::from(Span::styled(format!(" +{} more", zero.len() - lines.len()), sty(th.dim, th.bg))));
            }
            lines.push(Line::from(Span::styled(" click: list / copy / save", sty(th.accent, th.bg))));
        }
        f.render_widget(Paragraph::new(lines), inner);
        self.hits.push((r, Hit::Zero));
    }

    fn draw_detail(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let mut spans = vec![Span::styled(" Selected: ", sty(th.dim, th.bg))];
        if let Some(row) = self.rows.get(self.sel) {
            spans.push(Span::styled(row.branch.clone(), sty(th.accent, th.bg).add_modifier(Modifier::BOLD)));
            if row.people.is_empty() {
                spans.push(Span::styled("   no contact in the contacts file", sty(th.warn, th.bg)));
            }
            for p in &row.people {
                let (icon, col) = match p.state {
                    SendState::Sent => (" ✔", th.ok),
                    SendState::Failed => (" ✖", th.err),
                    SendState::NotSent => ("", th.dim),
                };
                spans.push(Span::styled(format!("   {} ", p.contact.role), sty(th.accent, th.bg)));
                spans.push(Span::styled(format!("{} {}", fit(&p.contact.label(), 20), format_phone(&p.contact.phone)), sty(th.fg, th.bg)));
                spans.push(Span::styled(icon, sty(col, th.bg).add_modifier(Modifier::BOLD)));
            }
        }
        f.render_widget(Paragraph::new(Line::from(spans)).style(sty(th.fg, th.bg)), r);
    }

    fn draw_status(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let area_narrow = r.width < 96;
        let blk = Block::default().borders(Borders::ALL).border_style(sty(th.line, th.bg)).title(Span::styled(" STATUS ", sty(th.accent, th.bg).add_modifier(Modifier::BOLD)));
        let inner = blk.inner(r);
        f.render_widget(blk, r);
        let l = &self.live;
        let iw = inner.width as usize;
        let mut lines: Vec<Line> = vec![];
        if l.total > 0 {
            let bw = iw.saturating_sub(36).clamp(10, 40);
            let filled = bw * l.done / l.total.max(1);
            let wait = l.until.and_then(|u| u.checked_duration_since(Instant::now())).map(|d| format!("  next in {}s", d.as_secs() + 1)).unwrap_or_default();
            lines.push(Line::from(vec![
                Span::styled("█".repeat(filled), sty(th.ok, th.bg)),
                Span::styled("░".repeat(bw - filled), sty(th.line, th.bg)),
                Span::styled(format!(" {}/{}   sent {}   failed {}{}", l.done, l.total, l.sent, l.failed, wait), sty(th.fg, th.bg)),
            ]));
            let last = l.recent.last().cloned().unwrap_or_default();
            let c = if last.starts_with("FAIL") { th.err } else if last.starts_with("OK") { th.ok } else { th.dim };
            lines.push(Line::from(Span::styled(fit(&last, iw), sty(c, th.bg))));
        } else {
            let (n, why) = self.send_state();
            match why {
                Some(w) => lines.push(Line::from(vec![Span::styled("NEXT: ", sty(th.warn, th.bg).add_modifier(Modifier::BOLD)), Span::styled(w, sty(th.fg, th.bg))])),
                None => lines.push(Line::from(vec![Span::styled("READY: ", sty(th.ok, th.bg).add_modifier(Modifier::BOLD)), Span::styled(format!("{n} message(s) will be sent. Press the green SEND button."), sty(th.fg, th.bg))])),
            }
            let zc = self.rows.iter().filter(|x| x.reviews == 0).count();
            let note = if zc > 0 && area_narrow { format!("{zc} branch(es) have 0 reviews - click '0 Reviews (Z)' below to see them") } else if !self.warnings.is_empty() { fit(&self.warnings.join("  |  "), iw) } else { "Messages can be sent again any time. Nothing is remembered.".to_string() };
            lines.push(Line::from(Span::styled(note, sty(if self.warnings.is_empty() && !(zc > 0 && area_narrow) { th.dim } else { th.warn }, th.bg))));
        }
        f.render_widget(Paragraph::new(lines), inner);
    }

    fn draw_send(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let (n, why) = self.send_state();
        let (txt, st, hit) = if self.live.running {
            (format!("■  STOP SENDING   {}/{} done   (click or Esc)", self.live.done, self.live.total), sty(th.bg, th.err).add_modifier(Modifier::BOLD), Hit::Stop)
        } else if let Some(w) = why {
            (format!("▶  SEND   -   first: {w}"), sty(th.dim, th.line), Hit::Send)
        } else {
            (format!("▶  SEND {n} MESSAGE{} NOW     (click here, or Ctrl+S / F5)", if n == 1 { "" } else { "S" }), sty(th.bg, th.ok).add_modifier(Modifier::BOLD), Hit::Send)
        };
        let w = r.width as usize;
        let lines = vec![Line::from(" ".repeat(w)), Line::from(pad_center(&txt, w)), Line::from(" ".repeat(w))];
        f.render_widget(Paragraph::new(lines).style(st), r);
        self.hits.push((r, hit));
    }

    fn draw_toolbar(&mut self, f: &mut Frame, r: Rect, th: &Theme) {
        let btn = sty(th.fg, th.line);
        let mut a = Bld::new(r, sty(th.fg, th.bg));
        a.text(" ", a.base);
        a.btn("Theme (T)", btn, Hit::Theme);
        a.btn("Settings (O)", btn, Hit::Settings);
        a.btn("Contacts (C)", btn, Hit::ContactsList);
        a.btn("0 Reviews (Z)", btn, Hit::Zero);
        a.btn("Reload (R)", btn, Hit::Reload);
        a.btn("Help (H)", btn, Hit::Help);
        a.btn("Quit (Ctrl+Q)", sty(th.bg, th.warn), Hit::Quit);
        self.put(f, r, a);
    }

    // ---------------- dialogs ----------------

    fn draw_modal(&mut self, f: &mut Frame, area: Rect, th: &Theme) {
        self.mhits.clear();
        let Some(m) = self.modal.take() else { return };
        let mut mh: Vec<(Rect, MHit)> = vec![];
        let mut keep = true;
        let panel = sty(th.fg, th.panel);
        match &m {
            Modal::Alert(t, body) => {
                let w = 70u16.min(area.width);
                let r = popup(f, area, w, text_h(body, w as usize - 4) + 4, t, th);
                let inner = inner_of(r);
                f.render_widget(Paragraph::new(body.clone()).wrap(ratatui::widgets::Wrap { trim: false }).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("OK  (Enter)", KeyCode::Enter, 1)], th, &mut mh);
            }
            Modal::Confirm(t, body, act) => {
                let w = 70u16.min(area.width);
                let r = popup(f, area, w, text_h(body, w as usize - 4) + 4, t, th);
                let inner = inner_of(r);
                f.render_widget(Paragraph::new(body.clone()).wrap(ratatui::widgets::Wrap { trim: false }).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                let items = match act {
                    Act::Send => vec![b("Yes, send  (Y)", KeyCode::Char('y'), 1), b("No  (N)", KeyCode::Char('n'), 0)],
                    Act::Cover(roles) => vec![b(&format!("Yes, add {}  (Y)", roles.join("/")), KeyCode::Char('y'), 1), b("No, only the ticked roles  (N)", KeyCode::Char('n'), 0), b("Cancel  (Esc)", KeyCode::Esc, 2)],
                    Act::Quit => vec![b("Yes, quit  (Y)", KeyCode::Char('y'), 2), b("No  (N)", KeyCode::Char('n'), 0)],
                };
                mbuttons(f, inner, &items, th, &mut mh);
            }
            Modal::Help => {
                let h = (HELP.lines().count() as u16 + 4).min(area.height);
                let r = popup(f, area, 82.min(area.width), h, "Help", th);
                let inner = inner_of(r);
                f.render_widget(Paragraph::new(HELP).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("Close  (Esc)", KeyCode::Esc, 1)], th, &mut mh);
            }
            Modal::Input { title, hint, buf, .. } => {
                let multi = buf.multiline;
                let h = if multi { 16 } else { 8 };
                let r = popup(f, area, 76.min(area.width), h, title, th);
                let inner = inner_of(r);
                let w = inner.width as usize;
                f.render_widget(Paragraph::new(hint.clone()).wrap(ratatui::widgets::Wrap { trim: false }).style(sty(th.dim, th.panel)), Rect { height: 2, ..inner });
                let box_area = Rect { x: inner.x, y: inner.y + 2, width: inner.width, height: inner.height.saturating_sub(4).max(1) };
                f.render_widget(Block::default().style(sty(th.fg, th.bg)), box_area);
                if multi {
                    let (rows, cur) = buf.wrapped(w.max(1));
                    let first = cur.0.saturating_sub(box_area.height as usize - 1);
                    let lines: Vec<Line> = rows.iter().skip(first).take(box_area.height as usize).map(|s| Line::from(s.clone())).collect();
                    f.render_widget(Paragraph::new(lines).style(sty(th.fg, th.bg)), box_area);
                    f.set_cursor_position((box_area.x + cur.1 as u16, box_area.y + (cur.0 - first) as u16));
                } else {
                    let (v, cx) = buf.line_view(w);
                    f.render_widget(Paragraph::new(v).style(sty(th.fg, th.bg)), Rect { height: 1, ..box_area });
                    f.set_cursor_position((box_area.x + cx as u16, box_area.y));
                }
                let ok = if multi { ("Use it  (Ctrl+S)".to_string(), KeyCode::Char('s'), KeyModifiers::CONTROL, 1) } else { ("OK  (Enter)".to_string(), KeyCode::Enter, KeyModifiers::NONE, 1) };
                mbuttons(f, inner, &[ok, b("Cancel  (Esc)", KeyCode::Esc, 0)], th, &mut mh);
            }
            Modal::Browse(br) => {
                let h = area.height.saturating_sub(2).min(26);
                let r = popup(f, area, area.width.saturating_sub(4).min(96), h, &format!("Choose a file - {}", fit(&br.dir.to_string_lossy(), 56)), th);
                let inner = inner_of(r);
                let rows = inner.height.saturating_sub(2) as usize;
                let top = if br.sel >= rows { br.sel + 1 - rows } else { 0 };
                let mut lines: Vec<Line> = vec![];
                for (i, (name, is_dir)) in br.entries.iter().enumerate().skip(top).take(rows) {
                    let bg = if i == br.sel { th.line } else { th.panel };
                    let txt = if *is_dir { format!(" ▸ {name}/") } else { format!("   {name}") };
                    lines.push(Line::from(Span::styled(pad(&txt, inner.width as usize), sty(if *is_dir { th.accent } else { th.fg }, bg))));
                    mh.push((Rect { x: inner.x, y: inner.y + (i - top) as u16, width: inner.width, height: 1 }, MHit::Row(i)));
                }
                f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                let mut items = vec![b("Up one folder  (Backspace)", KeyCode::Backspace, 0), b("Type a path  (/)", KeyCode::Char('/'), 0)];
                if br.target == Target::Attach {
                    items.push(b("No file  (X)", KeyCode::Char('x'), 0));
                }
                items.push(b("Cancel  (Esc)", KeyCode::Esc, 2));
                mbuttons(f, inner, &items, th, &mut mh);
            }
            Modal::Contacts(s) => {
                let h = area.height.saturating_sub(2).min(28);
                let r = popup(f, area, area.width.saturating_sub(4).min(96), h, &format!("Contacts ({})", self.contacts.len()), th);
                let inner = inner_of(r);
                let rows = inner.height.saturating_sub(2) as usize;
                let top = if *s >= rows { *s + 1 - rows } else { 0 };
                let mut lines: Vec<Line> = vec![];
                for (i, c) in self.contacts.iter().enumerate().skip(top).take(rows) {
                    let bg = if i == *s { th.line } else { th.panel };
                    let br = if c.cover { format!("{} branches", c.branches.len()) } else { c.branch.clone() };
                    let t = format!(" {:<5}{:<22}{:<18}{}", c.role, fit(&c.label(), 21), format_phone(&c.phone), br);
                    lines.push(Line::from(Span::styled(pad(&t, inner.width as usize), sty(th.fg, bg))));
                    mh.push((Rect { x: inner.x, y: inner.y + (i - top) as u16, width: inner.width, height: 1 }, MHit::Row(i)));
                }
                if self.contacts.is_empty() {
                    lines.push(Line::from(Span::styled(self.contacts_err.clone().unwrap_or_else(|| "empty".into()), sty(th.warn, th.panel))));
                }
                f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("Choose another file  (O)", KeyCode::Char('o'), 0), b("Reload  (R)", KeyCode::Char('r'), 0), b("Close  (Esc)", KeyCode::Esc, 1)], th, &mut mh);
            }
            Modal::Zero(s) => {
                let zero: Vec<&Row> = self.rows.iter().filter(|r| r.reviews == 0).collect();
                let h = area.height.saturating_sub(2).min(24);
                let r = popup(f, area, 64.min(area.width), h, &format!("Branches with 0 reviews ({})", zero.len()), th);
                let inner = inner_of(r);
                let rows = inner.height.saturating_sub(2) as usize;
                let top = if *s >= rows { *s + 1 - rows } else { 0 };
                let mut lines: Vec<Line> = vec![];
                for (i, row) in zero.iter().enumerate().skip(top).take(rows) {
                    lines.push(Line::from(Span::styled(pad(&format!(" {}", row.branch), inner.width as usize), sty(th.fg, if i == *s { th.line } else { th.panel }))));
                    mh.push((Rect { x: inner.x, y: inner.y + (i - top) as u16, width: inner.width, height: 1 }, MHit::Row(i)));
                }
                if zero.is_empty() {
                    lines.push(Line::from(Span::styled(" Every branch has reviews.", sty(th.ok, th.panel))));
                }
                f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("Copy names  (C)", KeyCode::Char('c'), 0), b("Save to file  (S)", KeyCode::Char('s'), 0), b("Close  (Esc)", KeyCode::Esc, 1)], th, &mut mh);
            }
            Modal::Settings(s) => {
                let h = (SETTINGS.len() as u16 + 4).min(area.height);
                let r = popup(f, area, 78.min(area.width), h, "Settings - click a line to change it", th);
                let inner = inner_of(r);
                let rows = inner.height.saturating_sub(2) as usize;
                let top = if *s >= rows { *s + 1 - rows } else { 0 };
                let mut lines: Vec<Line> = vec![];
                for (i, (label, _)) in SETTINGS.iter().enumerate().skip(top).take(rows) {
                    let bg = if i == *s { th.line } else { th.panel };
                    let v = fit(&self.setting_value(i), (inner.width as usize).saturating_sub(36));
                    lines.push(Line::from(vec![Span::styled(pad(&format!(" {label}"), 34), sty(th.fg, bg)), Span::styled(pad(&v, inner.width as usize - 34), sty(th.accent, bg))]));
                    mh.push((Rect { x: inner.x, y: inner.y + (i - top) as u16, width: inner.width, height: 1 }, MHit::Row(i)));
                }
                f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("Close  (Esc)", KeyCode::Esc, 1)], th, &mut mh);
            }
            Modal::Themes { sel, .. } => {
                let list = self.theme_list();
                let h = (list.len() as u16 + 6).min(area.height);
                let r = popup(f, area, 64.min(area.width), h, "Choose a colour theme - click one to preview", th);
                let inner = inner_of(r);
                let all = &self.themes;
                let mut lines: Vec<Line> = vec![];
                for (i, (name, key)) in list.iter().enumerate() {
                    let bg = if i == *sel { th.line } else { th.panel };
                    let t = all.iter().find(|t| t.name == *key);
                    let mut spans = vec![Span::styled(if i == *sel { " ▶ " } else { "   " }, sty(th.accent, bg))];
                    spans.push(Span::styled(pad(name, 38), sty(th.fg, bg).add_modifier(if i == *sel { Modifier::BOLD } else { Modifier::empty() })));
                    if let Some(t) = t {
                        for c in [t.bg, t.accent, t.ok, t.warn, t.err] {
                            spans.push(Span::styled("██", Style::default().fg(c.c()).bg(bg.c())));
                        }
                    }
                    lines.push(Line::from(spans));
                    mh.push((Rect { x: inner.x, y: inner.y + i as u16, width: inner.width, height: 1 }, MHit::Row(i)));
                }
                f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                mbuttons(f, inner, &[b("Use this theme  (Enter)", KeyCode::Enter, 1), b("Cancel  (Esc)", KeyCode::Esc, 0)], th, &mut mh);
            }
            Modal::Link { code } => {
                if self.wa.connected() && self.wa.linked() {
                    keep = false;
                } else {
                    let qr = self.wa.qr();
                    let (qlines, qw) = qr_lines(&qr);
                    let h = (qlines.len() as u16 + 8).max(12).min(area.height);
                    let w = (qw as u16 + 6).max(64).min(area.width);
                    let r = popup(f, area, w, h, "Link WhatsApp", th);
                    let inner = inner_of(r);
                    let mut lines: Vec<Line> = vec![
                        Line::from(Span::styled("On your phone: WhatsApp > Linked devices > Link a device, then scan.", panel)),
                        Line::from(Span::styled(fit(&format!("Status: {} {}", self.wa.status(), self.wa.detail()), inner.width as usize), sty(th.dim, th.panel))),
                    ];
                    if let Some(c) = code {
                        lines.push(Line::from(Span::styled(format!("Pairing code:  {c}"), sty(th.ok, th.panel).add_modifier(Modifier::BOLD))));
                        lines.push(Line::from(Span::styled("WhatsApp > Linked devices > Link with phone number instead", sty(th.dim, th.panel))));
                    } else if qlines.is_empty() {
                        lines.push(Line::from(Span::styled("Waiting for the QR code...", sty(th.dim, th.panel))));
                    } else if inner.height < qlines.len() as u16 + 5 || (inner.width as usize) < qw {
                        lines.push(Line::from(Span::styled("Window too small for the QR code: make it bigger, or use the pairing code button.", sty(th.warn, th.panel))));
                    } else {
                        for l in qlines {
                            lines.push(Line::from(Span::styled(pad_center(&l, inner.width as usize), Style::default().fg(Color::Black).bg(Color::White))));
                        }
                    }
                    f.render_widget(Paragraph::new(lines).style(panel), Rect { height: inner.height.saturating_sub(2), ..inner });
                    mbuttons(f, inner, &[b("Use a phone-number code  (P)", KeyCode::Char('p'), 0), b("Close  (Esc)", KeyCode::Esc, 1)], th, &mut mh);
                }
            }
        }
        if keep && self.modal.is_none() {
            self.modal = Some(m);
        } else if !keep {
            self.alert("WhatsApp", "Linked and connected.");
        }
        self.mhits = mh;
    }
}
