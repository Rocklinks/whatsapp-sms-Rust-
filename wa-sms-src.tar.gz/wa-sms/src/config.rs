use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::collections::BTreeMap;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

// Everything the program remembers lives in the "data" folder next to it:
//
//   config.json          settings (made to be edited by hand as well)
//   whatsapp-session.db  the linked WhatsApp session
//
// Contacts are deliberately NOT stored here. They are read from the contacts file every
// time, so only the people listed in that file can ever get a message.
//
// No send history is kept: a message can always be sent again, nothing ever asks
// "this message was already sent".

/// The content of config.json.
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default)]
pub struct Cfg {
    pub excel_file: String,
    pub excel_dir: String,
    pub contacts_file: String,
    pub contacts_dir: String,
    pub attachment: String,
    #[serde(rename = "attachment_dir")]
    pub attach_dir: String,

    pub mode: String, // "template" or "custom"
    #[serde(rename = "message_template")]
    pub template: String,
    #[serde(skip)]
    pub custom: String, // the custom message lives in memory only: never saved
    pub agm_message: String, // "combined" (one list) or "separate" (one per branch)

    #[serde(rename = "use_whatsapp")]
    pub use_wa: bool,
    pub use_sms: bool,
    pub confirm_send: bool, // true = ask "Send N messages?" before sending
    #[serde(skip)]
    pub send_roles: Vec<String>, // roles ticked in SEND TO - never saved, you tick them every time
    pub cover_roles: Vec<String>, // roles that look after many branches (AGM)

    #[serde(rename = "default_country_code")]
    pub country: String,
    #[serde(rename = "reviews_column")]
    pub reviews_col: String, // blank = find the "Reviews" header

    #[serde(rename = "sms_server_url")]
    pub sms_url: String,
    pub sms_mode: String, // the gateway API that worked last time ("auto" = not known yet)
    #[serde(rename = "sms_custom_path")]
    pub sms_path: String,
    #[serde(rename = "sms_custom_method")]
    pub sms_method: String,
    #[serde(rename = "sms_custom_body")]
    pub sms_body: String,
    pub sms_test_phone: String,

    #[serde(rename = "wa_min_delay_ms")]
    pub wa_min: i64,
    #[serde(rename = "wa_max_delay_ms")]
    pub wa_max: i64,
    #[serde(rename = "sms_min_delay_ms")]
    pub sms_min: i64,
    #[serde(rename = "sms_max_delay_ms")]
    pub sms_max: i64,

    #[serde(rename = "ui_theme")]
    pub theme: String, // preset name, "system" or "custom"
    #[serde(skip_serializing_if = "BTreeMap::is_empty")]
    pub custom_theme: BTreeMap<String, String>,
    #[serde(rename = "welcome_done")]
    pub welcomed: bool,
}

impl Default for Cfg {
    fn default() -> Self {
        Cfg {
            excel_file: String::new(),
            excel_dir: String::new(),
            contacts_file: String::new(),
            contacts_dir: String::new(),
            attachment: String::new(),
            attach_dir: String::new(),
            mode: "template".into(),
            template: "Till now {reviews} Reviews for {branch}".into(),
            custom: String::new(),
            agm_message: "combined".into(),
            use_wa: true,
            use_sms: false,
            confirm_send: false,
            send_roles: Vec::new(),
            cover_roles: vec!["AGM".into()],
            country: "91".into(),
            reviews_col: String::new(),
            sms_url: String::new(),
            sms_mode: "auto".into(),
            sms_path: String::new(),
            sms_method: "POST".into(),
            sms_body: String::new(),
            sms_test_phone: String::new(),
            wa_min: 3000,
            wa_max: 7000,
            sms_min: 12000,
            sms_max: 25000,
            theme: "Catppuccin Mocha".into(),
            custom_theme: BTreeMap::new(),
            welcomed: false,
        }
    }
}

impl Cfg {
    /// Repairs values that would break the program (typos in a hand-edited file).
    pub fn normalize(&mut self) {
        if self.mode != "custom" {
            self.mode = "template".into();
        }
        if self.agm_message != "separate" {
            self.agm_message = "combined".into();
        }
        if self.cover_roles.is_empty() {
            self.cover_roles = vec!["AGM".into()];
        }
        if self.theme.trim().is_empty() {
            self.theme = "Catppuccin Mocha".into();
        }
        if self.sms_method.is_empty() {
            self.sms_method = "POST".into();
        }
        self.wa_min = self.wa_min.max(500);
        self.wa_max = self.wa_max.max(self.wa_min);
        self.sms_min = self.sms_min.max(200);
        self.sms_max = self.sms_max.max(self.sms_min);
    }
}

/// Keys written by older versions that nothing reads any more
/// (state.json and the old send history are not used any more either).
const OBSOLETE_KEYS: &[&str] = &[
    "gnome_sync",
    "roles",
    "role_aliases",
    "contacts_files",
    "contacts_file_mtime",
    "send_roles",
    "custom_message",
];

/// Holds the settings.
pub struct Store {
    pub dir: PathBuf,
    pub cfg: Cfg,
    raw: Map<String, Value>, // config.json as read, so keys we do not know survive a save
    pub fresh: bool,         // no config.json existed yet (first start)
}

impl Store {
    pub fn open() -> (Store, Option<String>) {
        let mut s = Store { dir: data_dir(), cfg: Cfg::default(), raw: Map::new(), fresh: false };
        let mut problem = None;
        match s.read_config() {
            Ok(()) => {}
            Err(ReadError::Missing) => s.fresh = true,
            Err(ReadError::Bad(msg)) => {
                // keep the user's hand-edited file: a save must not silently destroy it
                let bad = s.config_path().with_extension("json.bad");
                let _ = std::fs::copy(s.config_path(), &bad);
                problem = Some(format!("{msg} (a copy was kept as {})", bad.display()));
            }
        }
        (s, problem)
    }

    pub fn config_path(&self) -> PathBuf {
        self.dir.join("config.json")
    }

    fn read_config(&mut self) -> Result<(), ReadError> {
        let b = match std::fs::read(self.config_path()) {
            Ok(b) => b,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Err(ReadError::Missing),
            Err(e) => return Err(ReadError::Bad(format!("cannot read config.json: {e}"))),
        };
        let raw: Map<String, Value> = serde_json::from_slice(&b)
            .map_err(|e| ReadError::Bad(format!("config.json is not valid JSON: {e}")))?;
        let mut cfg: Cfg = serde_json::from_slice(&b)
            .map_err(|e| ReadError::Bad(format!("config.json has a wrong value: {e}")))?;
        cfg.normalize();
        cfg.send_roles = self.cfg.send_roles.clone();
        cfg.custom = self.cfg.custom.clone();
        self.cfg = cfg;
        self.raw = raw;
        Ok(())
    }

    /// Re-reads config.json (used by Settings > Reload config).
    pub fn reload(&mut self) -> Result<(), String> {
        match self.read_config() {
            Ok(()) => Ok(()),
            Err(ReadError::Missing) => Err("config.json does not exist".into()),
            Err(ReadError::Bad(m)) => Err(m),
        }
    }

    pub fn save_cfg(&self) {
        let ours = match serde_json::to_value(&self.cfg) {
            Ok(Value::Object(m)) => m,
            _ => return,
        };
        let mut out = self.raw.clone();
        for k in OBSOLETE_KEYS {
            out.remove(*k);
        }
        for (k, v) in ours {
            out.insert(k, v);
        }
        let _ = write_json(&self.config_path(), &Value::Object(out));
    }
}

enum ReadError {
    Missing,
    Bad(String),
}

// ---------------- folders and paths ----------------

pub fn exists(p: impl AsRef<Path>) -> bool {
    p.as_ref().exists()
}

pub fn home_dir() -> PathBuf {
    std::env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("."))
}

/// The folder the program file lives in.
pub fn program_dir() -> PathBuf {
    match std::env::current_exe() {
        Ok(exe) => {
            let exe = std::fs::canonicalize(&exe).unwrap_or(exe);
            exe.parent().map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("."))
        }
        Err(_) => PathBuf::from("."),
    }
}

fn writable(dir: &Path) -> bool {
    let probe = dir.join(format!(".write-test-{}", std::process::id()));
    match std::fs::File::create(&probe) {
        Ok(_) => {
            let _ = std::fs::remove_file(&probe);
            true
        }
        Err(_) => false,
    }
}

pub fn xdg_data() -> PathBuf {
    match std::env::var_os("XDG_DATA_HOME") {
        Some(x) if !x.is_empty() => PathBuf::from(x),
        _ => home_dir().join(".local").join("share"),
    }
}

fn make_private_dir(p: &Path) {
    let _ = std::fs::create_dir_all(p);
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(p, std::fs::Permissions::from_mode(0o700));
    }
}

/// $WA_SMS_DATA (or the old $WA_SA_DATA), else the "data" folder next to the program, else ~/.local/share/wa-sms.
pub fn data_dir() -> PathBuf {
    static DIR: OnceLock<PathBuf> = OnceLock::new();
    DIR.get_or_init(|| {
        if let Some(d) = std::env::var_os("WA_SMS_DATA").or_else(|| std::env::var_os("WA_SA_DATA")) {
            if !d.is_empty() {
                let d = PathBuf::from(d);
                make_private_dir(&d);
                return d;
            }
        }
        let prog = program_dir();
        let next = prog.join("data");
        if next.exists() && writable(&next) {
            return next;
        }
        let p = prog.to_string_lossy().to_string();
        let dev_build = p.contains("/target/");
        if !next.exists() && writable(&prog) && !p.starts_with("/usr/") && !dev_build {
            make_private_dir(&next);
            if next.exists() {
                return next;
            }
        }
        let d = xdg_data().join("wa-sms");
        make_private_dir(&d);
        d
    })
    .clone()
}

/// Removes quotes and "file://" and expands a leading "~".
pub fn expand_path(p: &str) -> String {
    let p = p.trim().trim_matches(|c| c == '\'' || c == '"').trim();
    let p = p.strip_prefix("file://").unwrap_or(p);
    if p == "~" || p.starts_with("~/") {
        return home_dir().join(p.trim_start_matches('~').trim_start_matches('/')).to_string_lossy().to_string();
    }
    p.to_string()
}

/// Turns a configured file name into a real path. A relative name is looked up in `dir`
/// (if given) or next to the program, and the letter case of folders is forgiven.
pub fn resolve_path(p: &str, dir: &str) -> String {
    let p = expand_path(p);
    if p.is_empty() {
        return p;
    }
    let mut path = PathBuf::from(&p);
    if !path.is_absolute() {
        let base = expand_path(dir);
        let base = if base.is_empty() {
            program_dir()
        } else if !Path::new(&base).is_absolute() {
            program_dir().join(base)
        } else {
            PathBuf::from(base)
        };
        path = base.join(path);
    }
    fix_case(&path.to_string_lossy())
}

/// Finds "/home/x/sathya/a.txt" when the folder is really called "Sathya" (Linux is case sensitive).
pub fn fix_case(p: &str) -> String {
    let path = Path::new(p);
    if path.exists() || !path.is_absolute() {
        return p.to_string();
    }
    let mut cur = PathBuf::from("/");
    for part in p.split('/') {
        if part.is_empty() {
            continue;
        }
        let next = cur.join(part);
        if next.exists() {
            cur = next;
            continue;
        }
        let Ok(entries) = std::fs::read_dir(&cur) else { return p.to_string() };
        let mut found = false;
        for e in entries.flatten() {
            if e.file_name().to_string_lossy().to_lowercase() == part.to_lowercase() {
                cur = cur.join(e.file_name());
                found = true;
                break;
            }
        }
        if !found {
            return p.to_string();
        }
    }
    cur.to_string_lossy().to_string()
}

/// Where a file browser should open: the current file, else the configured folder, else home.
pub fn start_dir(file: &str, dir: &str) -> String {
    let f = resolve_path(file, dir);
    if !f.is_empty() && exists(&f) {
        return f;
    }
    let d = expand_path(dir);
    if !d.is_empty() {
        let d = if Path::new(&d).is_absolute() { PathBuf::from(d) } else { program_dir().join(d) };
        if d.exists() {
            return format!("{}/", d.to_string_lossy());
        }
    }
    format!("{}/", home_dir().to_string_lossy())
}

// ---------------- small file helpers ----------------

/// Replaces the file atomically (write a temp file, then rename).
pub fn write_json(path: &Path, v: &Value) -> std::io::Result<()> {
    let b = serde_json::to_vec_pretty(v).map_err(std::io::Error::other)?;
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, b)?;
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = std::fs::set_permissions(&tmp, std::fs::Permissions::from_mode(0o600));
    }
    std::fs::rename(&tmp, path)
}

static LOG_LOCK: Mutex<()> = Mutex::new(());

/// Adds one line to a log file in the data folder (app.log, sent.log ...).
pub fn append_log(name: &str, line: &str) {
    let _g = LOG_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let mut opts = std::fs::OpenOptions::new();
    opts.append(true).create(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        opts.mode(0o600);
    }
    if let Ok(mut f) = opts.open(data_dir().join(name)) {
        let _ = writeln!(f, "{line}");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults_match_the_original() {
        let c = Cfg::default();
        assert_eq!(c.template, "Till now {reviews} Reviews for {branch}");
        assert_eq!((c.wa_min, c.wa_max, c.sms_min, c.sms_max), (3000, 7000, 12000, 25000));
        assert!(c.use_wa && !c.use_sms);
        assert_eq!(c.country, "91");
    }

    #[test]
    fn partial_config_keeps_defaults_and_normalizes() {
        let mut c: Cfg = serde_json::from_str(r#"{"mode":"weird","wa_min_delay_ms":10,"wa_max_delay_ms":5}"#).unwrap();
        c.normalize();
        assert_eq!(c.mode, "template");
        assert_eq!(c.wa_min, 500);
        assert_eq!(c.wa_max, 500);
        assert_eq!(c.template, "Till now {reviews} Reviews for {branch}");
    }

    #[test]
    fn expand_path_handles_quotes_and_file_scheme() {
        assert_eq!(expand_path("  'file:///tmp/a b.xlsx' "), "/tmp/a b.xlsx");
    }
}
