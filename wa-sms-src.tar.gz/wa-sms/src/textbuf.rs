use crate::util::width;
use ratatui::crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
use unicode_width::UnicodeWidthChar;

/// A small text editor: one line (the template, a path ...) or several (the custom message).
#[derive(Clone, Debug, Default)]
pub struct TextBuf {
    pub lines: Vec<String>,
    pub row: usize,
    pub col: usize, // cursor position in characters
    pub multiline: bool,
}

fn byte_at(s: &str, col: usize) -> usize {
    s.char_indices().nth(col).map(|(i, _)| i).unwrap_or(s.len())
}

fn char_len(s: &str) -> usize {
    s.chars().count()
}

impl TextBuf {
    pub fn new(multiline: bool) -> Self {
        TextBuf { lines: vec![String::new()], row: 0, col: 0, multiline }
    }

    pub fn with_text(text: &str, multiline: bool) -> Self {
        let mut t = TextBuf::new(multiline);
        t.set_text(text);
        t
    }

    /// Replaces the text; the cursor goes to the end.
    pub fn set_text(&mut self, text: &str) {
        let text = text.replace("\r\n", "\n").replace('\r', "\n");
        self.lines = if self.multiline { text.split('\n').map(str::to_string).collect() } else { vec![text.replace('\n', " ")] };
        if self.lines.is_empty() {
            self.lines.push(String::new());
        }
        self.row = self.lines.len() - 1;
        self.col = char_len(&self.lines[self.row]);
    }

    pub fn text(&self) -> String {
        self.lines.join("\n")
    }

    pub fn is_blank(&self) -> bool {
        self.lines.iter().all(|l| l.trim().is_empty())
    }

    pub fn insert_str(&mut self, s: &str) -> bool {
        let mut changed = false;
        for c in s.chars() {
            match c {
                '\r' => {}
                '\n' => {
                    if self.multiline {
                        self.newline();
                    } else {
                        self.insert_char(' ');
                    }
                    changed = true;
                }
                c if c.is_control() => {}
                c => {
                    self.insert_char(c);
                    changed = true;
                }
            }
        }
        changed
    }

    fn insert_char(&mut self, c: char) {
        let line = &mut self.lines[self.row];
        let at = byte_at(line, self.col);
        line.insert(at, c);
        self.col += 1;
    }

    fn newline(&mut self) {
        let at = byte_at(&self.lines[self.row], self.col);
        let rest = self.lines[self.row].split_off(at);
        self.lines.insert(self.row + 1, rest);
        self.row += 1;
        self.col = 0;
    }

    /// Handles an editing key. Returns true when the text changed.
    pub fn handle_key(&mut self, k: KeyEvent) -> bool {
        let ctrl = k.modifiers.contains(KeyModifiers::CONTROL);
        let alt = k.modifiers.contains(KeyModifiers::ALT);
        match k.code {
            KeyCode::Char(c) if !ctrl && !alt => {
                self.insert_char(c);
                true
            }
            KeyCode::Char('a') if ctrl => {
                self.col = 0;
                false
            }
            KeyCode::Char('e') if ctrl => {
                self.col = char_len(&self.lines[self.row]);
                false
            }
            KeyCode::Char('u') if ctrl => {
                let at = byte_at(&self.lines[self.row], self.col);
                self.lines[self.row].replace_range(..at, "");
                self.col = 0;
                true
            }
            KeyCode::Char('k') if ctrl => {
                let at = byte_at(&self.lines[self.row], self.col);
                self.lines[self.row].truncate(at);
                true
            }
            KeyCode::Enter if self.multiline => {
                self.newline();
                true
            }
            KeyCode::Backspace => {
                if self.col > 0 {
                    let line = &mut self.lines[self.row];
                    let at = byte_at(line, self.col - 1);
                    line.remove(at);
                    self.col -= 1;
                    true
                } else if self.row > 0 {
                    let cur = self.lines.remove(self.row);
                    self.row -= 1;
                    self.col = char_len(&self.lines[self.row]);
                    self.lines[self.row].push_str(&cur);
                    true
                } else {
                    false
                }
            }
            KeyCode::Delete => {
                let len = char_len(&self.lines[self.row]);
                if self.col < len {
                    let line = &mut self.lines[self.row];
                    let at = byte_at(line, self.col);
                    line.remove(at);
                    true
                } else if self.row + 1 < self.lines.len() {
                    let next = self.lines.remove(self.row + 1);
                    self.lines[self.row].push_str(&next);
                    true
                } else {
                    false
                }
            }
            KeyCode::Left => {
                if self.col > 0 {
                    self.col -= 1;
                } else if self.row > 0 {
                    self.row -= 1;
                    self.col = char_len(&self.lines[self.row]);
                }
                false
            }
            KeyCode::Right => {
                if self.col < char_len(&self.lines[self.row]) {
                    self.col += 1;
                } else if self.row + 1 < self.lines.len() {
                    self.row += 1;
                    self.col = 0;
                }
                false
            }
            KeyCode::Up if self.multiline => {
                if self.row > 0 {
                    self.row -= 1;
                    self.col = self.col.min(char_len(&self.lines[self.row]));
                }
                false
            }
            KeyCode::Down if self.multiline => {
                if self.row + 1 < self.lines.len() {
                    self.row += 1;
                    self.col = self.col.min(char_len(&self.lines[self.row]));
                }
                false
            }
            KeyCode::Home => {
                self.col = 0;
                false
            }
            KeyCode::End => {
                self.col = char_len(&self.lines[self.row]);
                false
            }
            _ => false,
        }
    }

    /// A single line, scrolled sideways so that the cursor stays visible.
    /// Returns the visible text and the cursor column inside it.
    pub fn line_view(&self, w: usize) -> (String, usize) {
        if w == 0 {
            return (String::new(), 0);
        }
        let line = &self.lines[self.row];
        let chars: Vec<char> = line.chars().collect();
        let col = self.col.min(chars.len());
        // move the start to the right until the cursor fits
        let mut start = 0;
        loop {
            let used: usize = chars[start..col].iter().map(|c| UnicodeWidthChar::width(*c).unwrap_or(0)).sum();
            if used < w || start >= col {
                break;
            }
            start += 1;
        }
        let mut out = String::new();
        let mut used = 0;
        for c in &chars[start..] {
            let cw = UnicodeWidthChar::width(*c).unwrap_or(0);
            if used + cw > w {
                break;
            }
            used += cw;
            out.push(*c);
        }
        let cx: usize = chars[start..col].iter().map(|c| UnicodeWidthChar::width(*c).unwrap_or(0)).sum();
        (out, cx.min(w - 1))
    }

    /// The text wrapped to `w` columns: the visual rows and the cursor (row, column) among them.
    pub fn wrapped(&self, w: usize) -> (Vec<String>, (usize, usize)) {
        let w = w.max(1);
        let mut rows: Vec<String> = Vec::new();
        let mut cursor = (0, 0);
        for (li, line) in self.lines.iter().enumerate() {
            let mut cur = String::new();
            let mut used = 0;
            let first_row_of_line = rows.len();
            let mut cursor_set = false;
            for (ci, c) in line.chars().enumerate() {
                let cw = UnicodeWidthChar::width(c).unwrap_or(0);
                if used + cw > w {
                    rows.push(std::mem::take(&mut cur));
                    used = 0;
                }
                if li == self.row && ci == self.col {
                    cursor = (rows.len(), used);
                    cursor_set = true;
                }
                cur.push(c);
                used += cw;
            }
            if li == self.row && !cursor_set {
                // the cursor stands after the last character
                if used >= w {
                    cursor = (rows.len() + 1, 0);
                    rows.push(std::mem::take(&mut cur));
                    cur = String::new();
                } else {
                    cursor = (rows.len(), used);
                }
            }
            let _ = first_row_of_line;
            rows.push(cur);
        }
        (rows, cursor)
    }

    pub fn display_width(&self) -> usize {
        width(&self.lines[self.row])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ratatui::crossterm::event::{KeyEventKind, KeyEventState};

    fn key(code: KeyCode) -> KeyEvent {
        KeyEvent { code, modifiers: KeyModifiers::NONE, kind: KeyEventKind::Press, state: KeyEventState::NONE }
    }

    fn type_text(t: &mut TextBuf, s: &str) {
        for c in s.chars() {
            t.handle_key(key(KeyCode::Char(c)));
        }
    }

    #[test]
    fn typing_editing_and_unicode() {
        let mut t = TextBuf::new(false);
        type_text(&mut t, "Till now {reviews}");
        assert_eq!(t.text(), "Till now {reviews}");
        t.handle_key(key(KeyCode::Home));
        t.handle_key(key(KeyCode::Delete));
        assert_eq!(t.text(), "ill now {reviews}");
        t.handle_key(key(KeyCode::End));
        t.handle_key(key(KeyCode::Backspace));
        assert_eq!(t.text(), "ill now {reviews");
        let mut u = TextBuf::new(false);
        type_text(&mut u, "வணக்கம்");
        u.handle_key(key(KeyCode::Backspace));
        assert_eq!(u.text().chars().count(), "வணக்கம்".chars().count() - 1);
    }

    #[test]
    fn multiline_enter_and_joining() {
        let mut t = TextBuf::new(true);
        type_text(&mut t, "ab");
        t.handle_key(key(KeyCode::Enter));
        type_text(&mut t, "cd");
        assert_eq!(t.text(), "ab\ncd");
        t.handle_key(key(KeyCode::Home));
        t.handle_key(key(KeyCode::Backspace));
        assert_eq!(t.text(), "abcd");
        // a single-line box ignores Enter and turns pasted newlines into spaces
        let mut s = TextBuf::new(false);
        assert!(!s.handle_key(key(KeyCode::Enter)));
        s.insert_str("a\nb");
        assert_eq!(s.text(), "a b");
    }

    #[test]
    fn line_view_keeps_the_cursor_visible() {
        let mut t = TextBuf::new(false);
        type_text(&mut t, "0123456789");
        let (v, cx) = t.line_view(5);
        assert_eq!(v, "6789");
        assert_eq!(cx, 4);
        t.handle_key(key(KeyCode::Home));
        let (v, cx) = t.line_view(5);
        assert_eq!((v.as_str(), cx), ("01234", 0));
    }

    #[test]
    fn wrapping_places_the_cursor() {
        let mut t = TextBuf::new(true);
        t.set_text("abcdefghij\nxy");
        let (rows, cur) = t.wrapped(4);
        assert_eq!(rows, vec!["abcd", "efgh", "ij", "xy"]);
        assert_eq!(cur, (3, 2));
    }
}
