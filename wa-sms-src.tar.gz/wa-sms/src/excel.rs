use crate::branches::{key_name, Branch};
use crate::config::exists;
use calamine::{Data, Reader};
use regex::Regex;
use std::collections::HashSet;
use std::path::Path;
use std::sync::OnceLock;

fn reviews_header() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| Regex::new(r"(?i)review").unwrap())
}

fn total_row() -> &'static Regex {
    static R: OnceLock<Regex> = OnceLock::new();
    R.get_or_init(|| Regex::new(r"(?i)^\s*(grand\s*)?total\b").unwrap())
}

/// Reads the Excel (or csv) file: one branch per row with its number of reviews.
/// The reviews column is the one whose header contains "review", or the letter given in Settings.
/// The branch column is the one whose header contains "branch", else the first other column.
pub fn load_branches(file: &str, reviews_col: &str) -> Result<(Vec<Branch>, String), String> {
    if !exists(file) {
        return Err(format!("Excel file not found: {file}"));
    }
    let rows = read_sheet(file)?;
    let width = rows.iter().map(Vec::len).max().unwrap_or(0);

    let (header, rev_col) = find_reviews_column(&rows, width, &reviews_col.trim().to_uppercase())?;
    let head = &rows[header];
    let mut name_col: Option<usize> = None;
    for (i, cell) in head.iter().enumerate() {
        if i != rev_col && cell.to_lowercase().contains("branch") {
            name_col = Some(i);
            break;
        }
    }
    if name_col.is_none() {
        for (i, cell) in head.iter().enumerate() {
            if i != rev_col && !cell.trim().is_empty() {
                name_col = Some(i);
                break;
            }
        }
    }
    let name_col = name_col.unwrap_or(if rev_col == 0 { 1 } else { 0 });

    let mut out: Vec<Branch> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut duplicates = 0;
    for r in &rows[header + 1..] {
        if name_col >= r.len() {
            continue;
        }
        let name = r[name_col].trim().to_string();
        if name.is_empty() || total_row().is_match(&name) {
            continue;
        }
        if !seen.insert(key_name(&name)) {
            duplicates += 1;
            continue;
        }
        let mut reviews = 0i64;
        if rev_col < r.len() {
            if let Ok(f) = r[rev_col].trim().replace(',', "").parse::<f64>() {
                reviews = (f + 0.5) as i64;
            }
        }
        out.push(Branch { name, reviews });
    }
    if out.is_empty() {
        let base = Path::new(file).file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
        return Err(format!("no branches found under the header row in {base}"));
    }
    let note = if duplicates > 0 { format!("{duplicates} duplicate branch row(s) skipped") } else { String::new() };
    Ok((out, note))
}

/// Returns the header row and the column of the reviews numbers.
fn find_reviews_column(rows: &[Vec<String>], width: usize, letter: &str) -> Result<(usize, usize), String> {
    if rows.is_empty() {
        return Err("the sheet is empty".into());
    }
    if !letter.is_empty() {
        let mut n = 0usize;
        for ch in letter.chars() {
            if !ch.is_ascii_uppercase() {
                return Err(format!("Reviews column {letter:?} is not a valid column letter"));
            }
            n = n * 26 + (ch as usize - 'A' as usize) + 1;
        }
        if n > width {
            return Err(format!(
                "Reviews column {letter:?} is not a column in this sheet (columns go up to {})",
                column_letter(width.saturating_sub(1))
            ));
        }
        for (i, r) in rows.iter().enumerate() {
            if !blank_row(r) {
                return Ok((i, n - 1));
            }
        }
    }
    for (i, r) in rows.iter().enumerate().take(15) {
        for (j, cell) in r.iter().enumerate() {
            if reviews_header().is_match(cell) {
                return Ok((i, j));
            }
        }
    }
    let mut seen: Vec<String> = Vec::new();
    for r in rows {
        if blank_row(r) {
            continue;
        }
        for (j, cell) in r.iter().enumerate() {
            if !cell.trim().is_empty() {
                seen.push(format!("{}={}", column_letter(j), cell.trim()));
            }
        }
        break;
    }
    Err(format!(
        "no 'Reviews' column found. Set 'Reviews column' in config.json (reviews_column). Columns: {}",
        seen.join(", ")
    ))
}

fn blank_row(r: &[String]) -> bool {
    r.iter().all(|c| c.trim().is_empty())
}

pub fn column_letter(i: usize) -> String {
    let mut s = String::new();
    let mut n = i + 1;
    while n > 0 {
        s.insert(0, (b'A' + ((n - 1) % 26) as u8) as char);
        n = (n - 1) / 26;
    }
    s
}

/// Writes 9.87654321E9 as 9876543210 (Excel stores long numbers that way).
fn plain_number(f: f64) -> String {
    if f.is_finite() && f.fract() == 0.0 && f.abs() < 1e15 {
        format!("{}", f as i64)
    } else {
        format!("{f}")
    }
}

fn cell_text(d: &Data) -> String {
    match d {
        Data::Empty | Data::Error(_) => String::new(),
        Data::String(s) => s.clone(),
        Data::Float(f) => plain_number(*f),
        Data::Int(i) => i.to_string(),
        Data::Bool(b) => if *b { "1".into() } else { "0".into() },
        Data::DateTime(dt) => plain_number(dt.as_f64()),
        Data::DateTimeIso(s) | Data::DurationIso(s) => s.clone(),
    }
}

/// The cells of the first sheet of an .xlsx file (or of a .csv file) as rows of text.
fn read_sheet(file: &str) -> Result<Vec<Vec<String>>, String> {
    let ext = Path::new(file).extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
    if ext == "csv" {
        let mut rdr = csv::ReaderBuilder::new().has_headers(false).flexible(true).from_path(file).map_err(|e| e.to_string())?;
        let mut rows = Vec::new();
        for rec in rdr.records() {
            let rec = rec.map_err(|e| e.to_string())?;
            let mut row: Vec<String> = rec.iter().map(str::to_string).collect();
            if let Some(first) = row.first_mut() {
                *first = first.trim_start_matches('\u{feff}').to_string();
            }
            rows.push(row);
        }
        return Ok(rows);
    }
    let mut wb = calamine::open_workbook_auto(file).map_err(|e| format!("cannot open as .xlsx: {e}"))?;
    let range = match wb.worksheet_range_at(0) {
        Some(Ok(r)) => r,
        Some(Err(e)) => return Err(format!("cannot read the worksheet: {e}")),
        None => return Err("no worksheet found in the file".into()),
    };
    let col0 = range.start().map(|(_, c)| c as usize).unwrap_or(0);
    let mut rows = Vec::new();
    for r in range.rows() {
        let mut row = vec![String::new(); col0];
        row.extend(r.iter().map(cell_text));
        rows.push(row);
    }
    Ok(rows)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn csv_file(name: &str, body: &str) -> String {
        let p = std::env::temp_dir().join(format!("wa-sms-test-{}-{name}", std::process::id()));
        std::fs::File::create(&p).unwrap().write_all(body.as_bytes()).unwrap();
        p.to_string_lossy().to_string()
    }

    #[test]
    fn column_letters() {
        assert_eq!(column_letter(0), "A");
        assert_eq!(column_letter(25), "Z");
        assert_eq!(column_letter(26), "AA");
    }

    #[test]
    fn numbers_are_written_plainly() {
        assert_eq!(plain_number(9.87654321e9), "9876543210");
        assert_eq!(plain_number(12.0), "12");
        assert_eq!(plain_number(3.5), "3.5");
    }

    #[test]
    fn loads_branches_skips_total_and_duplicates() {
        let f = csv_file(
            "a.csv",
            "Report,,\nS.No,Branch Name,Reviews\n1,Kovilpatti,9\n2,Ramnad-2,\"1,037\"\n3,ramnad2,5\n4,Zero Town,0\n,Total,1046\n",
        );
        let (b, note) = load_branches(&f, "").unwrap();
        assert_eq!(b.len(), 3);
        assert_eq!((b[0].name.as_str(), b[0].reviews), ("Kovilpatti", 9));
        assert_eq!((b[1].name.as_str(), b[1].reviews), ("Ramnad-2", 1037));
        assert_eq!(b[2].reviews, 0);
        assert_eq!(note, "1 duplicate branch row(s) skipped");
    }

    #[test]
    fn reviews_column_letter_override() {
        let f = csv_file("b.csv", "Place,Count\nAlpha,4\nBeta,7\n");
        assert!(load_branches(&f, "").is_err()); // no header containing "review"
        let (b, _) = load_branches(&f, "b").unwrap();
        assert_eq!((b[0].name.as_str(), b[0].reviews, b[1].reviews), ("Alpha", 4, 7));
    }

    #[test]
    fn missing_file_and_bad_letter() {
        assert!(load_branches("/nonexistent/x.xlsx", "").unwrap_err().contains("not found"));
        let f = csv_file("c.csv", "Branch,Reviews\nA,1\n");
        assert!(load_branches(&f, "9").unwrap_err().contains("not a valid column letter"));
        assert!(load_branches(&f, "Z").unwrap_err().contains("not a column in this sheet"));
    }
}
