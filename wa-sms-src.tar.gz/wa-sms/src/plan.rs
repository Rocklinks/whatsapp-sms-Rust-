use crate::branches::Row;
use crate::config::Cfg;
use std::collections::{HashMap, HashSet};

// ---------------- message texts ----------------

/// Fills {branch} and {reviews} into the template.
pub fn render_template(tpl: &str, branch: &str, reviews: i64) -> String {
    tpl.replace("{branch}", branch).replace("{reviews}", &reviews.to_string())
}

/// The text an AGM gets: the words before the first {placeholder} are written once, the
/// rest is repeated for every branch.
///
///   "Till now 9 Reviews for Kovilpatti, 37 Reviews for Ramnad"
pub fn list_message(tpl: &str, rows: &[&Row]) -> String {
    let Some(i) = tpl.find('{') else { return tpl.to_string() };
    let (intro, each) = tpl.split_at(i);
    let parts: Vec<String> = rows.iter().map(|r| render_template(each, &r.branch, r.reviews)).collect();
    format!("{intro}{}", parts.join(", "))
}

// ---------------- what one Send will deliver ----------------

/// Position of a person in the table: (row index, person index).
pub type Who = (usize, usize);

/// One message to one phone.
#[derive(Clone, Debug)]
pub struct Job {
    pub role: String,
    pub label: String,
    pub phone: String,
    pub message: String,
    pub wa: bool,
    pub sms: bool,
    /// Every entry in the table this message answers for (their status follows the job).
    pub who: Vec<Who>,
}

/// The result of looking at the ticks: the messages to send and what could not be covered.
#[derive(Debug, Default)]
pub struct Plan {
    pub jobs: Vec<Job>,
    pub by_role: HashMap<String, usize>, // messages per role (upper-case)
    pub ticked: usize,                   // ticked branches
    pub no_contact: Vec<String>,         // ticked branches without anybody in the ticked roles
    pub missing: HashMap<String, Vec<String>>, // ticked role -> ticked branches that have nobody with that role
}

struct CoverGroup {
    who: Vec<Who>,
    rows: Vec<usize>,
}

/// Works out the messages for the ticked branches and the ticked roles.
///
///  - a branch-level person (BM, ASM, CRM ...) gets one message per ticked branch;
///  - an AGM gets ONE message with all his ticked branches (or one per branch, see Cfg.agm_message);
///  - in Custom mode everybody gets the custom text, once per phone.
///
/// Planning only reads; nothing is changed, so it can be repeated for a preview.
/// There is no send history: every plan is a plan to send, so a message can always be sent again.
pub fn build_plan(rows: &[Row], cfg: &Cfg, roles: &HashSet<String>) -> Plan {
    let mut p = Plan::default();
    let mut jobs: HashMap<String, usize> = HashMap::new(); // phone|text -> index in p.jobs
    let mut groups: HashMap<String, CoverGroup> = HashMap::new(); // role|phone -> branches of an AGM
    let mut group_order: Vec<String> = Vec::new();

    // two entries for the same phone and text share one job
    let mut add_job = |p: &mut Plan, who: Vec<Who>, role: &str, phone: &str, label: String, text: String| {
        let key = format!("{phone}\u{0}{text}");
        if let Some(&i) = jobs.get(&key) {
            p.jobs[i].who.extend(who);
            return;
        }
        jobs.insert(key, p.jobs.len());
        p.jobs.push(Job { role: role.to_string(), label, phone: phone.to_string(), message: text, wa: cfg.use_wa, sms: cfg.use_sms, who });
        *p.by_role.entry(role.to_uppercase()).or_insert(0) += 1;
    };

    for (ri, row) in rows.iter().enumerate() {
        if !row.ticked {
            continue;
        }
        p.ticked += 1;
        let has: HashSet<String> = row.people.iter().map(|x| x.contact.role.to_uppercase()).collect();
        for role in roles {
            if !has.contains(role) {
                p.missing.entry(role.clone()).or_default().push(row.branch.clone());
            }
        }

        let mut reached = false;
        for (pi, person) in row.people.iter().enumerate() {
            let c = &person.contact;
            if !roles.contains(&c.role.to_uppercase()) {
                continue;
            }
            reached = true;
            if c.cover {
                let key = format!("{}|{}", c.role.to_uppercase(), c.phone);
                if !groups.contains_key(&key) {
                    groups.insert(key.clone(), CoverGroup { who: Vec::new(), rows: Vec::new() });
                    group_order.push(key.clone());
                }
                let g = groups.get_mut(&key).unwrap();
                g.who.push((ri, pi));
                g.rows.push(ri);
                continue;
            }
            let text = if cfg.mode == "custom" { cfg.custom.clone() } else { render_template(&cfg.template, &row.branch, row.reviews) };
            add_job(&mut p, vec![(ri, pi)], &c.role, &c.phone, format!("{} / {}", row.branch, c.label()), text);
        }
        if !reached {
            p.no_contact.push(row.branch.clone());
        }
    }

    for key in group_order {
        let g = &groups[&key];
        let (r0, p0) = g.who[0];
        let first = &rows[r0].people[p0].contact;
        let name = first.label();
        if cfg.mode == "custom" {
            add_job(&mut p, g.who.clone(), &first.role, &first.phone, name, cfg.custom.clone());
        } else if cfg.agm_message == "separate" {
            for (i, &(ri, pi)) in g.who.iter().enumerate() {
                let row = &rows[g.rows[i]];
                let c = &rows[ri].people[pi].contact;
                add_job(
                    &mut p,
                    vec![(ri, pi)],
                    &c.role,
                    &c.phone,
                    format!("{} / {}", name, row.branch),
                    render_template(&cfg.template, &row.branch, row.reviews),
                );
            }
        } else {
            let list: Vec<&Row> = g.rows.iter().map(|&i| &rows[i]).collect();
            add_job(
                &mut p,
                g.who.clone(),
                &first.role,
                &first.phone,
                format!("{} ({} branches)", name, g.rows.len()),
                list_message(&cfg.template, &list),
            );
        }
    }
    p
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::branches::{build_rows, Branch};
    use crate::contacts::{role_set, Contact};

    fn setup() -> (Vec<Row>, Cfg) {
        let branches = vec![
            Branch { name: "Kovilpatti".into(), reviews: 9 },
            Branch { name: "Ramnad".into(), reviews: 37 },
        ];
        let c = |role: &str, phone: &str, branch: &str| Contact { role: role.into(), phone: phone.into(), branch: branch.into(), ..Default::default() };
        let contacts = vec![
            c("BM", "919000000001", "Kovilpatti"),
            c("BM", "919000000002", "Ramnad"),
            c("ASM", "919000000003", "Ramnad"),
            Contact { role: "AGM".into(), name: "AGM 01".into(), phone: "919000000009".into(), cover: true, branches: vec!["Kovilpatti".into(), "Ramnad".into()], ..Default::default() },
        ];
        let (mut rows, _) = build_rows(&branches, &contacts, &[]);
        rows[0].ticked = true;
        rows[1].ticked = true;
        (rows, Cfg::default())
    }

    #[test]
    fn templates_and_agm_list() {
        assert_eq!(render_template("Till now {reviews} Reviews for {branch}", "Ramnad", 37), "Till now 37 Reviews for Ramnad");
        let (rows, cfg) = setup();
        let list: Vec<&Row> = rows.iter().collect();
        assert_eq!(list_message(&cfg.template, &list), "Till now 9 Reviews for Kovilpatti, 37 Reviews for Ramnad");
        assert_eq!(list_message("no placeholder", &list), "no placeholder");
    }

    #[test]
    fn bm_one_per_branch_agm_one_combined() {
        let (rows, cfg) = setup();
        let plan = build_plan(&rows, &cfg, &role_set(&["BM".into(), "AGM".into()]));
        assert_eq!(plan.jobs.len(), 3);
        assert_eq!(plan.by_role["BM"], 2);
        assert_eq!(plan.by_role["AGM"], 1);
        let agm = plan.jobs.iter().find(|j| j.role == "AGM").unwrap();
        assert_eq!(agm.message, "Till now 9 Reviews for Kovilpatti, 37 Reviews for Ramnad");
        assert_eq!(agm.who.len(), 2);
        assert!(plan.missing.get("AGM").is_none()); // nobody is missing an AGM
    }

    #[test]
    fn agm_separate_gives_one_message_per_branch() {
        let (rows, mut cfg) = setup();
        cfg.agm_message = "separate".into();
        let plan = build_plan(&rows, &cfg, &role_set(&["AGM".into()]));
        assert_eq!(plan.jobs.len(), 2);
        assert_eq!(plan.jobs[0].message, "Till now 9 Reviews for Kovilpatti");
    }

    #[test]
    fn custom_text_goes_once_per_phone() {
        let (rows, mut cfg) = setup();
        cfg.mode = "custom".into();
        cfg.custom = "Hello all".into();
        let plan = build_plan(&rows, &cfg, &role_set(&["BM".into(), "AGM".into()]));
        assert_eq!(plan.jobs.len(), 3);
        assert!(plan.jobs.iter().all(|j| j.message == "Hello all"));
    }

    #[test]
    fn missing_roles_and_no_contact_are_reported() {
        let (rows, cfg) = setup();
        let plan = build_plan(&rows, &cfg, &role_set(&["ASM".into()]));
        assert_eq!(plan.jobs.len(), 1);
        assert_eq!(plan.missing["ASM"], vec!["Kovilpatti"]);
        assert_eq!(plan.no_contact, vec!["Kovilpatti"]);
    }

    /// Fix 1: sending the same text again is never blocked or questioned - planning twice gives the same jobs.
    #[test]
    fn same_message_can_always_be_planned_again() {
        let (rows, cfg) = setup();
        let roles = role_set(&["BM".into()]);
        let a = build_plan(&rows, &cfg, &roles);
        let b = build_plan(&rows, &cfg, &roles);
        assert_eq!(a.jobs.len(), 2);
        assert_eq!(a.jobs.len(), b.jobs.len());
        assert!(a.jobs.iter().all(|j| j.wa));
    }
}
