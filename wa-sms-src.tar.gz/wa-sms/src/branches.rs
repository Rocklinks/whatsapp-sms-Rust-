use crate::contacts::Contact;
use std::collections::{HashMap, HashSet};

/// One line of the Excel sheet.
#[derive(Clone, Debug, PartialEq)]
pub struct Branch {
    pub name: String,
    pub reviews: i64,
}

/// Reduces a branch name to lower-case letters and digits, so that
/// "Aruppukottai -2", "aruppukottai-2" and "Aruppukottai2" are the same name.
pub fn key_name(s: &str) -> String {
    s.to_lowercase().chars().filter(|r| r.is_ascii_lowercase() || r.is_ascii_digit() || (*r as u32) > 127).collect()
}

/// 1 for equal text and falls towards 0 with every letter that differs (edit distance).
fn similarity(a: &str, b: &str) -> f64 {
    let x: Vec<char> = a.chars().collect();
    let y: Vec<char> = b.chars().collect();
    if x.is_empty() && y.is_empty() {
        return 1.0;
    }
    let mut prev: Vec<usize> = (0..=y.len()).collect();
    let mut cur = vec![0usize; y.len() + 1];
    for i in 1..=x.len() {
        cur[0] = i;
        for j in 1..=y.len() {
            let cost = usize::from(x[i - 1] != y[j - 1]);
            cur[j] = (prev[j] + 1).min(cur[j - 1] + 1).min(prev[j - 1] + cost);
        }
        std::mem::swap(&mut prev, &mut cur);
    }
    1.0 - prev[y.len()] as f64 / x.len().max(y.len()) as f64
}

fn score(name: &str, key: &str) -> f64 {
    let k = key_name(name);
    if k.is_empty() || key.is_empty() {
        return 0.0;
    }
    if k == key {
        return 1.0;
    }
    let mut s = similarity(&k, key);
    let (mut short, mut long) = (k.as_str(), key);
    if short.len() > long.len() {
        std::mem::swap(&mut short, &mut long);
    }
    if short.chars().count() >= 5 && long.contains(short) && s < 0.9 {
        s = 0.9; // "Kayathar" inside "Kayathar-1"
    }
    s
}

/// Finds, for every branch name written in the contacts file, the Excel branch it means.
/// Small spelling differences are fine (Tenkasi / Thenkasi, Ramnad2 / Ramnad-2).
///
///   pass 1  a clear winner with similarity >= 0.85 (several names may share one Excel branch)
///   pass 2  what is left may take an Excel branch nobody else took, similarity >= 0.80
///
/// Ties are never guessed: a name that fits two branches equally well stays unmatched.
/// The result maps the name as written in the file to an index into `branches`.
pub fn match_branches(names: &[String], branches: &[Branch]) -> HashMap<String, usize> {
    let keys: Vec<String> = branches.iter().map(|b| key_name(&b.name)).collect();
    let mut matched: HashMap<String, usize> = HashMap::new();
    let mut taken: HashSet<usize> = HashSet::new();
    let mut open: Vec<&String> = Vec::new();
    for name in names {
        let (mut best, mut at, mut ties) = (0.0f64, usize::MAX, 0);
        for (i, key) in keys.iter().enumerate() {
            let s = score(name, key);
            if s > best + 1e-9 {
                best = s;
                at = i;
                ties = 1;
            } else if s > 0.0 && s > best - 1e-9 {
                ties += 1;
            }
        }
        if best >= 0.85 && ties == 1 {
            matched.insert(name.clone(), at);
            taken.insert(at);
        } else {
            open.push(name);
        }
    }

    struct Pair<'a> {
        name: &'a String,
        index: usize,
        score: f64,
    }
    let mut pairs: Vec<Pair> = Vec::new();
    for name in &open {
        for (i, key) in keys.iter().enumerate() {
            let s = score(name, key);
            if !taken.contains(&i) && s >= 0.80 {
                pairs.push(Pair { name, index: i, score: s });
            }
        }
    }
    pairs.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal)); // stable
    for p in pairs {
        if !matched.contains_key(p.name) && !taken.contains(&p.index) {
            matched.insert(p.name.clone(), p.index);
            taken.insert(p.index);
        }
    }
    matched
}

/// What happened to one person in the last send.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SendState {
    NotSent,
    Sent,
    Failed,
}

/// A person attached to a branch row, with the result of the last send.
#[derive(Clone, Debug)]
pub struct Recipient {
    pub contact: Contact,
    pub state: SendState,
}

/// One branch of the Excel sheet together with everybody who belongs to it.
#[derive(Clone, Debug)]
pub struct Row {
    pub branch: String,
    pub reviews: i64,
    pub ticked: bool,
    pub people: Vec<Recipient>,
}

/// Joins the Excel branches with the contacts. The previous rows are only used to keep the
/// ticks. `unmatched` lists branch names in the contacts that no Excel branch fits.
pub fn build_rows(branches: &[Branch], contacts: &[Contact], previous: &[Row]) -> (Vec<Row>, Vec<String>) {
    let ticked: HashSet<String> = previous.iter().filter(|r| r.ticked).map(|r| key_name(&r.branch)).collect();
    let mut rows: Vec<Row> = branches
        .iter()
        .map(|b| Row { branch: b.name.clone(), reviews: b.reviews, ticked: ticked.contains(&key_name(&b.name)), people: Vec::new() })
        .collect();

    let mut names: Vec<String> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    let mut note = |n: &str| {
        if !n.is_empty() && seen.insert(n.to_string()) {
            names.push(n.to_string());
        }
    };
    for c in contacts {
        note(&c.branch);
        for n in &c.branches {
            note(n);
        }
    }
    let matched = match_branches(&names, branches);

    for c in contacts {
        if !c.cover {
            if let Some(&i) = matched.get(&c.branch) {
                rows[i].people.push(Recipient { contact: c.clone(), state: SendState::NotSent });
            }
            continue;
        }
        let mut done: HashSet<usize> = HashSet::new(); // an AGM is added once per branch, even if two file names fit it
        for n in &c.branches {
            if let Some(&i) = matched.get(n) {
                if done.insert(i) {
                    rows[i].people.push(Recipient { contact: c.clone(), state: SendState::NotSent });
                }
            }
        }
    }
    let mut unmatched: Vec<String> = names.into_iter().filter(|n| !matched.contains_key(n)).collect();
    unmatched.sort();
    (rows, unmatched)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn b(name: &str) -> Branch {
        Branch { name: name.into(), reviews: 1 }
    }

    #[test]
    fn key_names_ignore_spacing_and_case() {
        assert_eq!(key_name("Aruppukottai -2"), "aruppukottai2");
        assert_eq!(key_name("ARUPPUKOTTAI2"), "aruppukottai2");
    }

    #[test]
    fn spelling_variants_match() {
        let branches = vec![b("Tenkasi"), b("Ramnad-2"), b("Kovilpatti")];
        let names: Vec<String> = ["Thenkasi", "Ramnad2", "Kovilpatti", "Nowhere"].iter().map(|s| s.to_string()).collect();
        let m = match_branches(&names, &branches);
        assert_eq!(m["Thenkasi"], 0);
        assert_eq!(m["Ramnad2"], 1);
        assert_eq!(m["Kovilpatti"], 2);
        assert!(!m.contains_key("Nowhere"));
    }

    #[test]
    fn a_branch_is_never_taken_twice_in_the_second_pass() {
        // both names fit both free branches equally well: the second pass hands them out one by one
        let branches = vec![b("Kayathar-1"), b("Kayathar-2")];
        let names = vec!["Kayathar".to_string(), "Kayathar ".to_string()];
        let m = match_branches(&names, &branches);
        assert_eq!(m.len(), 2);
        assert_ne!(m["Kayathar"], m["Kayathar "]);
        // a single exact name is a clear winner and never needs the second pass
        let m = match_branches(&["Kayathar-2".to_string()], &branches);
        assert_eq!(m["Kayathar-2"], 1);
    }

    #[test]
    fn rows_keep_ticks_and_attach_people() {
        let branches = vec![b("Alpha Town"), b("Beta City")];
        let contacts = vec![
            Contact { role: "BM".into(), phone: "919000000001".into(), branch: "alpha town".into(), ..Default::default() },
            Contact { role: "AGM".into(), phone: "919000000002".into(), cover: true, branches: vec!["Alpha Town".into(), "Beta City".into(), "Gone".into()], ..Default::default() },
        ];
        let mut prev = build_rows(&branches, &[], &[]).0;
        prev[1].ticked = true;
        let (rows, unmatched) = build_rows(&branches, &contacts, &prev);
        assert!(!rows[0].ticked && rows[1].ticked);
        assert_eq!(rows[0].people.len(), 2);
        assert_eq!(rows[1].people.len(), 1);
        assert_eq!(unmatched, vec!["Gone"]);
    }
}
