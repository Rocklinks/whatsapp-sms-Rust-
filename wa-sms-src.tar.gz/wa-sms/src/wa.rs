use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use whatsapp_rust::pair_code::PairCodeOptions;
use whatsapp_rust::prelude::*;
use whatsapp_rust::upload::{UploadOptions, UploadResponse};
use whatsapp_rust::wacore::download::MediaType;
use whatsapp_rust::wacore::store::DevicePropsOverride;

use crate::config::data_dir;

// WhatsApp works through the whatsapp-rust library: link the computer once (QR code or pairing
// code), then send text or a file. The linked session is kept in data/whatsapp-session.db.
//
// This computer introduces itself to WhatsApp as Google Chrome on Linux (see `build_bot`), and
// it never asks for - or keeps - any chat history: it only sends.

/// Why a send failed. "Not on WhatsApp" is final, everything else may be retried.
#[derive(Debug, Clone, PartialEq)]
pub enum WaError {
    NotOnWhatsApp,
    Other(String),
}

impl std::fmt::Display for WaError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            WaError::NotOnWhatsApp => write!(f, "this number is not on WhatsApp"),
            WaError::Other(s) => write!(f, "{s}"),
        }
    }
}

impl From<String> for WaError {
    fn from(s: String) -> Self {
        WaError::Other(s)
    }
}

// ---------------- attachment ----------------

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Image,
    Video,
    Audio,
    Document,
}

impl Kind {
    pub fn name(self) -> &'static str {
        match self {
            Kind::Image => "image",
            Kind::Video => "video",
            Kind::Audio => "audio",
            Kind::Document => "document",
        }
    }
}

/// A file sent with the message. It is uploaded to WhatsApp once and reused for every person.
pub struct Attachment {
    pub path: PathBuf,
    pub kind: Kind,
    pub mime: String,
    upload: tokio::sync::Mutex<Option<UploadResponse>>,
}

/// What a file really is, from its first bytes (the extension is only a fallback), so that a video is
/// sent as a video, a song as audio, a picture as an image and everything else as a document.
fn sniff(h: &[u8]) -> Option<(Kind, &'static str)> {
    let at = |i: usize, s: &[u8]| h.len() >= i + s.len() && &h[i..i + s.len()] == s;
    if at(0, &[0xFF, 0xD8, 0xFF]) {
        return Some((Kind::Image, "image/jpeg"));
    }
    if at(0, &[0x89, b'P', b'N', b'G']) {
        return Some((Kind::Image, "image/png"));
    }
    if at(0, b"GIF8") {
        return Some((Kind::Image, "image/gif"));
    }
    if at(0, b"RIFF") && at(8, b"WEBP") {
        return Some((Kind::Image, "image/webp"));
    }
    if at(0, b"RIFF") && at(8, b"WAVE") {
        return Some((Kind::Audio, "audio/wav"));
    }
    if at(4, b"ftyp") {
        let brand = &h[8.min(h.len())..12.min(h.len())];
        return Some(match brand {
            b"M4A " | b"M4B " | b"M4P " => (Kind::Audio, "audio/mp4"),
            b"heic" | b"heix" | b"mif1" => (Kind::Image, "image/heic"),
            b if b.starts_with(b"3gp") => (Kind::Video, "video/3gpp"),
            _ => (Kind::Video, "video/mp4"),
        });
    }
    if at(0, b"OggS") {
        return Some((Kind::Audio, "audio/ogg; codecs=opus"));
    }
    if at(0, b"fLaC") {
        return Some((Kind::Audio, "audio/flac"));
    }
    if at(0, b"#!AMR") {
        return Some((Kind::Audio, "audio/amr"));
    }
    if at(0, b"ID3") {
        return Some((Kind::Audio, "audio/mpeg"));
    }
    if h.len() >= 2 && h[0] == 0xFF && (h[1] & 0xF6) == 0xF0 {
        return Some((Kind::Audio, "audio/aac"));
    }
    if h.len() >= 2 && h[0] == 0xFF && (h[1] & 0xE0) == 0xE0 {
        return Some((Kind::Audio, "audio/mpeg"));
    }
    if at(0, &[0x1A, 0x45, 0xDF, 0xA3]) {
        return Some((Kind::Document, "video/x-matroska")); // mkv / webm: WhatsApp cannot play them as video
    }
    if at(0, b"%PDF") {
        return Some((Kind::Document, "application/pdf"));
    }
    None
}

/// Kind and MIME type of a file: from its content first, then from its extension.
pub fn detect(path: &str) -> (Kind, String) {
    let mut head = [0u8; 16];
    let n = std::fs::File::open(path).and_then(|mut f| std::io::Read::read(&mut f, &mut head)).unwrap_or(0);
    if let Some((k, m)) = sniff(&head[..n]) {
        return (k, m.to_string());
    }
    let ext = Path::new(path).extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
    let (k, m): (Kind, &str) = match ext.as_str() {
        "jpg" | "jpeg" => (Kind::Image, "image/jpeg"),
        "png" | "webp" | "gif" => (Kind::Image, mime_for(&ext)),
        "mp4" | "mov" | "m4v" => (Kind::Video, "video/mp4"),
        "3gp" => (Kind::Video, "video/3gpp"),
        "mp3" => (Kind::Audio, "audio/mpeg"),
        "m4a" => (Kind::Audio, "audio/mp4"),
        "aac" => (Kind::Audio, "audio/aac"),
        "ogg" | "oga" | "opus" => (Kind::Audio, "audio/ogg; codecs=opus"),
        "wav" => (Kind::Audio, "audio/wav"),
        "flac" => (Kind::Audio, "audio/flac"),
        "amr" => (Kind::Audio, "audio/amr"),
        _ => (Kind::Document, mime_for(&ext)),
    };
    (k, m.to_string())
}

fn mime_for(ext: &str) -> &'static str {
    match ext {
        "pdf" => "application/pdf",
        "png" => "image/png",
        "webp" => "image/webp",
        "gif" => "image/gif",
        "doc" => "application/msword",
        "docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "xls" => "application/vnd.ms-excel",
        "xlsx" | "xlsm" => "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "ppt" => "application/vnd.ms-powerpoint",
        "pptx" => "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "txt" | "log" => "text/plain",
        "csv" => "text/csv",
        "json" => "application/json",
        "zip" => "application/zip",
        "mp3" => "audio/mpeg",
        "ogg" => "audio/ogg",
        "wav" => "audio/wav",
        "html" | "htm" => "text/html",
        "rtf" => "application/rtf",
        "odt" => "application/vnd.oasis.opendocument.text",
        "ods" => "application/vnd.oasis.opendocument.spreadsheet",
        "rar" => "application/vnd.rar",
        "7z" => "application/x-7z-compressed",
        "xml" => "application/xml",
        "jpg" | "jpeg" => "image/jpeg",
        "mp4" => "video/mp4",
        "webm" => "video/webm",
        "mkv" => "video/x-matroska",
        _ => "application/octet-stream",
    }
}

impl Attachment {
    pub fn new(path: &str) -> Result<Attachment, String> {
        let meta = std::fs::metadata(path).map_err(|_| format!("attachment not found: {path}"))?;
        if meta.is_dir() || meta.len() == 0 {
            return Err(format!("attachment is not a usable file: {path}"));
        }
        if meta.len() > 95 << 20 {
            let name = Path::new(path).file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
            return Err(format!("attachment is too big for WhatsApp (about 95 MB at most): {name}"));
        }
        let (kind, mime) = detect(path);
        Ok(Attachment { path: PathBuf::from(path), kind, mime, upload: tokio::sync::Mutex::new(None) })
    }

    /// The attachment uploaded to WhatsApp (uploading it the first time).
    async fn uploaded(&self, client: &Arc<Client>) -> Result<UploadResponse, String> {
        let mut slot = self.upload.lock().await;
        if let Some(up) = slot.as_ref() {
            return Ok(up.clone());
        }
        let path = self.path.clone();
        let data = tokio::task::spawn_blocking(move || std::fs::read(path))
            .await
            .map_err(|e| e.to_string())?
            .map_err(|e| e.to_string())?;
        let media = match self.kind {
            Kind::Image => MediaType::Image,
            Kind::Video => MediaType::Video,
            Kind::Audio => MediaType::Audio,
            Kind::Document => MediaType::Document,
        };
        let up = tokio::time::timeout(Duration::from_secs(180), client.upload(data, media, UploadOptions::default()))
            .await
            .map_err(|_| "file upload failed: timed out".to_string())?
            .map_err(|e| format!("file upload failed: {e}"))?;
        *slot = Some(up.clone());
        Ok(up)
    }

    fn file_name(&self) -> String {
        self.path.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| "file".into())
    }

    async fn message(&self, client: &Arc<Client>, text: &str) -> Result<wa::Message, String> {
        let up = self.uploaded(client).await?;
        let caption = if text.trim().is_empty() { None } else { Some(text.to_string()) };
        let mime = Some(self.mime.clone());
        let msg = match self.kind {
            Kind::Image => wa::Message {
                image_message: MessageField::some(wa::message::ImageMessage {
                    url: Some(up.url.clone()),
                    direct_path: Some(up.direct_path.clone()),
                    media_key: Some(up.media_key.to_vec().into()),
                    mimetype: mime,
                    caption,
                    file_enc_sha256: Some(up.file_enc_sha256.to_vec().into()),
                    file_sha256: Some(up.file_sha256.to_vec().into()),
                    file_length: Some(up.file_length),
                    ..Default::default()
                }),
                ..Default::default()
            },
            Kind::Video => wa::Message {
                video_message: MessageField::some(wa::message::VideoMessage {
                    url: Some(up.url.clone()),
                    direct_path: Some(up.direct_path.clone()),
                    media_key: Some(up.media_key.to_vec().into()),
                    mimetype: mime,
                    caption,
                    file_enc_sha256: Some(up.file_enc_sha256.to_vec().into()),
                    file_sha256: Some(up.file_sha256.to_vec().into()),
                    file_length: Some(up.file_length),
                    streaming_sidecar: up.streaming_sidecar.clone().map(Into::into),
                    ..Default::default()
                }),
                ..Default::default()
            },
            Kind::Audio => wa::Message {
                audio_message: MessageField::some(wa::message::AudioMessage {
                    url: Some(up.url.clone()),
                    direct_path: Some(up.direct_path.clone()),
                    media_key: Some(up.media_key.to_vec().into()),
                    mimetype: mime,
                    file_enc_sha256: Some(up.file_enc_sha256.to_vec().into()),
                    file_sha256: Some(up.file_sha256.to_vec().into()),
                    file_length: Some(up.file_length),
                    ..Default::default()
                }),
                ..Default::default()
            },
            Kind::Document => {
                let name = self.file_name();
                wa::Message {
                    document_message: MessageField::some(wa::message::DocumentMessage {
                        url: Some(up.url.clone()),
                        direct_path: Some(up.direct_path.clone()),
                        media_key: Some(up.media_key.to_vec().into()),
                        mimetype: mime,
                        file_name: Some(name.clone()),
                        title: Some(name),
                        caption,
                        file_enc_sha256: Some(up.file_enc_sha256.to_vec().into()),
                        file_sha256: Some(up.file_sha256.to_vec().into()),
                        file_length: Some(up.file_length),
                        ..Default::default()
                    }),
                    ..Default::default()
                }
            }
        };
        Ok(msg)
    }
}

// ---------------- the linked session ----------------

#[derive(Default)]
struct Inner {
    status: String, // CONNECTED, not linked, connecting ...
    detail: String,
    qr: String,        // the current QR code while linking
    pair_code: String, // the current 8 character pairing code
    pair_error: String,
    handle: Option<BotHandle>,
    client: Option<Arc<Client>>,
    generation: u64, // events of an older bot are ignored
}

/// The WhatsApp session. Cheap to share between threads.
pub struct Wa {
    rt: Arc<tokio::runtime::Runtime>,
    inner: Arc<Mutex<Inner>>,
    version: Arc<AtomicU64>, // grows with every change of status or QR code
}

fn lock(m: &Mutex<Inner>) -> std::sync::MutexGuard<'_, Inner> {
    m.lock().unwrap_or_else(|p| p.into_inner())
}

pub fn session_db_path() -> PathBuf {
    data_dir().join("whatsapp-session.db")
}

impl Wa {
    pub fn new() -> Wa {
        let rt = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .thread_name("wa-sms-net")
            .build()
            .expect("cannot start the network runtime");
        Wa { rt: Arc::new(rt), inner: Arc::new(Mutex::new(Inner::default())), version: Arc::new(AtomicU64::new(1)) }
    }

    /// Changes whenever the status, the detail, the QR code or a pairing code changed.
    pub fn version(&self) -> u64 {
        self.version.load(Ordering::Relaxed)
    }

    fn set_status(&self, status: &str, detail: &str) {
        set_status(&self.inner, &self.version, None, status, detail);
    }

    pub fn status(&self) -> String {
        let s = lock(&self.inner).status.clone();
        if s.is_empty() { "starting".into() } else { s }
    }

    pub fn detail(&self) -> String {
        lock(&self.inner).detail.clone()
    }

    pub fn qr(&self) -> String {
        lock(&self.inner).qr.clone()
    }

    pub fn connected(&self) -> bool {
        match &lock(&self.inner).client {
            Some(c) => c.is_connected() && c.is_logged_in(),
            None => false,
        }
    }

    /// Whether this computer has a WhatsApp session (connected right now or not).
    pub fn linked(&self) -> bool {
        match &lock(&self.inner).client {
            Some(c) => c.persistence_manager().get_device_snapshot().pn.is_some(),
            None => false,
        }
    }

    /// Builds the client. This is where the two important choices are made:
    ///  * the computer introduces itself as Google Chrome on Linux;
    ///  * no chat history is requested or stored.
    async fn build_bot(&self, generation: u64, pair: Option<PairCodeOptions>) -> Result<Bot, String> {
        let path = session_db_path();
        let store = SqliteStore::new(&path.to_string_lossy()).await.map_err(|e| format!("WhatsApp session database: {e}"))?;

        let (i1, v1) = (self.inner.clone(), self.version.clone());
        let (i2, v2) = (self.inner.clone(), self.version.clone());
        let (i3, v3) = (self.inner.clone(), self.version.clone());
        let (i4, v4) = (self.inner.clone(), self.version.clone());
        let (i5, v5) = (self.inner.clone(), self.version.clone());

        let mut builder = Bot::builder()
            .with_backend(store)
            .with_device_props(
                DevicePropsOverride::new().with_os("Linux").with_platform_type(wa::device_props::PlatformType::CHROME),
            )
            .skip_history_sync()
            .on_qr_code(move |code, _timeout| {
                let (i, v) = (i1.clone(), v1.clone());
                async move {
                    {
                        let mut g = lock(&i);
                        if g.generation != generation {
                            return;
                        }
                        g.qr = code;
                    }
                    v.fetch_add(1, Ordering::Relaxed);
                }
            })
            .on_pair_code(move |code, _timeout| {
                let (i, v) = (i2.clone(), v2.clone());
                async move {
                    {
                        let mut g = lock(&i);
                        if g.generation != generation {
                            return;
                        }
                        g.pair_code = code;
                    }
                    v.fetch_add(1, Ordering::Relaxed);
                }
            })
            .on_connected(move |_client| {
                let (i, v) = (i3.clone(), v3.clone());
                async move {
                    {
                        let mut g = lock(&i);
                        if g.generation != generation {
                            return;
                        }
                        g.qr.clear();
                    }
                    set_status(&i, &v, Some(generation), "CONNECTED", "");
                }
            })
            .on_logged_out(move |info| {
                let (i, v) = (i4.clone(), v4.clone());
                async move {
                    lock(&i).qr.clear();
                    set_status(&i, &v, Some(generation), "logged out", &format!("{:?}", info.reason));
                }
            })
            .on_event(move |event, _client| {
                let (i, v) = (i5.clone(), v5.clone());
                async move {
                    match &*event {
                        Event::Disconnected(_) => {
                            let linked = lock(&i).client.as_ref().map(|c| c.persistence_manager().get_device_snapshot().pn.is_some()).unwrap_or(false);
                            if linked {
                                set_status(&i, &v, Some(generation), "reconnecting", "");
                            }
                        }
                        Event::PairSuccess(_) => {
                            lock(&i).qr.clear();
                            set_status(&i, &v, Some(generation), "linked", "connecting...");
                        }
                        Event::PairError(e) => {
                            lock(&i).qr.clear();
                            set_status(&i, &v, Some(generation), "pairing failed", &format!("{e:?}"));
                        }
                        Event::PairingQrCodesExhausted(_) => {
                            lock(&i).qr.clear();
                            set_status(&i, &v, Some(generation), "not linked", "the QR code expired - press F9 again");
                        }
                        Event::PairingCodeError(e) => {
                            {
                                let mut g = lock(&i);
                                if g.generation != generation {
                                    return;
                                }
                                g.pair_error = e.error.clone();
                            }
                            v.fetch_add(1, Ordering::Relaxed);
                        }
                        Event::StreamReplaced(_) => {
                            set_status(&i, &v, Some(generation), "opened elsewhere", "WhatsApp Web was opened on another computer with this link");
                        }
                        Event::ClientOutdated(_) => {
                            set_status(&i, &v, Some(generation), "error", "WhatsApp says this program version is too old");
                        }
                        _ => {}
                    }
                }
            });
        if let Some(options) = pair {
            builder = builder.with_pair_code(options);
        }
        builder.build().await.map_err(|e| format!("WhatsApp: {e}"))
    }

    /// Opens the session database and, when a session exists, connects (the library keeps reconnecting).
    pub fn start(&self) -> Result<(), String> {
        let generation = self.next_generation();
        let result: Result<(), String> = self.rt.block_on(async {
            let bot = match self.build_bot(generation, None).await {
                Ok(b) => b,
                Err(e) => {
                    self.set_status("error", &e);
                    return Err(e);
                }
            };
            let client = bot.client();
            let linked = client.persistence_manager().get_device_snapshot().pn.is_some();
            if !linked {
                lock(&self.inner).client = Some(client);
                self.set_status("not linked", "press F9 to link");
                return Ok(());
            }
            self.set_status("connecting", "");
            let handle = bot.spawn();
            let mut g = lock(&self.inner);
            g.client = Some(handle.client());
            g.handle = Some(handle);
            Ok(())
        });
        result
    }

    fn next_generation(&self) -> u64 {
        let mut g = lock(&self.inner);
        g.generation += 1;
        g.generation
    }

    /// Stops the running bot (if any) without touching the stored session.
    async fn stop_bot(&self) {
        let handle = {
            let mut g = lock(&self.inner);
            g.client = None;
            g.handle.take()
        };
        if let Some(h) = handle {
            let _ = tokio::time::timeout(Duration::from_secs(8), h.shutdown()).await;
        }
    }

    /// Starts linking with a QR code; the code is available through `qr()` while it is valid.
    pub fn link(&self) -> Result<(), String> {
        if self.linked() {
            return Err("WhatsApp is already linked".into());
        }
        self.rt.block_on(async {
            self.stop_bot().await;
            let generation = self.next_generation();
            {
                let mut g = lock(&self.inner);
                g.qr.clear();
                g.pair_code.clear();
                g.pair_error.clear();
            }
            let bot = self.build_bot(generation, None).await?;
            let handle = bot.spawn();
            {
                let mut g = lock(&self.inner);
                g.client = Some(handle.client());
                g.handle = Some(handle);
            }
            self.set_status("waiting for scan", "");
            Ok(())
        })
    }

    /// Cancels a linking that is waiting for the scan.
    pub fn stop_link(&self) {
        if self.linked() {
            return;
        }
        self.rt.block_on(async {
            self.stop_bot().await;
        });
        lock(&self.inner).qr.clear();
        self.set_status("not linked", "press F9 to link");
    }

    /// The alternative to the QR code: the phone asks for an 8 character code.
    pub fn pair_code(&self, phone: &str) -> Result<String, String> {
        self.rt.block_on(async {
            self.stop_bot().await;
            let generation = self.next_generation();
            {
                let mut g = lock(&self.inner);
                g.qr.clear();
                g.pair_code.clear();
                g.pair_error.clear();
            }
            let options = PairCodeOptions { phone_number: phone.to_string(), ..Default::default() };
            let bot = self.build_bot(generation, Some(options)).await?;
            let handle = bot.spawn();
            {
                let mut g = lock(&self.inner);
                g.client = Some(handle.client());
                g.handle = Some(handle);
            }
            self.set_status("waiting for pairing code", "");
            for _ in 0..120 {
                tokio::time::sleep(Duration::from_millis(250)).await;
                let g = lock(&self.inner);
                if !g.pair_code.is_empty() {
                    return Ok(g.pair_code.clone());
                }
                if !g.pair_error.is_empty() {
                    return Err(g.pair_error.clone());
                }
            }
            Err("no pairing code arrived in 30 seconds - check the internet connection".into())
        })
    }

    /// Unlinks this computer and prepares a fresh, unlinked session.
    pub fn logout(&self) -> Result<(), String> {
        let result: Result<(), String> = self.rt.block_on(async {
            let client = lock(&self.inner).client.clone();
            if let Some(c) = client {
                if c.persistence_manager().get_device_snapshot().pn.is_some() {
                    let _ = tokio::time::timeout(Duration::from_secs(15), c.logout()).await;
                }
            }
            self.stop_bot().await;
            Ok(())
        });
        // logging out does not wipe the stored keys: remove the session file so nothing stays behind
        let db = session_db_path();
        for suffix in ["", "-wal", "-shm", "-journal"] {
            let mut p = db.clone().into_os_string();
            p.push(suffix);
            let _ = std::fs::remove_file(PathBuf::from(p));
        }
        {
            let mut g = lock(&self.inner);
            g.qr.clear();
            g.pair_code.clear();
            g.generation += 1;
        }
        self.set_status("not linked", "logged out");
        result
    }

    /// Logs out and starts linking again.
    pub fn repair(&self) -> Result<(), String> {
        let _ = self.logout();
        self.link()
    }

    pub fn close(&self) {
        self.rt.block_on(async {
            self.stop_bot().await;
        });
    }

    // ---------------- sending ----------------

    /// Delivers the text, or the attachment with the text as its caption.
    pub fn send(&self, phone: &str, text: &str, attachment: Option<&Attachment>) -> Result<(), WaError> {
        let client = lock(&self.inner).client.clone();
        let Some(client) = client else { return Err(WaError::Other("WhatsApp is not connected".into())) };
        if !client.is_connected() || !client.is_logged_in() {
            return Err(WaError::Other("WhatsApp is not connected".into()));
        }
        self.rt.block_on(async {
            let work = async {
                let jid = Jid::pn(phone);
                // a lookup that fails for network reasons is not a reason to refuse: only a clear "no" is
                if let Ok(found) = client.contacts().is_on_whatsapp(std::slice::from_ref(&jid)).await {
                    match found.first() {
                        None => return Err(WaError::NotOnWhatsApp),
                        Some(r) if !r.is_registered => return Err(WaError::NotOnWhatsApp),
                        _ => {}
                    }
                }
                let message = match attachment {
                    None => wa::Message::text(text),
                    Some(a) => a.message(&client, text).await?,
                };
                client.send_message(jid.clone(), message).await.map_err(|e| WaError::Other(e.to_string()))?;
                // an audio message has no caption: the text follows as its own message
                if let Some(a) = attachment {
                    if a.kind == Kind::Audio && !text.trim().is_empty() {
                        client.send_message(jid, wa::Message::text(text)).await.map_err(|e| WaError::Other(e.to_string()))?;
                    }
                }
                Ok(())
            };
            match tokio::time::timeout(Duration::from_secs(60), work).await {
                Ok(r) => r,
                Err(_) => Err(WaError::Other("timed out after 60 seconds".into())),
            }
        })
    }
}

fn set_status(inner: &Arc<Mutex<Inner>>, version: &Arc<AtomicU64>, generation: Option<u64>, status: &str, detail: &str) {
    {
        let mut g = lock(inner);
        if let Some(gen_) = generation {
            if g.generation != gen_ {
                return;
            }
        }
        g.status = status.to_string();
        g.detail = detail.to_string();
    }
    version.fetch_add(1, Ordering::Relaxed);
}

#[cfg(test)]
mod detect_tests {
    use super::*;

    fn kind_of(name: &str, bytes: &[u8]) -> (Kind, String) {
        let p = std::env::temp_dir().join(format!("wa-sms-detect-{}-{name}", std::process::id()));
        std::fs::write(&p, bytes).unwrap();
        let r = detect(&p.to_string_lossy());
        let _ = std::fs::remove_file(p);
        r
    }

    #[test]
    fn content_decides_not_the_name() {
        let mut mp4 = vec![0, 0, 0, 24];
        mp4.extend_from_slice(b"ftypisom\0\0\0\0");
        assert_eq!(kind_of("a.bin", &mp4), (Kind::Video, "video/mp4".into()));
        let mut m4a = vec![0, 0, 0, 24];
        m4a.extend_from_slice(b"ftypM4A \0\0\0\0");
        assert_eq!(kind_of("a.mp4", &m4a).0, Kind::Audio);
        assert_eq!(kind_of("x.dat", b"ID3\x03\0\0\0\0\0\0").0, Kind::Audio);
        assert_eq!(kind_of("x.dat", b"OggS\0\x02\0\0\0\0\0\0\0\0").0, Kind::Audio);
        assert_eq!(kind_of("x.dat", &[0xFF, 0xD8, 0xFF, 0xE0, 0, 0]), (Kind::Image, "image/jpeg".into()));
        assert_eq!(kind_of("x.dat", b"%PDF-1.7\n"), (Kind::Document, "application/pdf".into()));
    }

    #[test]
    fn extension_is_the_fallback() {
        let docx = kind_of("r.docx", b"PK\x03\x04\0\0\0\0");
        assert_eq!(docx.0, Kind::Document);
        assert!(docx.1.contains("wordprocessingml"));
        assert_eq!(kind_of("s.mp3", b"\0\0\0\0\0\0\0\0").0, Kind::Audio);
        assert_eq!(kind_of("v.mov", b"\0\0\0\0\0\0\0\0").0, Kind::Video);
        assert_eq!(kind_of("n.txt", b"hello").1, "text/plain");
    }
}
