use crate::branches::key_name;
use crate::config::Cfg;
use crate::util::{digits_only, trunc};
use serde_json::Value;
use std::collections::{BTreeMap, HashMap, HashSet};

/// One person from the contacts file.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Contact {
    pub role: String,  // BM, ASM, CRM, AGM ... (whatever the file says)
    pub name: String,  // optional
    pub phone: String, // digits with country code, e.g. 919994452985
    pub branch: String, // branch-level contact: the one branch the person belongs to
    pub branches: Vec<String>, // cover contact (AGM): every branch the person looks after
    pub cover: bool,
}

impl Contact {
    /// How a person is shown in messages and lists: the name, else the phone.
    pub fn label(&self) -> String {
        if !self.name.is_empty() {
            self.name.clone()
        } else {
            format_phone(&self.phone)
        }
    }
}

// ---------------- phone numbers ----------------

/// Returns the digits including the country code, or "" when the number cannot be right.
/// An Indian number written without +91 must have its 10 digits (9 digits is a typo, not a number).
pub fn normalize_phone(raw: &str, country: &str) -> String {
    let raw = raw.trim();
    let mut d = digits_only(raw);
    let international = raw.starts_with('+') || d.starts_with("00");
    if let Some(rest) = d.strip_prefix("00") {
        d = rest.to_string();
    }
    if !international {
        d = d.trim_start_matches('0').to_string();
        if d.len() == 10 && !country.is_empty() {
            d = format!("{country}{d}");
        } else if country == "91" && d.len() < 10 {
            return String::new();
        }
    }
    if d.len() < 8 || d.len() > 15 {
        return String::new();
    }
    d
}

/// Writes 919994452985 as "+91 99944 52985".
pub fn format_phone(phone: &str) -> String {
    let n = phone.len();
    if n > 10 {
        format!("+{} {} {}", &phone[..n - 10], &phone[n - 10..n - 5], &phone[n - 5..])
    } else {
        format!("+{phone}")
    }
}

/// Drops the default country code: "99944 52985".
pub fn short_phone(phone: &str, country: &str) -> String {
    let mut p = phone;
    if !country.is_empty() && p.starts_with(country) && p.len() == country.len() + 10 {
        p = &p[country.len()..];
    }
    if p.len() == 10 {
        return format!("{} {}", &p[..5], &p[5..]);
    }
    format!("+{phone}")
}

// ---------------- reading the contacts file ----------------

/// Reads the contacts file. Two formats are understood:
///
///   .json  {"agms": {"AGM_01": {"name": "...", "phone": "..."}},
///           "branches": {"Kovilpatti": {"agm_id": "AGM_01",
///                                       "contacts": [{"role": "BM", "name": "...", "phone": "..."}]}}}
///   .txt   one person per line:  Branch, Role, Phone [, Name]
///
/// It returns the people plus warnings about lines that were skipped.
pub fn load_contacts(path: &str, cfg: &Cfg) -> Result<(Vec<Contact>, Vec<String>), String> {
    let data = std::fs::read(path).map_err(|_| format!("contacts file not found: {path}"))?;
    let base = std::path::Path::new(path).file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let mut b = ContactBuilder::new(cfg);
    let is_json = std::path::Path::new(path)
        .extension()
        .map(|e| e.to_string_lossy().eq_ignore_ascii_case("json"))
        .unwrap_or(false);
    let text = String::from_utf8_lossy(&data).to_string();
    if is_json {
        b.read_json(&text).map_err(|e| format!("{base}: {e}"))?;
    } else {
        b.read_text(&text);
    }
    if b.list.is_empty() {
        return Err(format!("{base} has no contacts. Expected lines like:  Kovilpatti, BM, 9994452985"));
    }
    Ok((b.list, b.warnings))
}

/// Collects people while a file is read. It keeps role spelling consistent, merges the lines
/// of one AGM into a single person and skips exact duplicates.
struct ContactBuilder {
    country: String,
    cover: HashSet<String>,           // upper-case roles that look after many branches
    spelling: HashMap<String, String>, // upper-case role -> the spelling used first
    list: Vec<Contact>,
    cover_at: HashMap<String, usize>, // "AGM|phone" -> index in list
    seen: HashSet<String>,
    warnings: Vec<String>,
}

impl ContactBuilder {
    fn new(cfg: &Cfg) -> Self {
        ContactBuilder {
            country: cfg.country.clone(),
            cover: cfg.cover_roles.iter().map(|r| r.trim().to_uppercase()).collect(),
            spelling: HashMap::new(),
            list: Vec::new(),
            cover_at: HashMap::new(),
            seen: HashSet::new(),
            warnings: Vec::new(),
        }
    }

    fn role(&mut self, raw: &str) -> String {
        let raw = raw.trim();
        let raw = if raw.is_empty() { "BM" } else { raw };
        let key = raw.to_uppercase();
        if let Some(first) = self.spelling.get(&key) {
            return first.clone();
        }
        self.spelling.insert(key, raw.to_string());
        raw.to_string()
    }

    /// Records one person. For a cover role (AGM) the branch is added to that person's list.
    fn add(&mut self, branch: &str, role: &str, name: &str, raw_phone: &str) {
        let branch = branch.trim().to_string();
        let role = self.role(role);
        let name = name.trim().to_string();
        let phone = normalize_phone(raw_phone, &self.country);
        if phone.is_empty() {
            self.warnings.push(format!("{branch} {role}: phone {:?} is not a valid number - skipped", raw_phone.trim()));
            return;
        }
        if self.cover.contains(&role.to_uppercase()) {
            let key = format!("{}|{}", role.to_uppercase(), phone);
            let i = match self.cover_at.get(&key) {
                Some(i) => *i,
                None => {
                    self.cover_at.insert(key, self.list.len());
                    self.list.push(Contact { role: role.clone(), name: name.clone(), phone: phone.clone(), cover: true, ..Default::default() });
                    self.list.len() - 1
                }
            };
            let c = &mut self.list[i];
            if c.name.is_empty() {
                c.name = name;
            }
            if !branch.is_empty() {
                c.branches.push(branch);
            }
            return;
        }
        if branch.is_empty() {
            self.warnings.push(format!("{role} {}: no branch given - skipped", format_phone(&phone)));
            return;
        }
        let key = format!("{}|{}|{}", role.to_uppercase(), key_name(&branch), phone);
        if !self.seen.insert(key) {
            return;
        }
        self.list.push(Contact { role, name, phone, branch, ..Default::default() });
    }

    // ---- text format ----

    fn read_text(&mut self, text: &str) {
        let text = text.replace('\r', "");
        for (n, line) in text.split('\n').enumerate() {
            let line = line.trim_start_matches('\u{feff}').trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }
            let f: Vec<&str> = line.split(|c| c == ',' || c == ';' || c == '\t').map(str::trim).collect();
            if f.len() < 3 {
                self.warnings.push(format!("line {} ignored (write it as: Branch, Role, Phone): {}", n + 1, trunc(line, 40)));
                continue;
            }
            if digits_only(f[2]).is_empty() {
                continue; // a header line such as "Branch, Role, Phone"
            }
            let name = f.get(3).copied().unwrap_or("");
            self.add(f[0], f[1], name, f[2]);
        }
    }

    // ---- JSON format ----

    fn read_json(&mut self, data: &str) -> Result<(), String> {
        if data.trim().starts_with('[') {
            return Err("this is a plain list (the old contacts.json of an earlier version) - it is not used. Choose the file with \"agms\" and \"branches\"".into());
        }
        let (text, fixed) = strip_trailing_commas(data);
        if fixed > 0 {
            self.warnings.push(format!("the file has {fixed} comma(s) right before ] or }} - ignored, please remove them"));
        }
        let doc: Value = serde_json::from_str(&text).map_err(|e| format!("not valid JSON ({e})"))?;
        let branches = match doc.get("branches") {
            Some(Value::Object(m)) => m,
            _ => return Err("no \"branches\" found".into()),
        };
        // the file is a map: read it in a fixed (sorted) order
        let sorted_branches: BTreeMap<&String, &Value> = branches.iter().collect();
        let mut agm_branches: HashMap<String, Vec<String>> = HashMap::new();
        for (name, br) in sorted_branches {
            if let Some(id) = br.get("agm_id").and_then(Value::as_str) {
                if !id.is_empty() {
                    agm_branches.entry(id.to_string()).or_default().push(name.clone());
                }
            }
            if let Some(Value::Array(people)) = br.get("contacts") {
                for p in people {
                    let (role, pname, phone) = person_fields(p);
                    self.add(name, &role, &pname, &phone);
                }
            }
        }
        if let Some(Value::Object(agms)) = doc.get("agms") {
            let sorted: BTreeMap<&String, &Value> = agms.iter().collect();
            for (id, p) in sorted {
                let (mut role, pname, phone) = person_fields(p);
                if role.is_empty() {
                    role = "AGM".into();
                }
                self.cover.insert(role.trim().to_uppercase());
                match agm_branches.get(id) {
                    None => self.add("", &role, &pname, &phone),
                    Some(list) if list.is_empty() => self.add("", &role, &pname, &phone),
                    Some(list) => {
                        for name in list {
                            self.add(name, &role, &pname, &phone);
                        }
                    }
                }
            }
        }
        Ok(())
    }
}

/// role, name and phone of one person object. The phone may be written "9994452985" or as a number.
fn person_fields(p: &Value) -> (String, String, String) {
    let s = |k: &str| p.get(k).and_then(Value::as_str).unwrap_or("").to_string();
    let phone = match p.get("phone") {
        Some(Value::String(s)) => s.trim().trim_matches('"').to_string(),
        Some(Value::Number(n)) => n.to_string(),
        _ => String::new(),
    };
    (s("role"), s("name"), phone)
}

/// Removes a comma that stands right before ] or } (the usual slip when the last item of a
/// list is deleted by hand). Commas inside text are left alone.
pub fn strip_trailing_commas(s: &str) -> (String, usize) {
    let chars: Vec<char> = s.chars().collect();
    let mut out = String::with_capacity(s.len());
    let (mut in_text, mut escaped, mut removed) = (false, false, 0usize);
    let mut i = 0;
    while i < chars.len() {
        let r = chars[i];
        if in_text {
            out.push(r);
            if escaped {
                escaped = false;
            } else if r == '\\' {
                escaped = true;
            } else if r == '"' {
                in_text = false;
            }
            i += 1;
            continue;
        }
        if r == '"' {
            in_text = true;
        } else if r == ',' {
            let mut j = i + 1;
            while j < chars.len() && " \t\r\n".contains(chars[j]) {
                j += 1;
            }
            if j < chars.len() && (chars[j] == '}' || chars[j] == ']') {
                removed += 1;
                i += 1;
                continue;
            }
        }
        out.push(r);
        i += 1;
    }
    (out, removed)
}

// ---------------- roles ----------------

/// Lists the roles that exist in the contacts: BM, ASM, CRM first, then any other branch
/// role, and the roles that cover many branches (AGM) last.
pub fn roles_in(contacts: &[Contact]) -> Vec<String> {
    let mut seen: HashMap<String, String> = HashMap::new();
    for c in contacts {
        seen.insert(c.role.to_uppercase(), c.role.clone());
    }
    let rank = |role: &str| -> u8 {
        match role.to_uppercase().as_str() {
            "BM" => 0,
            "ASM" => 1,
            "CRM" => 2,
            _ => {
                if contacts.iter().any(|c| c.role.eq_ignore_ascii_case(role) && c.cover) {
                    9
                } else {
                    5
                }
            }
        }
    };
    let mut roles: Vec<String> = seen.into_values().collect();
    roles.sort_by(|a, b| rank(a).cmp(&rank(b)).then_with(|| a.cmp(b)));
    roles
}

/// Turns a list of roles into a lookup by upper-case name.
pub fn role_set(roles: &[String]) -> HashSet<String> {
    roles.iter().map(|r| r.trim().to_uppercase()).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg() -> Cfg {
        Cfg::default()
    }

    #[test]
    fn phone_normalising() {
        assert_eq!(normalize_phone("9994452985", "91"), "919994452985");
        assert_eq!(normalize_phone("+91 99944 52985", "91"), "919994452985");
        assert_eq!(normalize_phone("0091 9994452985", "91"), "919994452985");
        assert_eq!(normalize_phone("099944529", "91"), ""); // 9 digits is a typo
        assert_eq!(normalize_phone("12", "91"), "");
        assert_eq!(format_phone("919994452985"), "+91 99944 52985");
        assert_eq!(short_phone("919994452985", "91"), "99944 52985");
    }

    #[test]
    fn json_with_agm_and_trailing_comma() {
        let text = r#"{
          "agms": {"AGM_01": {"name": "AGM 01", "phone": 9000000001}},
          "branches": {
            "Branch 02": {"agm_id": "AGM_01", "contacts": [{"role": "BM", "name": "B2", "phone": "9000000010"},]},
            "Branch 01": {"agm_id": "AGM_01", "contacts": [
              {"role": "BM", "name": "B1", "phone": "9000000007"},
              {"role": "crm", "phone": "9000000008"}
            ]}
          }
        }"#;
        let mut b = ContactBuilder::new(&cfg());
        b.read_json(text).unwrap();
        assert_eq!(b.warnings.len(), 1);
        let agm = b.list.iter().find(|c| c.cover).unwrap();
        assert_eq!(agm.branches, vec!["Branch 01", "Branch 02"]);
        assert_eq!(agm.phone, "919000000001");
        assert_eq!(b.list.iter().filter(|c| !c.cover).count(), 3);
        assert_eq!(roles_in(&b.list), vec!["BM", "crm", "AGM"]);
    }

    #[test]
    fn plain_list_json_is_rejected() {
        let mut b = ContactBuilder::new(&cfg());
        assert!(b.read_json("[1,2]").is_err());
    }

    #[test]
    fn text_format_skips_header_and_bad_lines() {
        let mut b = ContactBuilder::new(&cfg());
        b.read_text("Branch, Role, Phone\n# note\nKovilpatti, BM, 9994452985\nbroken line\nKovilpatti, AGM, 9000000001, AGM 01\nRamnad, AGM, 9000000001");
        assert_eq!(b.list.len(), 2);
        assert_eq!(b.warnings.len(), 1);
        let agm = b.list.iter().find(|c| c.cover).unwrap();
        assert_eq!(agm.branches, vec!["Kovilpatti", "Ramnad"]);
        assert_eq!(agm.name, "AGM 01");
    }

    #[test]
    fn duplicates_are_ignored() {
        let mut b = ContactBuilder::new(&cfg());
        b.read_text("A, BM, 9994452985\nA, bm, 9994452985");
        assert_eq!(b.list.len(), 1);
    }

    #[test]
    fn trailing_commas_inside_text_are_kept() {
        let (s, n) = strip_trailing_commas(r#"{"a": "x,]", "b": [1,2,],}"#);
        assert_eq!(n, 2);
        assert_eq!(s, r#"{"a": "x,]", "b": [1,2]}"#);
    }
}
