// The terminal screen: state, drawing, keys, mouse and the send engine.

use crate::branches::{build_rows, Branch, Row, SendState};
use crate::config::*;
use crate::contacts::{format_phone, load_contacts, roles_in, role_set, Contact};
use crate::excel::load_branches;
use crate::launcher;
use crate::plan::{build_plan, Job, Plan};
use crate::sms::Gateway;
use crate::textbuf::TextBuf;
use crate::theme::{self, Rgb, Theme};
use crate::util::{b64, clip, fit, pad, width};
use crate::wa::{Attachment, Wa, WaError};
use ratatui::crossterm::event::{
    self, DisableBracketedPaste, DisableMouseCapture, EnableBracketedPaste, EnableMouseCapture, Event, KeyCode, KeyEvent, KeyEventKind,
    KeyModifiers, MouseButton, MouseEventKind,
};
use ratatui::crossterm::execute;
use ratatui::layout::{Constraint, Layout, Rect};
use ratatui::style::{Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Clear, Paragraph};
use ratatui::{DefaultTerminal, Frame};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::Arc;
use std::time::{Duration, Instant};

mod ui;

// ---------------- messages from background threads ----------------

enum Msg {
    Alert(String, String),
    Done { idx: usize, ok: bool, note: String },
    Wait(Instant),
    Finished { stopped: bool },
    PairCode(String),
    Reload,
}

enum Act {
    Send,
    /// BM etc. are ticked but a cover role (AGM) is not: ask whether to add it. Holds those roles.
    Cover(Vec<String>),
    Quit,
}

/// Something on the main screen that reacts to a mouse click.
#[derive(Clone, Copy)]
enum Hit {
    Mode(u8),
    Wa,
    Sms,
    Role(usize),
    Attach,
    Remove,
    Excel,
    Contacts,
    EditText,
    Check,
    LinkWa,
    All(bool),
    Send,
    Stop,
    Theme,
    Settings,
    ContactsList,
    Zero,
    Reload,
    Help,
    Quit,
    Row(usize),
}

/// Something in an open dialog that reacts to a click: a button (a key press) or a list row.
#[derive(Clone, Copy)]
enum MHit {
    Key(KeyCode, KeyModifiers),
    Row(usize),
}

#[derive(Clone, Copy, PartialEq)]
enum Target {
    Excel,
    Contacts,
    Attach,
}

enum InputAct {
    Message,
    Path(Target),
    Setting(usize),
    PairPhone,
    TestSms,
}

struct Browser {
    dir: PathBuf,
    entries: Vec<(String, bool)>,
    sel: usize,
    target: Target,
}

enum Modal {
    Alert(String, String),
    Confirm(String, String, Act),
    Input { title: String, hint: String, buf: TextBuf, act: InputAct },
    Browse(Browser),
    Contacts(usize),
    Zero(usize),
    Settings(usize),
    Help,
    Themes { sel: usize, old: String },
    Link { code: Option<String> },
}

#[derive(Default)]
struct Live {
    running: bool,
    total: usize,
    done: usize,
    sent: usize,
    failed: usize,
    current: String,
    until: Option<Instant>,
    recent: Vec<String>,
}

pub struct App {
    store: Store,
    wa: Arc<Wa>,
    gw: Arc<Gateway>,
    themes: Vec<Theme>,
    sys_theme: Option<Theme>,
    rows: Vec<Row>,
    contacts: Vec<Contact>,
    roles: Vec<String>,
    excel_note: String,
    excel_err: Option<String>,
    contacts_err: Option<String>,
    warnings: Vec<String>,
    sel: usize,
    top: usize,
    table: Rect,
    hits: Vec<(Rect, Hit)>,
    mhits: Vec<(Rect, MHit)>,
    att_info: String,
    modal: Option<Modal>,
    live: Live,
    jobs: Vec<Job>,
    pending: Option<Plan>,
    stop: Arc<AtomicBool>,
    tx: Sender<Msg>,
    rx: Receiver<Msg>,
    quit: bool,
    last_version: u64,
}

const SETTINGS: &[(&str, bool)] = &[
    ("Excel file...", false),
    ("Contacts file...", false),
    ("Country code", false),
    ("Reviews column (blank = auto)", false),
    ("SMS gateway address", false),
    ("WhatsApp min delay (ms)", false),
    ("WhatsApp max delay (ms)", false),
    ("SMS min delay (ms)", false),
    ("SMS max delay (ms)", false),
    ("SMS test phone", false),
    ("Ask before sending", true),
    ("AGM message: combined / separate", true),
    ("Send by WhatsApp", true),
    ("Send by SMS", true),
    ("Check SMS gateway", false),
    ("Send test SMS", false),
    ("Reload config.json", false),
    ("Re-pair WhatsApp (new QR)", false),
    ("Log out WhatsApp", false),
    ("Colour theme...", false),
];

fn now() -> String {
    chrono::Local::now().format("%Y-%m-%d %H:%M:%S").to_string()
}

fn log(name: &str, line: &str) {
    append_log(name, &format!("{} {}", now(), line));
}

impl App {
    pub fn new(store: Store, problem: Option<String>) -> App {
        let (tx, rx) = channel();
        let mut app = App {
            store,
            wa: Arc::new(Wa::new()),
            gw: Arc::new(Gateway::default()),
            themes: theme::presets(),
            sys_theme: None,
            rows: vec![],
            contacts: vec![],
            roles: vec![],
            excel_note: String::new(),
            excel_err: None,
            contacts_err: None,
            warnings: vec![],
            sel: 0,
            top: 0,
            table: Rect::default(),
            hits: vec![],
            mhits: vec![],
            att_info: String::new(),
            modal: None,
            live: Live::default(),
            jobs: vec![],
            pending: None,
            stop: Arc::new(AtomicBool::new(false)),
            tx,
            rx,
            quit: false,
            last_version: 0,
        };
        if app.store.fresh {
            app.store.save_cfg();
        }
        app.reload_data();
        app.refresh_att();
        app.start_wa();
        if let Some(p) = problem {
            app.modal = Some(Modal::Alert("config.json problem".into(), format!("{p}\n\nDefaults are used until you fix the file (Settings > Reload).")));
        } else if !app.store.cfg.welcomed {
            app.store.cfg.welcomed = true;
            app.store.save_cfg();
            app.modal = Some(Modal::Help);
        }
        app
    }

    fn cfg(&self) -> &Cfg {
        &self.store.cfg
    }

    fn start_wa(&self) {
        let wa = self.wa.clone();
        std::thread::spawn(move || {
            let _ = wa.start();
        });
    }

    fn alert(&mut self, title: &str, body: impl Into<String>) {
        self.modal = Some(Modal::Alert(title.into(), body.into()));
    }

    fn save(&mut self) {
        self.store.cfg.normalize();
        self.store.save_cfg();
    }

    // ---------- data ----------

    fn excel_path(&self) -> String {
        resolve_path(&self.cfg().excel_file, &self.cfg().excel_dir)
    }

    fn contacts_path(&self) -> String {
        resolve_path(&self.cfg().contacts_file, &self.cfg().contacts_dir)
    }

    fn reload_data(&mut self) {
        let mut branches: Vec<Branch> = vec![];
        self.excel_err = None;
        self.excel_note.clear();
        if self.cfg().excel_file.trim().is_empty() {
            self.excel_err = Some("no Excel file chosen - press F3".into());
        } else {
            match load_branches(&self.excel_path(), &self.cfg().reviews_col) {
                Ok((b, note)) => {
                    branches = b;
                    self.excel_note = note;
                }
                Err(e) => self.excel_err = Some(e),
            }
        }
        self.contacts_err = None;
        self.warnings.clear();
        self.contacts.clear();
        if self.cfg().contacts_file.trim().is_empty() {
            self.contacts_err = Some("no contacts file - press F7".into());
        } else {
            match load_contacts(&self.contacts_path(), self.cfg()) {
                Ok((c, w)) => {
                    self.contacts = c;
                    self.warnings = w;
                }
                Err(e) => self.contacts_err = Some(e),
            }
        }
        let (rows, unmatched) = build_rows(&branches, &self.contacts, &self.rows);
        self.rows = rows;
        if !unmatched.is_empty() {
            self.warnings.push(format!("not found in Excel: {}", unmatched.join(", ")));
        }
        self.roles = roles_in(&self.contacts);
        let roles = self.roles.clone();
        self.store.cfg.send_roles.retain(|r| roles.contains(r));
        self.sel = self.sel.min(self.rows.len().saturating_sub(1));
    }

    fn theme(&mut self) -> Theme {
        let name = self.cfg().theme.clone();
        if name == "system" {
            if self.sys_theme.is_none() {
                self.sys_theme = Some(theme::system_theme());
            }
            return self.sys_theme.clone().unwrap();
        }
        if name == "custom" {
            if let Some(t) = theme::custom_theme(&self.cfg().custom_theme) {
                return t;
            }
        }
        self.themes.iter().find(|t| t.name.to_lowercase() == name.to_lowercase()).cloned().unwrap_or_else(|| self.themes[0].clone())
    }

    /// (name shown, value saved in config.json)
    fn theme_list(&self) -> Vec<(String, String)> {
        let mut v: Vec<(String, String)> = self.themes.iter().map(|t| (t.name.clone(), t.name.clone())).collect();
        v.push(("System (follow my desktop colours)".into(), "system".into()));
        if theme::custom_theme(&self.cfg().custom_theme).is_some() {
            v.push(("Custom (from config.json)".into(), "custom".into()));
        }
        v
    }

    fn open_themes(&mut self) {
        let cur = self.cfg().theme.clone();
        let sel = self.theme_list().iter().position(|(_, k)| k.eq_ignore_ascii_case(&cur)).unwrap_or(0);
        self.modal = Some(Modal::Themes { sel, old: cur });
    }

    fn ticked_roles(&self) -> Vec<String> {
        self.roles.iter().filter(|r| self.cfg().send_roles.contains(r)).cloned().collect()
    }

    // ---------- sending ----------

    fn begin_send(&mut self, ask_cover: bool) {
        if self.live.running {
            self.alert("Sending", "A send is already running. Press Esc to stop it.");
            return;
        }
        self.reload_data();
        if self.rows.is_empty() {
            let e = self.excel_err.clone().unwrap_or_else(|| "The Excel file has no branches.".into());
            self.alert("Nothing to send", e);
            return;
        }
        if !self.cfg().use_wa && !self.cfg().use_sms {
            self.alert("Nothing to send", "Tick WhatsApp and/or SMS in the VIA line (keys W and S).");
            return;
        }
        let with_file = self.with_attachment();
        if self.cfg().mode == "custom" && self.cfg().custom.trim().is_empty() && !with_file {
            self.alert("Nothing to send", "The custom message is empty. Press E to write it.");
            return;
        }
        if with_file {
            let p = resolve_path(&self.cfg().attachment, &self.cfg().attach_dir);
            if self.cfg().attachment.trim().is_empty() || !exists(&p) {
                self.alert("Attachment", "Custom + Attachment is selected but the file is missing. Press F4 to choose it.");
                return;
            }
            if !self.cfg().use_wa {
                self.alert("Attachment", "Files go by WhatsApp only. Tick WhatsApp in the VIA line.");
                return;
            }
        }
        let roles = role_set(&self.cfg().send_roles);
        if roles.is_empty() {
            self.alert("Nothing to send", "Tick who to send to: press 1, 2, 3 ... for the roles in SEND TO.");
            return;
        }
        let plan = build_plan(&self.rows, self.cfg(), &roles);
        if plan.ticked == 0 {
            self.alert("Nothing to send", "No branch is ticked. Use Space on a row, or A for all.");
            return;
        }
        if plan.jobs.is_empty() {
            let mut t = String::from("Nobody to send to for the ticked branches and roles.");
            if !plan.no_contact.is_empty() {
                t.push_str(&format!("\n\nNo contact: {}", fit(&plan.no_contact.join(", "), 300)));
            }
            self.alert("Nothing to send", t);
            return;
        }
        // Only the ticked roles get a message. The one thing we ask: a cover role (AGM) that looks after
        // the ticked branches but is not ticked - nothing else is ever offered.
        let cover: Vec<String> = self.cfg().cover_roles.iter().map(|r| r.to_uppercase()).collect();
        let mut offer: Vec<String> = vec![];
        for r in &self.roles {
            let is_cover = cover.contains(&r.to_uppercase());
            let has_people = self.rows.iter().any(|row| row.ticked && row.people.iter().any(|p| p.contact.role.eq_ignore_ascii_case(r)));
            if ask_cover && is_cover && !roles.contains(r) && has_people {
                offer.push(r.clone());
            }
        }
        self.pending = Some(plan);
        if !offer.is_empty() {
            let chosen = self.ticked_roles().join(", ");
            self.modal = Some(Modal::Confirm(
                format!("Also send to {}?", offer.join("/")),
                format!("Only {chosen} is ticked, so only {chosen} gets the message.\n\nDo you also want to send it to {}?", offer.join(", ")),
                Act::Cover(offer),
            ));
        } else {
            self.after_agm();
        }
    }

    fn after_agm(&mut self) {
        let Some(plan) = &self.pending else { return };
        if self.cfg().confirm_send {
            let mut t = format!("Send {} message(s) for {} branch(es)?", plan.jobs.len(), plan.ticked);
            let mut roles: Vec<_> = plan.by_role.iter().collect();
            roles.sort();
            t.push_str("\n\n");
            for (r, n) in roles {
                t.push_str(&format!("{r}: {n}   "));
            }
            let (w, s) = (self.cfg().use_wa, self.cfg().use_sms);
            t.push_str(&format!("\nvia {}", if w && s { "WhatsApp + SMS" } else if w { "WhatsApp" } else { "SMS" }));
            if self.with_attachment() {
                t.push_str(&format!("\nattachment: {}", self.att_info));
                if s {
                    t.push_str(" (SMS carries the text only)");
                }
            }
            if !plan.no_contact.is_empty() {
                t.push_str(&format!("\n\nNo contact for: {}", fit(&plan.no_contact.join(", "), 200)));
            }
            self.modal = Some(Modal::Confirm("Send".into(), t, Act::Send));
        } else {
            self.start_send();
        }
    }

    fn start_send(&mut self) {
        let Some(plan) = self.pending.take() else { return };
        let cfg = self.cfg().clone();
        if cfg.use_wa && !self.wa.connected() {
            self.alert("WhatsApp is not connected", format!("Status: {}\n\nPress F9 to link WhatsApp, or turn WhatsApp off in Settings.", self.wa.status()));
            return;
        }
        let mut att = None;
        if cfg.use_wa && self.with_attachment() {
            match Attachment::new(&resolve_path(&cfg.attachment, &cfg.attach_dir)) {
                Ok(a) => att = Some(a),
                Err(e) => {
                    self.alert("Attachment", e);
                    return;
                }
            }
        }
        for r in self.rows.iter_mut() {
            for p in r.people.iter_mut() {
                p.state = SendState::NotSent;
            }
        }
        self.jobs = plan.jobs.clone();
        self.live = Live { running: true, total: plan.jobs.len(), ..Default::default() };
        self.stop.store(false, Ordering::SeqCst);
        log("activity.log", &format!("send started: {} message(s)", plan.jobs.len()));
        let (wa, gw, stop, tx) = (self.wa.clone(), self.gw.clone(), self.stop.clone(), self.tx.clone());
        std::thread::spawn(move || {
            let tx2 = tx.clone();
            let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| run_send(plan.jobs, cfg, wa, gw, att, stop.clone(), tx)));
            if r.is_err() {
                let _ = tx2.send(Msg::Finished { stopped: true });
                let _ = tx2.send(Msg::Alert("Error".into(), "The send stopped because of an internal error (see crash.log).".into()));
            }
        });
    }

    fn drain(&mut self) {
        while let Ok(m) = self.rx.try_recv() {
            match m {
                Msg::Alert(t, b) => self.alert(&t, b),
                Msg::Reload => self.reload_data(),
                Msg::PairCode(c) => self.modal = Some(Modal::Link { code: Some(c) }),
                Msg::Wait(t) => self.live.until = Some(t),
                Msg::Done { idx, ok, note } => {
                    let state = if ok { SendState::Sent } else { SendState::Failed };
                    if let Some(job) = self.jobs.get(idx) {
                        for &(r, p) in &job.who {
                            if let Some(person) = self.rows.get_mut(r).and_then(|x| x.people.get_mut(p)) {
                                person.state = state;
                            }
                        }
                        self.live.current = job.label.clone();
                        let line = format!("{} {}{}", if ok { "OK  " } else { "FAIL" }, job.label, if note.is_empty() { String::new() } else { format!(" - {note}") });
                        self.live.recent.push(line);
                        if self.live.recent.len() > 20 {
                            self.live.recent.remove(0);
                        }
                    }
                    self.live.done += 1;
                    if ok {
                        self.live.sent += 1;
                    } else {
                        self.live.failed += 1;
                    }
                }
                Msg::Finished { stopped } => {
                    self.live.running = false;
                    self.live.until = None;
                    let t = format!("{} Sent {}, failed {}.", if stopped { "Stopped." } else { "Finished." }, self.live.sent, self.live.failed);
                    log("activity.log", &t);
                    self.live.recent.push(t);
                }
            }
        }
    }

    // ---------- keys ----------

    fn on_key(&mut self, k: KeyEvent) {
        if self.modal.is_some() {
            self.modal_key(k);
            return;
        }
        let ctrl = k.modifiers.contains(KeyModifiers::CONTROL);
        let n = self.rows.len();
        match k.code {
            KeyCode::Char('q') if ctrl => self.quit = true,
            KeyCode::Char('s') if ctrl => self.begin_send(true),
            KeyCode::Char('t') => self.open_themes(),
            KeyCode::Char('o') => self.modal = Some(Modal::Settings(0)),
            KeyCode::Char('c') => self.modal = Some(Modal::Contacts(0)),
            KeyCode::Char('z') => self.modal = Some(Modal::Zero(0)),
            KeyCode::Char('h') | KeyCode::Char('?') => self.modal = Some(Modal::Help),
            KeyCode::Char('b') => self.open_browser(Target::Excel),
            KeyCode::Char('k') => self.open_browser(Target::Contacts),
            KeyCode::Char('f') => self.open_browser(Target::Attach),
            KeyCode::Char('l') => self.open_link(),
            KeyCode::Char('m') => self.set_mode((self.mode_index() + 1) % 2),
            KeyCode::F(1) => self.modal = Some(Modal::Help),
            KeyCode::F(2) => self.set_mode((self.mode_index() + 1) % 2),
            KeyCode::F(3) => self.open_browser(Target::Excel),
            KeyCode::F(4) => self.open_browser(Target::Attach),
            KeyCode::F(5) => self.begin_send(true),
            KeyCode::F(6) => self.modal = Some(Modal::Zero(0)),
            KeyCode::F(7) => self.modal = Some(Modal::Contacts(0)),
            KeyCode::F(8) => self.modal = Some(Modal::Settings(0)),
            KeyCode::F(9) => self.open_link(),
            KeyCode::F(10) => self.open_themes(),
            KeyCode::Esc => {
                if self.live.running {
                    self.stop.store(true, Ordering::SeqCst);
                    self.live.recent.push("Stopping after the current message...".into());
                }
            }
            KeyCode::Up => self.sel = self.sel.saturating_sub(1),
            KeyCode::Down => self.sel = (self.sel + 1).min(n.saturating_sub(1)),
            KeyCode::PageUp => self.sel = self.sel.saturating_sub(10),
            KeyCode::PageDown => self.sel = (self.sel + 10).min(n.saturating_sub(1)),
            KeyCode::Home => self.sel = 0,
            KeyCode::End => self.sel = n.saturating_sub(1),
            KeyCode::Char(' ') | KeyCode::Enter => {
                if let Some(r) = self.rows.get_mut(self.sel) {
                    r.ticked = !r.ticked;
                }
                self.sel = (self.sel + 1).min(n.saturating_sub(1));
            }
            KeyCode::Char('a') => self.rows.iter_mut().for_each(|r| r.ticked = true),
            KeyCode::Char('g') => self.check_gateway(),
            KeyCode::Char('n') => self.rows.iter_mut().for_each(|r| r.ticked = false),
            KeyCode::Char('e') => self.edit_message(),
            KeyCode::Char('w') => self.toggle_channel(true),
            KeyCode::Char('s') => self.toggle_channel(false),
            KeyCode::Char('r') => {
                self.reload_data();
            }
            KeyCode::Char(c) if c.is_ascii_digit() && c != '0' => {
                self.toggle_role(c as usize - '1' as usize);
            }
            _ => {}
        }
    }

    fn edit_message(&mut self) {
        let custom = self.cfg().mode == "custom";
        let (title, hint, text) = if custom {
            ("Custom message", "Used for this run only - it is not saved to disk.  Enter = new line.  Ctrl+S = use it.", self.cfg().custom.clone())
        } else {
            ("Message template", "Use {branch} and {reviews}.   Enter = save   Esc = cancel", self.cfg().template.clone())
        };
        self.modal = Some(Modal::Input { title: title.into(), hint: hint.into(), buf: TextBuf::with_text(&text, custom), act: InputAct::Message });
    }

    fn open_browser(&mut self, target: Target) {
        let (file, dir) = match target {
            Target::Excel => (self.cfg().excel_file.clone(), self.cfg().excel_dir.clone()),
            Target::Contacts => (self.cfg().contacts_file.clone(), self.cfg().contacts_dir.clone()),
            Target::Attach => (self.cfg().attachment.clone(), self.cfg().attach_dir.clone()),
        };
        let mut start = PathBuf::from(start_dir(&file, &dir));
        if !start.is_dir() {
            start = home_dir();
        }
        let mut b = Browser { dir: start, entries: vec![], sel: 0, target };
        refresh_browser(&mut b);
        self.modal = Some(Modal::Browse(b));
    }

    fn open_link(&mut self) {
        if self.wa.linked() {
            self.alert("WhatsApp", format!("Already linked.\nStatus: {}\n\nTo link another phone use Settings > Log out WhatsApp.", self.wa.status()));
            return;
        }
        let wa = self.wa.clone();
        let tx = self.tx.clone();
        std::thread::spawn(move || {
            if let Err(e) = wa.link() {
                let _ = tx.send(Msg::Alert("WhatsApp".into(), e));
            }
        });
        self.modal = Some(Modal::Link { code: None });
    }

    fn pick(&mut self, target: Target, path: &str) {
        let p = PathBuf::from(path);
        let parent = p.parent().map(|x| x.to_string_lossy().to_string()).unwrap_or_default();
        match target {
            Target::Excel => {
                self.store.cfg.excel_file = path.into();
                self.store.cfg.excel_dir = parent;
            }
            Target::Contacts => {
                self.store.cfg.contacts_file = path.into();
                self.store.cfg.contacts_dir = parent;
            }
            Target::Attach => {
                self.store.cfg.attachment = path.into();
                self.store.cfg.attach_dir = parent;
                self.store.cfg.mode = "custom".into();
            }
        }
        self.refresh_att();
        self.save();
        self.reload_data();
        self.modal = None;
        if target == Target::Excel {
            if let Some(e) = self.excel_err.clone() {
                self.alert("Excel", e);
            }
        } else if target == Target::Contacts {
            if let Some(e) = self.contacts_err.clone() {
                self.alert("Contacts", e);
            }
        }
    }

    fn modal_key(&mut self, k: KeyEvent) {
        let Some(m) = self.modal.take() else { return };
        let ctrl = k.modifiers.contains(KeyModifiers::CONTROL);
        match m {
            Modal::Alert(..) | Modal::Help => {
                if matches!(k.code, KeyCode::Esc | KeyCode::Enter | KeyCode::Char(' ') | KeyCode::Char('q')) {
                    return;
                }
                self.modal = Some(m);
            }
            Modal::Confirm(t, b, act) => match k.code {
                KeyCode::Char('y') | KeyCode::Char('Y') | KeyCode::Enter => match act {
                    Act::Cover(roles) => {
                        for r in roles {
                            if !self.store.cfg.send_roles.contains(&r) {
                                self.store.cfg.send_roles.push(r);
                            }
                        }
                        self.begin_send(false);
                    }
                    Act::Send => self.start_send(),
                    Act::Quit => self.quit = true,
                },
                KeyCode::Char('n') | KeyCode::Char('N') => match act {
                    Act::Cover(_) => self.after_agm(),
                    Act::Send => self.pending = None,
                    Act::Quit => {}
                },
                KeyCode::Esc => self.pending = None,
                _ => self.modal = Some(Modal::Confirm(t, b, act)),
            },
            Modal::Input { title, hint, mut buf, act } => {
                let multi = buf.multiline;
                match k.code {
                    KeyCode::Esc => return,
                    KeyCode::Enter if !multi => {
                        let text = buf.text();
                        self.input_done(act, text);
                        return;
                    }
                    KeyCode::Char('s') if ctrl && multi => {
                        let text = buf.text();
                        self.input_done(act, text);
                        return;
                    }
                    _ => {
                        buf.handle_key(k);
                    }
                }
                self.modal = Some(Modal::Input { title, hint, buf, act });
            }
            Modal::Browse(mut b) => {
                let n = b.entries.len();
                match k.code {
                    KeyCode::Esc => return,
                    KeyCode::Up => b.sel = b.sel.saturating_sub(1),
                    KeyCode::Down => b.sel = (b.sel + 1).min(n.saturating_sub(1)),
                    KeyCode::PageUp => b.sel = b.sel.saturating_sub(10),
                    KeyCode::PageDown => b.sel = (b.sel + 10).min(n.saturating_sub(1)),
                    KeyCode::Home => b.sel = 0,
                    KeyCode::End => b.sel = n.saturating_sub(1),
                    KeyCode::Backspace | KeyCode::Left => {
                        if let Some(p) = b.dir.parent() {
                            b.dir = p.to_path_buf();
                            refresh_browser(&mut b);
                        }
                    }
                    KeyCode::Char('x') if b.target == Target::Attach => {
                        self.store.cfg.attachment.clear();
                        self.att_info.clear();
                        self.save();
                        return;
                    }
                    KeyCode::Char('/') | KeyCode::Char('p') => {
                        let t = b.target;
                        self.modal = Some(Modal::Input {
                            title: "Type or paste the file path".into(),
                            hint: "Enter = use it   Esc = cancel".into(),
                            buf: TextBuf::new(false),
                            act: InputAct::Path(t),
                        });
                        return;
                    }
                    KeyCode::Enter | KeyCode::Right => {
                        if let Some((name, is_dir)) = b.entries.get(b.sel).cloned() {
                            if name == ".." {
                                if let Some(p) = b.dir.parent() {
                                    b.dir = p.to_path_buf();
                                }
                                refresh_browser(&mut b);
                            } else if is_dir {
                                b.dir = b.dir.join(&name);
                                refresh_browser(&mut b);
                            } else {
                                let p = b.dir.join(&name).to_string_lossy().to_string();
                                let t = b.target;
                                self.pick(t, &p);
                                return;
                            }
                        }
                    }
                    _ => {}
                }
                self.modal = Some(Modal::Browse(b));
            }
            Modal::Contacts(mut s) => match k.code {
                KeyCode::Esc | KeyCode::F(7) => {}
                KeyCode::Up => {
                    s = s.saturating_sub(1);
                    self.modal = Some(Modal::Contacts(s));
                }
                KeyCode::Down => {
                    s = (s + 1).min(self.contacts.len().saturating_sub(1));
                    self.modal = Some(Modal::Contacts(s));
                }
                KeyCode::PageUp => self.modal = Some(Modal::Contacts(s.saturating_sub(10))),
                KeyCode::PageDown => self.modal = Some(Modal::Contacts((s + 10).min(self.contacts.len().saturating_sub(1)))),
                KeyCode::Char('o') => self.open_browser(Target::Contacts),
                KeyCode::Char('r') => {
                    self.reload_data();
                    self.modal = Some(Modal::Contacts(0));
                }
                _ => self.modal = Some(Modal::Contacts(s)),
            },
            Modal::Zero(mut s) => {
                let zero: Vec<String> = self.rows.iter().filter(|r| r.reviews == 0).map(|r| r.branch.clone()).collect();
                match k.code {
                    KeyCode::Esc | KeyCode::F(6) => {}
                    KeyCode::Up => {
                        s = s.saturating_sub(1);
                        self.modal = Some(Modal::Zero(s));
                    }
                    KeyCode::Down => {
                        s = (s + 1).min(zero.len().saturating_sub(1));
                        self.modal = Some(Modal::Zero(s));
                    }
                    KeyCode::Char('c') => {
                        copy_to_clipboard(&zero.join("\n"));
                        self.alert("Copied", format!("{} branch name(s) copied.", zero.len()));
                    }
                    KeyCode::Char('s') => {
                        let p = data_dir().join("zero-reviews.txt");
                        match std::fs::write(&p, zero.join("\n") + "\n") {
                            Ok(()) => self.alert("Saved", format!("Saved to {}", p.display())),
                            Err(e) => self.alert("Error", e.to_string()),
                        }
                    }
                    _ => self.modal = Some(Modal::Zero(s)),
                }
            }
            Modal::Settings(mut s) => match k.code {
                KeyCode::Esc | KeyCode::F(8) => {}
                KeyCode::Up => {
                    s = s.saturating_sub(1);
                    self.modal = Some(Modal::Settings(s));
                }
                KeyCode::Down => {
                    s = (s + 1).min(SETTINGS.len() - 1);
                    self.modal = Some(Modal::Settings(s));
                }
                KeyCode::Enter | KeyCode::Char(' ') => {
                    self.modal = Some(Modal::Settings(s));
                    self.setting_activate(s);
                }
                _ => self.modal = Some(Modal::Settings(s)),
            },
            Modal::Themes { mut sel, old } => {
                let list = self.theme_list();
                match k.code {
                    KeyCode::Esc => {
                        self.store.cfg.theme = old;
                        return;
                    }
                    KeyCode::Enter => {
                        self.save();
                        return;
                    }
                    KeyCode::Up => sel = sel.saturating_sub(1),
                    KeyCode::Down => sel = (sel + 1).min(list.len() - 1),
                    KeyCode::Home => sel = 0,
                    KeyCode::End => sel = list.len() - 1,
                    _ => {}
                }
                self.store.cfg.theme = list[sel].1.clone();
                self.modal = Some(Modal::Themes { sel, old });
            }
            Modal::Link { code } => match k.code {
                KeyCode::Esc => self.wa.stop_link(),
                KeyCode::Char('p') => {
                    self.modal = Some(Modal::Input {
                        title: "Pair with a code".into(),
                        hint: "Your WhatsApp number with country code, e.g. 919876543210".into(),
                        buf: TextBuf::new(false),
                        act: InputAct::PairPhone,
                    });
                }
                _ => self.modal = Some(Modal::Link { code }),
            },
        }
    }

    fn setting_value(&self, i: usize) -> String {
        let c = self.cfg();
        match i {
            0 => c.excel_file.clone(),
            1 => c.contacts_file.clone(),
            2 => c.country.clone(),
            3 => c.reviews_col.clone(),
            4 => c.sms_url.clone(),
            5 => c.wa_min.to_string(),
            6 => c.wa_max.to_string(),
            7 => c.sms_min.to_string(),
            8 => c.sms_max.to_string(),
            9 => c.sms_test_phone.clone(),
            10 => if c.confirm_send { "yes" } else { "no" }.into(),
            11 => c.agm_message.clone(),
            12 => if c.use_wa { "on" } else { "off" }.into(),
            13 => if c.use_sms { "on" } else { "off" }.into(),
            19 => self.theme_list().into_iter().find(|(_, k)| k.eq_ignore_ascii_case(&c.theme)).map(|(n, _)| n).unwrap_or_else(|| c.theme.clone()),
            _ => String::new(),
        }
    }

    fn setting_activate(&mut self, i: usize) {
        match i {
            0 => self.open_browser(Target::Excel),
            1 => self.open_browser(Target::Contacts),
            2..=9 => {
                let v = self.setting_value(i);
                self.modal = Some(Modal::Input { title: SETTINGS[i].0.into(), hint: "Enter = save   Esc = cancel".into(), buf: TextBuf::with_text(&v, false), act: InputAct::Setting(i) });
            }
            10 => {
                self.store.cfg.confirm_send = !self.cfg().confirm_send;
                self.save();
            }
            11 => {
                self.store.cfg.agm_message = if self.cfg().agm_message == "separate" { "combined".into() } else { "separate".into() };
                self.save();
            }
            12 => {
                self.store.cfg.use_wa = !self.cfg().use_wa;
                self.save();
            }
            13 => {
                self.store.cfg.use_sms = !self.cfg().use_sms;
                self.save();
            }
            14 => self.check_gateway(),
            15 => {
                let v = self.cfg().sms_test_phone.clone();
                self.modal = Some(Modal::Input { title: "Send test SMS to".into(), hint: "Your own number. Enter = send   Esc = cancel".into(), buf: TextBuf::with_text(&v, false), act: InputAct::TestSms });
            }
            16 => match self.store.reload() {
                Ok(()) => {
                    self.gw.reset();
                    self.reload_data();
                    self.alert("Settings", "config.json reloaded.");
                }
                Err(e) => self.alert("config.json", e),
            },
            17 => {
                let (wa, tx) = (self.wa.clone(), self.tx.clone());
                std::thread::spawn(move || {
                    let r = wa.repair();
                    let _ = tx.send(match r {
                        Ok(()) => Msg::Alert("WhatsApp".into(), "Restarted. Press F9 to see the QR code.".into()),
                        Err(e) => Msg::Alert("WhatsApp".into(), e),
                    });
                });
            }
            18 => {
                let (wa, tx) = (self.wa.clone(), self.tx.clone());
                std::thread::spawn(move || {
                    let r = wa.logout();
                    let _ = tx.send(match r {
                        Ok(()) => Msg::Alert("WhatsApp".into(), "Logged out. The saved session was removed from this computer.".into()),
                        Err(e) => Msg::Alert("WhatsApp".into(), e),
                    });
                });
            }
            19 => self.open_themes(),
            _ => {}
        }
    }

    fn input_done(&mut self, act: InputAct, text: String) {
        match act {
            InputAct::Message => {
                if self.cfg().mode == "custom" {
                    self.store.cfg.custom = text;
                } else if !text.trim().is_empty() {
                    self.store.cfg.template = text.trim().to_string();
                }
                self.save();
            }
            InputAct::Path(t) => {
                let p = resolve_path(&expand_path(&text), "");
                if exists(&p) {
                    self.pick(t, &p);
                } else {
                    self.alert("File", format!("Not found: {p}"));
                }
            }
            InputAct::Setting(i) => {
                let t = text.trim().to_string();
                let num = |s: &str| s.parse::<i64>().ok();
                let c = &mut self.store.cfg;
                match i {
                    2 => c.country = t,
                    3 => c.reviews_col = t,
                    4 => {
                        c.sms_url = t;
                        self.gw.reset();
                    }
                    5 => c.wa_min = num(&t).unwrap_or(c.wa_min),
                    6 => c.wa_max = num(&t).unwrap_or(c.wa_max),
                    7 => c.sms_min = num(&t).unwrap_or(c.sms_min),
                    8 => c.sms_max = num(&t).unwrap_or(c.sms_max),
                    9 => c.sms_test_phone = t,
                    _ => {}
                }
                self.save();
                if i == 2 || i == 3 {
                    self.reload_data();
                }
                self.modal = Some(Modal::Settings(i));
            }
            InputAct::PairPhone => {
                let (wa, tx) = (self.wa.clone(), self.tx.clone());
                std::thread::spawn(move || {
                    let _ = tx.send(match wa.pair_code(&text) {
                        Ok(c) => Msg::PairCode(c),
                        Err(e) => Msg::Alert("Pairing code".into(), e),
                    });
                });
                self.modal = Some(Modal::Link { code: None });
            }
            InputAct::TestSms => {
                self.store.cfg.sms_test_phone = text.trim().to_string();
                self.save();
                let phone = crate::contacts::normalize_phone(&text, &self.cfg().country);
                if phone.is_empty() {
                    self.alert("Test SMS", "That phone number does not look right.");
                    return;
                }
                let (gw, cfg, tx, stop) = (self.gw.clone(), self.cfg().clone(), self.tx.clone(), Arc::new(AtomicBool::new(false)));
                self.alert("Test SMS", "Sending...");
                std::thread::spawn(move || {
                    let r = gw.send(&stop, &cfg, &phone, "Test message from Wa-sms");
                    let _ = tx.send(Msg::Alert(
                        "Test SMS".into(),
                        match r {
                            Ok(()) => format!("Sent to {}. {}", format_phone(&phone), gw.learned()),
                            Err(e) => e,
                        },
                    ));
                });
            }
        }
    }

    fn on_paste(&mut self, s: &str) {
        if let Some(Modal::Input { buf, .. }) = &mut self.modal {
            buf.insert_str(s);
        }
    }

    fn mode_index(&self) -> usize {
        if self.cfg().mode != "custom" {
            0
        } else {
            1
        }
    }

    fn with_attachment(&self) -> bool {
        self.mode_index() == 1 && !self.cfg().attachment.trim().is_empty()
    }

    fn set_mode(&mut self, m: usize) {
        self.store.cfg.mode = if m == 0 { "template".into() } else { "custom".into() };
        self.save();
    }

    /// "Test SMS gateway": asks the phone app whether it answers (sends no SMS).
    fn check_gateway(&mut self) {
        if self.cfg().sms_url.trim().is_empty() {
            let v = self.cfg().sms_url.clone();
            self.modal = Some(Modal::Input {
                title: "SMS gateway address".into(),
                hint: "Address shown in the phone app, e.g. 192.168.1.20:8080. Enter = save, then press G to test.".into(),
                buf: TextBuf::with_text(&v, false),
                act: InputAct::Setting(4),
            });
            return;
        }
        let (gw, cfg, tx) = (self.gw.clone(), self.cfg().clone(), self.tx.clone());
        self.alert("SMS gateway", format!("Checking {} ...", cfg.sms_url));
        std::thread::spawn(move || {
            let (t, ok) = gw.check(&cfg);
            let _ = tx.send(Msg::Alert(if ok { "SMS gateway: connected" } else { "SMS gateway: NOT reachable" }.into(), t));
        });
    }

    fn toggle_channel(&mut self, wa: bool) {
        if wa {
            self.store.cfg.use_wa = !self.cfg().use_wa;
        } else {
            self.store.cfg.use_sms = !self.cfg().use_sms;
        }
        self.save();
    }

    fn toggle_role(&mut self, i: usize) {
        if let Some(role) = self.roles.get(i).cloned() {
            let v = &mut self.store.cfg.send_roles;
            if let Some(p) = v.iter().position(|x| *x == role) {
                v.remove(p);
            } else {
                v.push(role);
            }
        }
    }

    fn refresh_att(&mut self) {
        let p = resolve_path(&self.cfg().attachment, &self.cfg().attach_dir);
        self.att_info = if self.cfg().attachment.trim().is_empty() || !exists(&p) {
            String::new()
        } else {
            let (k, m) = crate::wa::detect(&p);
            format!("{}, {}", k.name(), m)
        };
    }

}

fn copy_to_clipboard(text: &str) {
    use std::io::Write;
    let mut out = std::io::stdout();
    let _ = write!(out, "\x1b]52;c;{}\x07", b64(text.as_bytes()));
    let _ = out.flush();
}

fn refresh_browser(b: &mut Browser) {
    let mut dirs: Vec<(String, bool)> = vec![];
    let mut files: Vec<(String, bool)> = vec![];
    if let Ok(rd) = std::fs::read_dir(&b.dir) {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if name.starts_with('.') {
                continue;
            }
            let is_dir = e.path().is_dir();
            if is_dir {
                dirs.push((name, true));
            } else {
                let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
                let ok = match b.target {
                    Target::Excel => matches!(ext.as_str(), "xlsx" | "xlsm" | "xls" | "csv" | "ods"),
                    Target::Contacts => matches!(ext.as_str(), "json" | "txt" | "csv"),
                    Target::Attach => true,
                };
                if ok {
                    files.push((name, false));
                }
            }
        }
    }
    dirs.sort_by_key(|x| x.0.to_lowercase());
    files.sort_by_key(|x| x.0.to_lowercase());
    let mut v = vec![("..".to_string(), true)];
    v.extend(dirs);
    v.extend(files);
    b.entries = v;
    b.sel = 0;
}

/// The QR code as text rows made of half blocks (black on white), with a one module border.
fn qr_lines(data: &str) -> (Vec<String>, usize) {
    if data.is_empty() {
        return (vec![], 0);
    }
    let Ok(code) = qrcode::QrCode::new(data.as_bytes()) else { return (vec![], 0) };
    let n = code.width();
    let colors = code.to_colors();
    let dark = |x: i64, y: i64| -> bool { x >= 0 && y >= 0 && (x as usize) < n && (y as usize) < n && colors[y as usize * n + x as usize] == qrcode::Color::Dark };
    let mut out = vec![];
    let mut y = -1i64;
    while y < n as i64 + 1 {
        let mut s = String::new();
        for x in -1..(n as i64 + 1) {
            s.push(match (dark(x, y), dark(x, y + 1)) {
                (true, true) => '█',
                (true, false) => '▀',
                (false, true) => '▄',
                _ => ' ',
            });
        }
        out.push(s);
        y += 2;
    }
    (out, n + 2)
}

// ---------------- the send engine (runs on its own thread) ----------------

fn sleep_checked(stop: &AtomicBool, ms: i64) {
    let end = Instant::now() + Duration::from_millis(ms.max(0) as u64);
    while Instant::now() < end && !stop.load(Ordering::SeqCst) {
        std::thread::sleep(Duration::from_millis(100));
    }
}

fn run_send(jobs: Vec<Job>, cfg: Cfg, wa: Arc<Wa>, gw: Arc<Gateway>, att: Option<Attachment>, stop: Arc<AtomicBool>, tx: Sender<Msg>) {
    let total = jobs.len();
    let mut stopped = false;
    for (i, job) in jobs.iter().enumerate() {
        if stop.load(Ordering::SeqCst) {
            stopped = true;
            break;
        }
        let mut ok = false;
        let mut notes: Vec<String> = vec![];
        if job.wa {
            let mut last = String::new();
            for attempt in 0..2 {
                match wa.send(&job.phone, &job.message, att.as_ref()) {
                    Ok(()) => {
                        ok = true;
                        log("sent.log", &format!("WA  {} {} {}", job.role, job.phone, job.label));
                        break;
                    }
                    Err(WaError::NotOnWhatsApp) => {
                        last = "not on WhatsApp".into();
                        break;
                    }
                    Err(e) => {
                        last = e.to_string();
                        if attempt == 0 {
                            sleep_checked(&stop, 2000);
                        }
                    }
                }
            }
            if !last.is_empty() && !ok {
                notes.push(format!("WhatsApp: {last}"));
            }
        }
        if job.sms && !job.message.trim().is_empty() && !stop.load(Ordering::SeqCst) {
            let mut last = String::new();
            let mut sms_ok = false;
            for attempt in 0..2 {
                match gw.send(&stop, &cfg, &job.phone, &job.message) {
                    Ok(()) => {
                        sms_ok = true;
                        log("sent.log", &format!("SMS {} {} {}", job.role, job.phone, job.label));
                        break;
                    }
                    Err(e) => {
                        last = e;
                        if attempt == 0 {
                            sleep_checked(&stop, 2000);
                        }
                    }
                }
            }
            if sms_ok {
                ok = true;
            } else {
                notes.push(format!("SMS: {}", fit(&last, 80)));
            }
        }
        if !ok {
            log("activity.log", &format!("FAILED {} {} - {}", job.phone, job.label, notes.join("; ")));
        }
        let _ = tx.send(Msg::Done { idx: i, ok, note: notes.join("; ") });
        if i + 1 < total && !stop.load(Ordering::SeqCst) {
            let (lo, hi) = if job.sms { (cfg.sms_min, cfg.sms_max) } else { (cfg.wa_min, cfg.wa_max) };
            let ms = if hi > lo { fastrand::i64(lo..=hi) } else { lo };
            let _ = tx.send(Msg::Wait(Instant::now() + Duration::from_millis(ms.max(0) as u64)));
            sleep_checked(&stop, ms);
        }
    }
    if stop.load(Ordering::SeqCst) {
        stopped = true;
    }
    let _ = tx.send(Msg::Finished { stopped });
}

// ---------------- the main loop ----------------

pub fn run(mut terminal: DefaultTerminal, mut app: App) -> std::io::Result<()> {
    let mut out = std::io::stdout();
    let _ = execute!(out, EnableMouseCapture, EnableBracketedPaste);
    let result = (|| -> std::io::Result<()> {
        launcher::ensure_launcher();
        while !app.quit {
            app.drain();
            app.last_version = app.wa.version();
            terminal.draw(|f| app.draw(f))?;
            if event::poll(Duration::from_millis(100))? {
                match event::read()? {
                    Event::Key(k) if k.kind != KeyEventKind::Release => app.on_key(k),
                    Event::Paste(s) => app.on_paste(&s),
                    Event::Mouse(m) => app.on_mouse(m.kind, m.column, m.row),
                    _ => {}
                }
            }
        }
        Ok(())
    })();
    let _ = execute!(std::io::stdout(), DisableBracketedPaste, DisableMouseCapture);
    app.stop.store(true, Ordering::SeqCst);
    app.wa.close();
    result
}
